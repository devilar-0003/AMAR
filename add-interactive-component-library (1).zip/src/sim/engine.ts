/**
 * DigiLab Pro — engine.ts
 * ------------------------------------------------------------------
 * The three.js bench renderer: scene, camera rig, orbit controls,
 * pointer picking, neon bloom (dark theme only), resize handling and
 * deterministic disposal. React owns the LogicSim; the engine merely
 * reads it every frame, so the 3D view never triggers re-renders.
 * ------------------------------------------------------------------
 */
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/examples/jsm/postprocessing/OutputPass.js";
import type { Build } from "./logic";
import type { LogicSim } from "./logic";
import { buildModel, type BenchModel } from "./models";
import { PALETTE, glowTexture, type Palette, type ThemeName } from "./kit";

export interface EngineHooks {
  onPick?: (nodeId: string, bitIndex: number) => void;
  onHover?: (nodeId: string | null) => void;
  onError?: (err: unknown) => void;
  onFrame?: (fps: number) => void;
}

export class BenchEngine {
  readonly container: HTMLElement;
  private hooks: EngineHooks;
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private controls!: OrbitControls;
  private composer: EffectComposer | null = null;
  private bloom: UnrealBloomPass | null = null;
  private bgTexture: THREE.Texture | null = null;
  private stage = new THREE.Group();
  private backdrop = new THREE.Group();
  private model: BenchModel | null = null;
  private sim: LogicSim | null = null;
  private build: Build | null = null;
  private theme: ThemeName = "dark";
  private raf = 0;
  private clockT = new THREE.Clock();
  private t = 0;
  private ro: ResizeObserver | null = null;
  private disposed = false;
  private pointerDown: { x: number; y: number; moved: boolean } | null = null;
  private raycaster = new THREE.Raycaster();
  private ndc = new THREE.Vector2();
  private hovered: THREE.Object3D | null = null;
  private fly: { from: THREE.Vector3; to: THREE.Vector3; tFrom: THREE.Vector3; tTo: THREE.Vector3; k: number; dur: number } | null = null;
  private fpsAcc = 0;
  private fpsFrames = 0;
  private interacted = false;
  private lights: { hemi: THREE.HemisphereLight; key: THREE.DirectionalLight; rimA: THREE.PointLight; rimB: THREE.PointLight } | null = null;
  private grid: THREE.GridHelper | null = null;
  private glow: THREE.Sprite | null = null;
  quality: "high" | "low" = "high";

  constructor(container: HTMLElement, hooks: EngineHooks = {}) {
    this.container = container;
    this.hooks = hooks;
    try {
      this.init();
    } catch (err) {
      this.hooks.onError?.(err);
    }
  }

  /* ---------------- bootstrap ---------------- */

  private init() {
    const pal = PALETTE[this.theme];
    const w = Math.max(1, this.container.clientWidth);
    const h = Math.max(1, this.container.clientHeight);

    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: "high-performance",
      preserveDrawingBuffer: true, // keeps the PNG snapshot button reliable
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    this.renderer.setSize(w, h);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.domElement.style.display = "block";
    this.renderer.domElement.style.width = "100%";
    this.renderer.domElement.style.height = "100%";
    this.renderer.domElement.style.touchAction = "none";
    this.container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(46, w / h, 0.1, 400);
    this.camera.position.set(9, 9, 13);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.075;
    this.controls.minDistance = 3.5;
    this.controls.maxDistance = 60;
    this.controls.maxPolarAngle = Math.PI * 0.495;
    this.controls.minPolarAngle = Math.PI * 0.06;
    this.controls.target.set(0, 0.4, 0);

    this.scene.add(this.stage);
    this.buildBackdrop(pal);
    this.applyTheme(this.theme);
    this.attachEvents();
    this.start();

    // chip markings are canvas textures: re-bake them once the webfonts land,
    // but never while the user is already moving the camera
    const fonts = (document as Document & { fonts?: { ready: Promise<unknown> } }).fonts;
    fonts?.ready
      .then(() => {
        if (!this.disposed && !this.interacted && this.build && this.sim) this.load(this.build, this.sim);
      })
      .catch(() => undefined);
  }

  private buildBackdrop(pal: Palette) {
    // gradient sky
    const c = document.createElement("canvas");
    c.width = 8;
    c.height = 512;
    const g = c.getContext("2d")!;
    const grd = g.createLinearGradient(0, 0, 0, 512);
    grd.addColorStop(0, "#" + pal.bgTop.toString(16).padStart(6, "0"));
    grd.addColorStop(0.55, "#" + pal.bg.toString(16).padStart(6, "0"));
    grd.addColorStop(1, "#" + pal.bg.toString(16).padStart(6, "0"));
    g.fillStyle = grd;
    g.fillRect(0, 0, 8, 512);
    this.bgTexture?.dispose();
    this.bgTexture = new THREE.CanvasTexture(c);
    this.bgTexture.colorSpace = THREE.SRGBColorSpace;
    this.scene.background = this.bgTexture;
    this.scene.fog = new THREE.FogExp2(pal.fog, 0.016);

    // infinite grid deck
    this.grid?.geometry.dispose();
    (this.grid?.material as THREE.Material | undefined)?.dispose();
    this.grid = new THREE.GridHelper(240, 120, pal.wireClk, pal.wireOff);
    const gm = this.grid.material as THREE.Material & { opacity: number; transparent: boolean };
    gm.opacity = this.theme === "dark" ? 0.13 : 0.2;
    gm.transparent = true;
    gm.depthWrite = false;
    this.grid.position.y = -0.62;
    this.backdrop.add(this.grid);

    // soft pool of light under the bench
    const spriteMat = new THREE.SpriteMaterial({
      map: glowTexture(this.theme === "dark" ? 0x0f5f70 : 0x9fd8e2),
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      opacity: this.theme === "dark" ? 0.55 : 0.28,
    });
    if (this.glow) {
      (this.glow.material as THREE.SpriteMaterial).dispose();
      this.backdrop.remove(this.glow);
    }
    this.glow = new THREE.Sprite(spriteMat);
    this.glow.scale.set(46, 26, 1);
    this.glow.position.y = -0.55;
    this.backdrop.add(this.glow);

    if (!this.backdrop.parent) this.scene.add(this.backdrop);
  }

  private applyTheme(theme: ThemeName) {
    const pal = PALETTE[theme];
    this.theme = theme;
    if (!this.scene) return;
    this.buildBackdrop(pal);

    if (this.lights) {
      this.scene.remove(this.lights.hemi, this.lights.key, this.lights.rimA, this.lights.rimB);
      this.lights.key.dispose?.();
    }
    const hemi = new THREE.HemisphereLight(pal.hemi, 0x020608, theme === "dark" ? 0.55 : 0.95);
    const key = new THREE.DirectionalLight(pal.key, theme === "dark" ? 1.5 : 1.9);
    key.position.set(7, 13, 7);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    key.shadow.camera.near = 1;
    key.shadow.camera.far = 48;
    key.shadow.camera.left = -18;
    key.shadow.camera.right = 18;
    key.shadow.camera.top = 18;
    key.shadow.camera.bottom = -18;
    key.shadow.bias = -0.0012;
    key.shadow.normalBias = 0.02;
    const rimA = new THREE.PointLight(pal.rim, theme === "dark" ? 26 : 12, 40, 2);
    rimA.position.set(-9, 4.5, -7);
    const rimB = new THREE.PointLight(pal.ledOn, theme === "dark" ? 18 : 8, 34, 2);
    rimB.position.set(9, 3.4, 8);
    this.scene.add(hemi, key, rimA, rimB);
    this.lights = { hemi, key, rimA, rimB };

    if (this.bloom) this.bloom.strength = theme === "dark" ? 0.62 : 0.0;
  }

  /* ---------------- events ---------------- */

  private attachEvents() {
    const el = this.renderer.domElement;
    el.addEventListener("pointerdown", this.onDown);
    el.addEventListener("pointerup", this.onUp);
    el.addEventListener("pointermove", this.onMove);
    el.addEventListener("pointerleave", this.onLeave);

    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(this.container);
    window.addEventListener("resize", this.resize);
  }

  private toNdc(e: PointerEvent) {
    const r = this.renderer.domElement.getBoundingClientRect();
    this.ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
  }

  private pick(e: PointerEvent): { node: string; bit: number; obj: THREE.Object3D } | null {
    if (!this.model) return null;
    this.toNdc(e);
    this.raycaster.setFromCamera(this.ndc, this.camera);
    const targets: THREE.Object3D[] = [];
    for (const [, part] of this.model.parts) {
      if (part.hotspots?.length) targets.push(...part.hotspots);
    }
    const hits = this.raycaster.intersectObjects(targets, false);
    if (!hits.length) return null;
    let obj: THREE.Object3D | null = hits[0].object;
    let nodeId: string | null = null;
    while (obj) {
      if (obj.userData?.nodeId) {
        nodeId = obj.userData.nodeId as string;
        break;
      }
      obj = obj.parent;
    }
    if (!nodeId) return null;
    const bit = typeof hits[0].object.userData?.bit === "number" ? hits[0].object.userData.bit : 0;
    return { node: nodeId, bit, obj: hits[0].object };
  }

  private onDown = (e: PointerEvent) => {
    this.interacted = true;
    this.pointerDown = { x: e.clientX, y: e.clientY, moved: false };
  };

  private onMove = (e: PointerEvent) => {
    if (this.pointerDown) {
      if (Math.abs(e.clientX - this.pointerDown.x) + Math.abs(e.clientY - this.pointerDown.y) > 5)
        this.pointerDown.moved = true;
    }
    const hit = this.pick(e);
    const next = hit ? hit.obj : null;
    if (next !== this.hovered) {
      this.hovered = next;
      this.renderer.domElement.style.cursor = hit ? "pointer" : "grab";
      this.hooks.onHover?.(hit ? hit.node : null);
    }
  };

  private onLeave = () => {
    this.hovered = null;
    this.hooks.onHover?.(null);
  };

  private onUp = (e: PointerEvent) => {
    const wasDrag = this.pointerDown?.moved;
    this.pointerDown = null;
    if (wasDrag) return;
    const hit = this.pick(e);
    if (hit) this.hooks.onPick?.(hit.node, hit.bit);
  };

  private resize = () => {
    if (this.disposed || !this.renderer) return;
    const w = Math.max(1, this.container.clientWidth);
    const h = Math.max(1, this.container.clientHeight);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, this.quality === "low" ? 1 : 2));
    this.renderer.setSize(w, h);
    this.composer?.setSize(w, h);
    this.bloom?.setSize(w, h);
  };

  /* ---------------- build lifecycle ---------------- */

  load(build: Build, sim: LogicSim) {
    if (this.disposed) return;
    this.build = build;
    this.sim = sim;
    this.clearStage();
    try {
      this.model = buildModel(build, PALETTE[this.theme]);
      this.stage.add(this.model.group);
      this.frameModel(true);
    } catch (err) {
      this.hooks.onError?.(err);
      this.model = null;
    }
  }

  private clearStage() {
    if (!this.model) return;
    this.stage.remove(this.model.group);
    disposeTree(this.model.group);
    this.model = null;
  }

  setSim(sim: LogicSim) {
    this.sim = sim;
  }

  frameModel(instant = false) {
    if (!this.model) return;
    const b = this.model.bounds;
    const size = new THREE.Vector3();
    b.getSize(size);
    const center = new THREE.Vector3();
    b.getCenter(center);
    const maxDim = Math.max(size.x, size.z, 6);
    const dist = maxDim * 1.32 + 3.2;
    const to = new THREE.Vector3(center.x + dist * 0.34, dist * 0.62, center.z + dist * 0.78);
    const tTo = new THREE.Vector3(center.x, Math.min(center.y, 1.0), center.z);
    if (instant) {
      this.camera.position.copy(to);
      this.controls.target.copy(tTo);
      this.controls.update();
      this.fly = null;
      return;
    }
    this.fly = { from: this.camera.position.clone(), to, tFrom: this.controls.target.clone(), tTo, k: 0, dur: 0.75 };
  }

  resetView() {
    this.frameModel(false);
  }

  focus(nodeId: string) {
    if (!this.model) return;
    const p = this.model.focusOf(nodeId);
    if (!p) return;
    const world = p.clone().add(this.model.group.position);
    const dir = this.camera.position.clone().sub(this.controls.target).normalize();
    this.fly = {
      from: this.camera.position.clone(),
      to: world.clone().add(dir.multiplyScalar(6.5)).setY(Math.max(3.2, world.y + 3.4)),
      tFrom: this.controls.target.clone(),
      tTo: world,
      k: 0,
      dur: 0.6,
    };
  }

  setTheme(theme: ThemeName) {
    if (theme === this.theme) return;
    this.applyTheme(theme);
    // rebuild so part colours follow the palette
    if (this.build && this.sim) this.load(this.build, this.sim);
  }

  setQuality(q: "high" | "low") {
    this.quality = q;
    this.resize();
  }

  setBloom(on: boolean) {
    if (on && !this.composer) this.setupComposer();
    if (!on) this.composer = null;
  }

  private setupComposer() {
    if (this.composer || this.disposed) return;
    try {
      const w = Math.max(1, this.container.clientWidth);
      const h = Math.max(1, this.container.clientHeight);
      const composer = new EffectComposer(this.renderer);
      composer.addPass(new RenderPass(this.scene, this.camera));
      const bloom = new UnrealBloomPass(new THREE.Vector2(w, h), 0.62, 0.55, 0.62);
      if (this.theme === "light") bloom.strength = 0;
      composer.addPass(bloom);
      composer.addPass(new OutputPass());
      composer.setSize(w, h);
      this.composer = composer;
      this.bloom = bloom;
    } catch (err) {
      this.composer = null;
      this.bloom = null;
      this.hooks.onError?.(err);
    }
  }

  /* ---------------- loop ---------------- */

  private start() {
    const loop = () => {
      if (this.disposed) return;
      this.raf = requestAnimationFrame(loop);
      const dt = Math.min(this.clockT.getDelta(), 0.1);
      this.t += dt;

      if (document.hidden) return;

      if (this.fly) {
        this.fly.k = Math.min(1, this.fly.k + dt / this.fly.dur);
        const e = 1 - Math.pow(1 - this.fly.k, 3);
        this.camera.position.lerpVectors(this.fly.from, this.fly.to, e);
        this.controls.target.lerpVectors(this.fly.tFrom, this.fly.tTo, e);
        if (this.fly.k >= 1) this.fly = null;
      }

      if (this.model && this.sim) {
        try {
          this.model.update(this.sim, this.t, dt);
        } catch (err) {
          this.hooks.onError?.(err);
        }
      }

      this.controls.update();

      if (this.composer && this.quality === "high" && this.theme === "dark") this.composer.render();
      else this.renderer.render(this.scene, this.camera);

      this.fpsAcc += dt;
      this.fpsFrames++;
      if (this.fpsAcc > 0.5) {
        this.hooks.onFrame?.(Math.round(this.fpsFrames / this.fpsAcc));
        this.fpsAcc = 0;
        this.fpsFrames = 0;
      }
    };
    loop();
  }

  get ready() {
    return Boolean(this.renderer);
  }

  snapshot(): string | null {
    try {
      if (this.composer && this.quality === "high" && this.theme === "dark") this.composer.render();
      else this.renderer?.render(this.scene, this.camera);
      return this.renderer.domElement.toDataURL("image/png");
    } catch {
      return null;
    }
  }

  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this.resize);
    this.ro?.disconnect();
    const el = this.renderer?.domElement;
    if (el) {
      el.removeEventListener("pointerdown", this.onDown);
      el.removeEventListener("pointerup", this.onUp);
      el.removeEventListener("pointermove", this.onMove);
      el.removeEventListener("pointerleave", this.onLeave);
    }
    this.clearStage();
    disposeTree(this.backdrop);
    this.bgTexture?.dispose();
    this.controls?.dispose();
    this.composer?.dispose?.();
    this.renderer?.dispose();
    if (el && el.parentElement) el.parentElement.removeChild(el);
    this.scene?.clear();
  }
}

/** Recursively free GPU resources of a subtree. */
export function disposeTree(root: THREE.Object3D) {
  root.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (mesh.geometry) mesh.geometry.dispose?.();
    const m = (mesh as unknown as { material?: THREE.Material | THREE.Material[] }).material;
    if (Array.isArray(m)) m.forEach((mm) => disposeMaterial(mm));
    else if (m) disposeMaterial(m);
  });
  root.clear();
}

function disposeMaterial(m: THREE.Material) {
  const rec = m as unknown as Record<string, unknown>;
  for (const key of ["map", "emissiveMap", "alphaMap", "normalMap", "roughnessMap"]) {
    const t = rec[key] as THREE.Texture | undefined;
    if (t && typeof t.dispose === "function" && !(t as unknown as { __shared?: boolean }).__shared) t.dispose();
  }
  m.dispose?.();
}
