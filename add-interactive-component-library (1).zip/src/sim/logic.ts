/**
 * DigiLab Pro — logic.ts
 * ------------------------------------------------------------------
 * Headless digital logic kernel. It is shared by:
 *   • the Three.js bench renderer (sim/models.ts)
 *   • the truth-table generator (data/library helpers)
 *   • the 2D logic-diagram preview
 * Because every view reads the *same* evaluator, simulated results and
 * documented truth tables can never disagree.
 * ------------------------------------------------------------------
 */

export type Bit = 0 | 1;
export type Vec = Bit[]; // index 0 = LSB

export type GateKind =
  | "AND"
  | "OR"
  | "NOT"
  | "NAND"
  | "NOR"
  | "XOR"
  | "XNOR"
  | "BUF";

export type FFKind = "SR" | "JK" | "D" | "T";
export type MemKind = "ROM" | "RAM" | "SRAM" | "DRAM";
export type Edge = "rising" | "falling" | "latch";

export type NodeKind =
  | "IN" // single-bit toggle switch
  | "INBUS" // DIP switch bank (multi-bit)
  | "CLK" // clock generator input
  | "OUT" // single-bit indicator lamp
  | "OUTBUS" // LED bar / 7-segment readout
  | "GATE"
  | "FF"
  | "MEM";

/** Input reference: "NODE" | "NODE:bit" | "VCC" | "GND" */
export type Ref = string;

export interface LNode {
  id: string;
  kind: NodeKind;
  label: string;
  /** part marking printed on the IC body, e.g. "7408" */
  part?: string;
  /** ordered input references (GATE) */
  in?: Ref[];
  /** gate function */
  gate?: GateKind;
  /** flip-flop descriptor */
  ff?: FFKind;
  /** number of bits for FF banks / buses */
  bits?: number;
  /** clock reference for stateful nodes */
  clk?: Ref;
  edge?: Edge;
  /** control pin references for flip-flops */
  ctl?: Record<string, Ref>;
  /** memory descriptor */
  mem?: MemSpec;
  /** initial state (LSB first) */
  init?: Bit[];
  /** OUTBUS presentation: LED bar or seven-segment readout */
  disp?: "led" | "seven";
  /** optional hint for the renderer */
  note?: string;
}

export interface MemSpec {
  kind: MemKind;
  words: number;
  width: number;
  addr: Ref[]; // LSB first
  din?: Ref[]; // LSB first
  we?: Ref;
  cs?: Ref;
  /** pre-programmed contents (ROM) */
  data?: Bit[][];
  /** DRAM: milliseconds before a written cell leaks away */
  decayMs?: number;
  /** DRAM: refresh line — a rising edge restores every cell */
  ref?: Ref;
}

export type TableMode = "combo" | "characteristic" | "sequence" | "memory";

export interface Build {
  id: string;
  title: string;
  nodes: LNode[];
  /** ids of nodes the user drives */
  controls: string[];
  /** ids of nodes the user reads */
  readouts: string[];
  clocked?: boolean;
  clockId?: string;
  tableMode: TableMode;
  /** number of clock pulses recorded by a "sequence" table */
  seqSteps?: number;
  /** demo pattern replayed by the sequence table and the lab's "run demo" player */
  script?: { at: number; set: Record<string, Bit[] | Bit> }[];
  /** state node used by characteristic tables */
  stateId?: string;
  /** truth-table column labels override */
  colLabels?: Record<string, string>;
  note?: string;
}

/* ------------------------------------------------------------------ */
/* primitives                                                          */
/* ------------------------------------------------------------------ */

export const CONST = (r: Ref): Bit | null =>
  r === "VCC" ? 1 : r === "GND" ? 0 : null;

export const parseRef = (r: Ref): { id: string; bit: number } => {
  const i = r.indexOf(":");
  if (i < 0) return { id: r, bit: -1 };
  return { id: r.slice(0, i), bit: Number(r.slice(i + 1)) };
};

export function applyGate(kind: GateKind, bits: Bit[]): Bit {
  const a = bits[0] ?? 0;
  // every n-input function reduces over all bits, not just the first two
  const all = bits.length > 0 && bits.every((b) => b === 1) ? 1 : 0;
  const any = bits.some((b) => b === 1) ? 1 : 0;
  switch (kind) {
    case "AND":
      return all as Bit;
    case "OR":
      return any as Bit;
    case "NOT":
      return (a ^ 1) as Bit;
    case "BUF":
      return a;
    case "NAND":
      return (all ^ 1) as Bit;
    case "NOR":
      return (any ^ 1) as Bit;
    case "XOR": {
      let x = 0;
      for (const b of bits) x ^= b;
      return x as Bit;
    }
    case "XNOR": {
      let x = 0;
      for (const b of bits) x ^= b;
      return (x ^ 1) as Bit;
    }
  }
}

export const GATE_SYMBOL: Record<GateKind, string> = {
  AND: "∧",
  OR: "∨",
  NOT: "¬",
  NAND: "⊼",
  NOR: "⊽",
  XOR: "⊕",
  XNOR: "⊙",
  BUF: "▷",
};

export function widthOf(n: LNode): number {
  switch (n.kind) {
    case "INBUS":
    case "OUTBUS":
      return n.bits ?? 1;
    case "FF":
      return n.bits ?? 1;
    case "MEM":
      return n.mem?.width ?? 1;
    default:
      return 1;
  }
}

const zeros = (w: number): Vec => new Array(w).fill(0) as Vec;

/* ------------------------------------------------------------------ */
/* simulator                                                           */
/* ------------------------------------------------------------------ */

export class LogicSim {
  readonly build: Build;
  private byId = new Map<string, LNode>();
  /** live wire values */
  values = new Map<string, Vec>();
  /** stored state for FF / MEM nodes */
  private state = new Map<string, Vec>();
  /** last observed clock level per stateful node */
  private prevClk = new Map<string, Bit>();
  /** memory cells */
  private cells = new Map<string, Bit[][]>();
  private cellStamp = new Map<string, number>();
  private now = 0;
  /** set when a DRAM cell has leaked (used by the UI warning lamp) */
  leak = false;
  error: string | null = null;

  constructor(build: Build) {
    this.build = build;
    for (const n of build.nodes) this.byId.set(n.id, n);
    this.reset();
  }

  node(id: string): LNode | undefined {
    return this.byId.get(id);
  }

  reset() {
    this.values.clear();
    this.state.clear();
    this.prevClk.clear();
    this.cells.clear();
    this.cellStamp.clear();
    this.leak = false;
    this.error = null;
    this.now = 0;

    for (const n of this.build.nodes) {
      const w = widthOf(n);
      if (n.kind === "FF") {
        const s = n.init ? [...n.init] : zeros(w);
        this.state.set(n.id, s.slice(0, w).concat(zeros(w)).slice(0, w));
      }
      if (n.kind === "MEM" && n.mem) {
        const grid: Bit[][] = [];
        for (let i = 0; i < n.mem.words; i++) {
          const src = n.mem.data?.[i];
          grid.push(src ? src.slice(0, n.mem.width) : zeros(n.mem.width));
        }
        this.cells.set(n.id, grid);
        this.cellStamp.set(n.id, 0);
      }
      if (n.kind === "IN" || n.kind === "CLK" || n.kind === "INBUS") {
        this.values.set(n.id, zeros(w));
      }
    }
    this.evaluate();
    // seed the edge detectors so the first transition is always seen
    for (const n of this.build.nodes) {
      if ((n.kind === "FF" || n.kind === "MEM") && n.clk) this.prevClk.set(n.id, this.bit(n.clk));
      if (n.mem?.ref) this.prevClk.set(`REF:${n.id}`, this.bit(n.mem.ref));
    }
  }

  /* ---------- input handling ---------- */

  setInput(id: string, bit: Bit, index = 0) {
    const n = this.byId.get(id);
    if (!n) return;
    const v = this.values.get(id) ?? zeros(widthOf(n));
    if (n.kind === "CLK") {
      v[0] = bit;
      this.values.set(id, v);
      this.syncClocks();
    } else {
      v[index] = bit;
      this.values.set(id, v);
    }
    this.evaluate();
  }

  toggle(id: string, index = 0) {
    const n = this.byId.get(id);
    if (!n) return;
    const cur = (this.values.get(id)?.[index] ?? 0) as Bit;
    this.setInput(id, (cur ^ 1) as Bit, index);
  }

  setInputs(map: Record<string, Bit[] | Bit>) {
    for (const [k, v] of Object.entries(map)) {
      const arr = Array.isArray(v) ? v : [v];
      arr.forEach((b, i) => {
        const n = this.byId.get(k);
        if (!n) return;
        const vec = this.values.get(k) ?? zeros(widthOf(n));
        vec[i] = b;
        this.values.set(k, vec);
      });
    }
    this.syncClocks();
    this.evaluate();
  }

  get value(): Record<string, Vec> {
    return Object.fromEntries(this.values);
  }

  bit(ref: Ref): Bit {
    const c = CONST(ref);
    if (c !== null) return c;
    const { id, bit } = parseRef(ref);
    const v = this.values.get(id);
    if (!v) return 0;
    return (bit < 0 ? v[0] : v[bit]) ?? 0;
  }

  vec(id: string): Vec {
    return this.values.get(id) ?? zeros(1);
  }

  /** read a numeric bus value (LSB first) */
  num(id: string): number {
    const v = this.vec(id);
    let out = 0;
    for (let i = 0; i < v.length; i++) if (v[i]) out |= 1 << i;
    return out;
  }

  /* ---------- evaluation ---------- */

  /** Fixed-point evaluation of the combinational network. */
  evaluate(passes = 14) {
    for (let p = 0; p < passes; p++) {
      let dirty = false;
      for (const n of this.build.nodes) {
        const next = this.evalNode(n);
        if (!next) continue;
        const prev = this.values.get(n.id);
        if (!prev || prev.length !== next.length || prev.some((b, i) => b !== next[i])) {
          this.values.set(n.id, next);
          dirty = true;
        }
      }
      if (!dirty) break;
    }
  }

  private evalNode(n: LNode): Vec | null {
    const w = widthOf(n);
    switch (n.kind) {
      case "IN":
      case "CLK":
      case "INBUS":
        return this.values.get(n.id) ?? zeros(w);

      case "OUT":
      case "OUTBUS": {
        const src = n.in?.[0];
        if (!src) return zeros(w);
        const { id, bit } = parseRef(src);
        const sv = this.values.get(id) ?? zeros(1);
        if (bit >= 0) return [sv[bit] ?? 0] as Vec;
        const out = zeros(w);
        for (let i = 0; i < w; i++) out[i] = sv[i] ?? 0;
        return out;
      }

      case "GATE": {
        const bits = (n.in ?? []).map((r) => this.bit(r));
        return [applyGate(n.gate ?? "BUF", bits)] as Vec;
      }

      case "FF": {
        const st = this.state.get(n.id) ?? zeros(w);
        if (n.edge === "latch" && n.ff === "SR") {
          // level-sensitive NOR latch: converges through the fixed point
          const s = this.bit(n.ctl?.S ?? "GND");
          const r = this.bit(n.ctl?.R ?? "GND");
          const q: Vec = zeros(w);
          for (let i = 0; i < w; i++) {
            const si = w > 1 ? (n.ctl?.[`S${i}`] ? this.bit(n.ctl[`S${i}`]) : s) : s;
            const ri = w > 1 ? (n.ctl?.[`R${i}`] ? this.bit(n.ctl[`R${i}`]) : r) : r;
            q[i] = si ? 1 : ri ? 0 : st[i];
          }
          this.state.set(n.id, q);
          return q;
        }
        return st;
      }

      case "MEM": {
        const m = n.mem!;
        const grid = this.cells.get(n.id) ?? [];
        let addr = 0;
        m.addr.forEach((r, i) => {
          if (this.bit(r)) addr |= 1 << i;
        });
        addr = Math.min(addr, m.words - 1);
        // DRAM leakage
        if (m.kind === "DRAM" && m.decayMs) {
          const stamp = this.cellStamp.get(n.id) ?? 0;
          if (this.now - stamp > m.decayMs) {
            const fresh = grid.some((word) => word.some((b) => b === 1));
            if (fresh) {
              this.leak = true;
              for (let i = 0; i < grid.length; i++) grid[i] = zeros(m.width);
            }
          }
        }
        const cs = m.cs ? this.bit(m.cs) : 1;
        if (!cs) return zeros(m.width);
        const word = grid[addr] ?? zeros(m.width);
        return word.slice(0, m.width);
      }
    }
  }

  /* ---------- sequential machinery ---------- */

  private stateful(): LNode[] {
    return this.build.nodes.filter((n) => (n.kind === "FF" || n.kind === "MEM") && n.clk);
  }

  /** Cascade clock edges (handles ripple counters naturally). */
  private syncClocks() {
    for (let pass = 0; pass < 12; pass++) {
      // settle the combinational network first, otherwise gated clocks such as
      // CLK·LOAD would never present their edge to the flip-flops
      this.evaluate();
      let changed = false;

      // DRAM refresh lines are edge-sampled independently of the write clock
      for (const n of this.build.nodes) {
        const r = n.mem?.ref;
        if (!r) continue;
        const key = `REF:${n.id}`;
        const cur = this.bit(r);
        const prev = this.prevClk.get(key);
        if (prev === undefined) {
          this.prevClk.set(key, cur);
          continue;
        }
        if (cur !== prev) {
          this.prevClk.set(key, cur);
          changed = true;
          if (prev === 0 && cur === 1) {
            this.cellStamp.set(n.id, this.now);
            this.leak = false;
          }
        }
      }

      const pending: { n: LNode; next: Vec }[] = [];
      for (const n of this.stateful()) {
        if (!n.clk) continue;
        const cur = this.bit(n.clk);
        const prev = this.prevClk.get(n.id);
        if (prev === undefined) {
          this.prevClk.set(n.id, cur);
          continue;
        }
        if (cur === prev) continue;
        this.prevClk.set(n.id, cur);
        changed = true;
        const edge = n.edge ?? "rising";
        const active =
          edge === "rising" ? prev === 0 && cur === 1 : edge === "falling" ? prev === 1 && cur === 0 : true;
        if (!active) continue;
        if (n.kind === "FF") pending.push({ n, next: this.nextFF(n) });
        if (n.kind === "MEM") this.memWrite(n);
      }
      // commit all next-states simultaneously => true synchronous behaviour
      for (const p of pending) this.state.set(p.n.id, p.next);
      if (!changed) break;
    }
    this.evaluate();
  }

  private nextFF(n: LNode): Vec {
    const w = widthOf(n);
    const st = this.state.get(n.id) ?? zeros(w);
    const out: Vec = zeros(w);
    const ctl = n.ctl ?? {};
    for (let i = 0; i < w; i++) {
      const pick = (key: string): Bit => {
        const single = ctl[key];
        const banked = ctl[`${key}${i}`];
        if (banked) return this.bit(banked);
        if (single) return this.bit(single);
        return 0;
      };
      const q = st[i];
      switch (n.ff) {
        case "D":
          out[i] = pick("D");
          break;
        case "T":
          out[i] = pick("T") ? ((q ^ 1) as Bit) : q;
          break;
        case "JK": {
          const j = pick("J");
          const k = pick("K");
          out[i] = j && k ? ((q ^ 1) as Bit) : j ? 1 : k ? 0 : q;
          break;
        }
        case "SR": {
          // characteristic equation Q(t+1) = S + R̄·Q  (S = R = 1 is the
          // forbidden combination — S is given dominance so the model stays
          // deterministic and the documentation flags the condition)
          const s = pick("S");
          const r = pick("R");
          out[i] = s ? 1 : r ? 0 : q;
          break;
        }
      }
      // asynchronous clear / preset win over the clocked behaviour
      if ((ctl.CLR && this.bit(ctl.CLR)) || (ctl[`CLR${i}`] && this.bit(ctl[`CLR${i}`]))) out[i] = 0;
      if ((ctl.PRE && this.bit(ctl.PRE)) || (ctl[`PRE${i}`] && this.bit(ctl[`PRE${i}`]))) out[i] = 1;
    }
    return out;
  }

  private memWrite(n: LNode) {
    const m = n.mem;
    if (!m || !m.din || !m.we) return;
    if (!this.bit(m.we)) return;
    if (m.cs && !this.bit(m.cs)) return;
    const grid = this.cells.get(n.id);
    if (!grid) return;
    let addr = 0;
    m.addr.forEach((r, i) => {
      if (this.bit(r)) addr |= 1 << i;
    });
    if (addr >= m.words) return;
    const word: Vec = zeros(m.width);
    m.din.forEach((r, i) => {
      if (i < m.width) word[i] = this.bit(r);
    });
    grid[addr] = word;
    this.cellStamp.set(n.id, this.now);
    this.leak = false;
  }

  /** Manual single clock pulse (low -> high -> low). */
  pulse() {
    const id = this.build.clockId ?? this.build.controls.find((c) => this.node(c)?.kind === "CLK");
    if (!id) return;
    this.setInput(id, 0);
    this.setInput(id, 1);
    this.setInput(id, 0);
  }

  setClock(high: boolean) {
    const id = this.build.clockId;
    if (!id) return;
    this.setInput(id, high ? 1 : 0);
  }

  clockLevel(): Bit {
    const id = this.build.clockId;
    if (!id) return 0;
    return this.vec(id)[0] ?? 0;
  }

  /** force a state (used by characteristic tables) */
  forceState(id: string, v: Vec) {
    const n = this.byId.get(id);
    if (!n) return;
    this.state.set(id, v.slice(0, widthOf(n)));
    this.evaluate();
  }

  readState(id: string): Vec {
    const n = this.byId.get(id);
    if (!n) return [];
    if (n.kind === "FF") return [...(this.state.get(id) ?? zeros(widthOf(n)))];
    return [...this.vec(id)];
  }

  memoryGrid(id: string): Bit[][] {
    return (this.cells.get(id) ?? []).map((r) => [...r]);
  }

  /** advance wall clock (auto-run + DRAM decay) */
  tick(dtMs: number) {
    this.now += dtMs;
    const anyDram = this.build.nodes.some((n) => n.mem?.kind === "DRAM");
    if (anyDram) this.evaluate(2);
  }

  clone(): LogicSim {
    return new LogicSim(this.build);
  }
}

/* ------------------------------------------------------------------ */
/* truth-table derivation (uses the very same kernel)                  */
/* ------------------------------------------------------------------ */

export interface TableRow {
  inputs: Record<string, Vec>;
  outputs: Record<string, Vec>;
  state?: Vec;
  nextState?: Vec;
  label?: string;
  highlight?: boolean;
}

export interface TruthTable {
  mode: TableMode;
  inCols: string[];
  outCols: string[];
  stateCol?: string;
  rows: TableRow[];
  note?: string;
}



export function deriveTable(build: Build, maxRows = 128): TruthTable {
  const nodeById = new Map(build.nodes.map((n) => [n.id, n]));
  // column labels default to the net identifier (A, B, CIN, SUM …) which is
  // what a textbook truth table shows; colLabels can prettify them.
  const lbl = (id: string) => build.colLabels?.[id] ?? id;
  const sim = new LogicSim(build);

  if (build.tableMode === "memory") {
    const memNode = build.nodes.find((n) => n.kind === "MEM");
    const rows: TableRow[] = [];
    const inCols = build.controls.filter((c) => nodeById.get(c)?.kind !== "CLK").map(lbl);
    if (memNode?.mem) {
      for (let a = 0; a < memNode.mem.words; a++) {
        const addrBits: Vec = memNode.mem.addr.map((_, i) => ((a >> i) & 1) as Bit);
        const inputs: Record<string, Vec> = {};
        const nonClk = build.controls.filter((c) => nodeById.get(c)?.kind !== "CLK");
        let k = 0;
        for (const c of nonClk) {
          const n = nodeById.get(c)!;
          if (n.kind === "INBUS" && /addr/i.test(n.id + n.label)) {
            inputs[lbl(c)] = addrBits;
          } else if (n.kind === "INBUS") {
            inputs[lbl(c)] = zeros(widthOf(n));
          } else {
            inputs[lbl(c)] = [addrBits[k] ?? 0] as Vec;
            k++;
          }
        }
        const data = memNode.mem.data?.[a] ?? zeros(memNode.mem.width);
        const outputs: Record<string, Vec> = {};
        for (const o of build.readouts) outputs[lbl(o)] = data.slice(0, widthOf(nodeById.get(o)!));
        rows.push({ inputs, outputs, label: `0x${a.toString(16).toUpperCase()}` });
      }
    }
    return { mode: "memory", inCols, outCols: build.readouts.map(lbl), rows, note: build.note };
  }

  const nonClock = build.controls.filter((c) => nodeById.get(c)?.kind !== "CLK");

  if (build.tableMode === "characteristic" && build.stateId) {
    const stNode = nodeById.get(build.stateId)!;
    const inCols = nonClock.map(lbl);
    const outCols = build.readouts.map(lbl);
    const rows: TableRow[] = [];
    for (let s = 0; s < 2; s++) {
      for (let combo = 0; combo < 1 << nonClock.length && rows.length < maxRows; combo++) {
        sim.reset();
        const inputs: Record<string, Vec> = {};
        nonClock.forEach((c, i) => {
          const n = nodeById.get(c)!;
          const w = widthOf(n);
          const v: Vec = zeros(w);
          for (let b = 0; b < w; b++) v[b] = ((combo >> (b + i * w)) & 1) as Bit;
          inputs[lbl(c)] = v;
          sim.setInput(c, 0, 0);
          v.forEach((bit, bi) => sim.setInput(c, bit, bi));
        });
        sim.forceState(build.stateId!, [s as Bit]);
        sim.setClock(false);
        sim.setClock(true);
        sim.setClock(false);
        const outputs: Record<string, Vec> = {};
        for (const o of build.readouts) outputs[lbl(o)] = sim.vec(o).slice(0, widthOf(nodeById.get(o)!));
        rows.push({
          inputs,
          outputs,
          state: [s as Bit],
          nextState: sim.readState(build.stateId!).slice(0, 1),
          label: stNode.ff ? `${stNode.ff} @ Q=${s}` : undefined,
        });
      }
    }
    return {
      mode: "characteristic",
      inCols,
      outCols,
      stateCol: `Q(t)`,
      rows,
      note: build.note ?? "Clock pulses ↑ are applied automatically for every row.",
    };
  }

  if (build.tableMode === "sequence") {
    const steps = build.seqSteps ?? 8;
    const inCols = nonClock.map(lbl);
    const outCols = build.readouts.map(lbl);
    const rows: TableRow[] = [];
    sim.reset();
    for (let s = 0; s <= steps; s++) {
      for (const ev of build.script ?? []) if (ev.at === s) sim.setInputs(ev.set);
      const inputs: Record<string, Vec> = {};
      for (const c of nonClock) inputs[lbl(c)] = sim.vec(c).slice();
      const outputs: Record<string, Vec> = {};
      for (const o of build.readouts) outputs[lbl(o)] = sim.vec(o).slice(0, widthOf(nodeById.get(o)!));
      rows.push({ inputs, outputs, label: s === 0 ? "RESET" : `CLK ↑ ${s}` });
      sim.pulse();
    }
    return {
      mode: "sequence",
      inCols,
      outCols,
      rows,
      note: build.note ?? "Outputs sampled immediately after each rising clock edge.",
    };
  }

  /* ---- combinational ---- */
  const totalBits = nonClock.reduce((a, c) => a + widthOf(nodeById.get(c)!), 0);
  const combos = Math.min(1 << totalBits, maxRows);
  const inCols = nonClock.map(lbl);
  const outCols = build.readouts.map(lbl);
  const rows: TableRow[] = [];
  for (let combo = 0; combo < combos; combo++) {
    let shift = 0;
    const inputs: Record<string, Vec> = {};
    for (const c of nonClock) {
      const n = nodeById.get(c)!;
      const w = widthOf(n);
      const v: Vec = zeros(w);
      for (let b = 0; b < w; b++) v[b] = ((combo >> (shift + b)) & 1) as Bit;
      shift += w;
      inputs[lbl(c)] = v;
    }
    sim.reset();
    nonClock.forEach((c) => {
      const v = inputs[lbl(c)];
      v.forEach((bit, bi) => sim.setInput(c, bit, bi));
    });
    const outputs: Record<string, Vec> = {};
    for (const o of build.readouts) outputs[lbl(o)] = sim.vec(o).slice(0, widthOf(nodeById.get(o)!));
    rows.push({ inputs, outputs });
  }
  return { mode: "combo", inCols, outCols, rows, note: build.note, };
}

export const toDecimal = (v: Vec): number => {
  let acc = 0;
  for (let i = 0; i < v.length; i++) if (v[i]) acc |= 1 << i;
  return acc;
};

export const toBinaryString = (v: Vec): string =>
  [...v].reverse().map((b) => b.toString()).join("");
