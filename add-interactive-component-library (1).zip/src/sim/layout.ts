/**
 * DigiLab Pro — layout.ts
 * ------------------------------------------------------------------
 * Pure (renderer-agnostic) graph helpers shared by the 3D bench
 * assembler and the 2D SVG logic diagram, so both views always show the
 * same topology in the same order.
 * ------------------------------------------------------------------
 */
import type { Build, LNode } from "./logic";
import { CONST, parseRef } from "./logic";

export interface Foot {
  w: number;
  d: number;
}

export function footprint(n: LNode): Foot {
  switch (n.kind) {
    case "IN":
      return { w: 0.8, d: 0.7 };
    case "INBUS":
      return { w: 0.42 * (n.bits ?? 4) + 0.5, d: 0.9 };
    case "CLK":
      return { w: 1.1, d: 0.9 };
    case "OUT":
      return { w: 0.6, d: 0.6 };
    case "OUTBUS":
      return n.disp === "seven" ? { w: 1.7, d: 2.1 } : { w: 0.56 * (n.bits ?? 4) + 0.3, d: 0.8 };
    case "GATE":
      return { w: 2.0, d: 1.45 };
    case "FF":
      return { w: 2.5, d: 1.6 };
    case "MEM":
      return { w: 3.3, d: 2.3 };
  }
}

export interface RefUse {
  ref: string;
  clock?: boolean;
  bus?: boolean;
}

export function inputRefs(n: LNode): RefUse[] {
  const out: RefUse[] = [];
  if (n.kind === "OUT" || n.kind === "OUTBUS") {
    if (n.in?.[0]) out.push({ ref: n.in[0], bus: n.kind === "OUTBUS" });
  }
  if (n.kind === "GATE") for (const r of n.in ?? []) out.push({ ref: r });
  if (n.kind === "FF") {
    if (n.clk) out.push({ ref: n.clk, clock: true });
    for (const [k, r] of Object.entries(n.ctl ?? {})) {
      if (CONST(r) !== null) continue;
      out.push({ ref: r, clock: /^CLK/i.test(k) });
    }
  }
  if (n.kind === "MEM" && n.mem) {
    if (n.clk) out.push({ ref: n.clk, clock: true });
    for (const r of n.mem.addr) out.push({ ref: r, bus: true });
    for (const r of n.mem.din ?? []) out.push({ ref: r, bus: true });
    if (n.mem.we) out.push({ ref: n.mem.we });
    if (n.mem.cs) out.push({ ref: n.mem.cs });
    if (n.mem.ref) out.push({ ref: n.mem.ref, clock: true });
  }
  return out;
}

/** Column index of every node; feedback edges are ignored. */
export function layoutDepths(build: Build): Map<string, number> {
  const byId = new Map(build.nodes.map((n) => [n.id, n]));
  const memo = new Map<string, number>();
  const active = new Set<string>();

  const depth = (id: string): number => {
    if (memo.has(id)) return memo.get(id)!;
    if (active.has(id)) return 0;
    const n = byId.get(id);
    if (!n) return 0;
    active.add(id);
    let d = 0;
    if (n.kind !== "IN" && n.kind !== "INBUS" && n.kind !== "CLK") {
      for (const { ref } of inputRefs(n)) {
        if (CONST(ref) !== null) continue;
        const { id: sid } = parseRef(ref);
        if (sid === id) continue;
        d = Math.max(d, depth(sid) + 1);
      }
    }
    active.delete(id);
    memo.set(id, d);
    return d;
  };

  for (const n of build.nodes) depth(n.id);
  const maxD = Math.max(0, ...memo.values());
  for (const id of build.readouts) memo.set(id, maxD + 1);
  return memo;
}

/** Ordered lane (row) index inside each column, barycentre-sorted. */
export function layoutLanes(build: Build): Map<string, number> {
  const depths = layoutDepths(build);
  const columns = new Map<number, LNode[]>();
  for (const n of build.nodes) {
    const d = depths.get(n.id) ?? 0;
    if (!columns.has(d)) columns.set(d, []);
    columns.get(d)!.push(n);
  }
  const lane = new Map<string, number>();
  const keys = [...columns.keys()].sort((a, b) => a - b);
  for (const k of keys) columns.get(k)!.forEach((n, i) => lane.set(n.id, i));

  for (let pass = 0; pass < 3; pass++) {
    for (const k of keys) {
      const nodes = columns.get(k)!;
      const scored = nodes.map((n) => {
        let sum = 0;
        let cnt = 0;
        for (const { ref } of inputRefs(n)) {
          const { id: sid } = parseRef(ref);
          const l = lane.get(sid);
          if (l !== undefined && sid !== n.id) {
            sum += l;
            cnt++;
          }
        }
        return { n, key: cnt ? sum / cnt : (lane.get(n.id) ?? 0) };
      });
      scored.sort((a, b) => a.key - b.key);
      scored.forEach((s, i) => lane.set(s.n.id, i));
    }
  }
  return lane;
}
