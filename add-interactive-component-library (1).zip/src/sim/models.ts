/**
 * DigiLab Pro — models.ts
 * ------------------------------------------------------------------
 * Turns a Build netlist into a laid-out 3D bench:
 *   • topological column layout (inputs left → outputs right)
 *   • barycentre lane ordering to reduce wire crossings
 *   • routed signal wires (single + parallel bus ribbons)
 *   • per-frame binding against the LogicSim kernel
 * ------------------------------------------------------------------
 */
import * as THREE from "three";
import type { Build, LNode, Vec } from "./logic";
import { LogicSim, parseRef, widthOf, CONST } from "./logic";
import {
  clockModule,
  dipBank,
  icChip,
  labelSprite,
  ledBar,
  ledLamp,
  memoryArray,
  pcbBoard,
  sevenSegment,
  toggleSwitch,
  wire,
  type Palette,
  type Part,
  type WirePart,
} from "./kit";
import { footprint, inputRefs, layoutDepths } from "./layout";

const COL_STEP = 3.35;
/** parts are modelled standing on y=0, so the bench surface sits just below */
const BOARD_Y = 0.012;

export interface BenchModel {
  group: THREE.Group;
  parts: Map<string, Part>;
  wires: WirePart[];
  size: { w: number; d: number };
  bounds: THREE.Box3;
  update(sim: LogicSim, t: number, dt: number): void;
  focusOf(id: string): THREE.Vector3 | null;
}

interface Edge {
  src: string;
  srcBit: number; // -1 => whole bus
  dst: string;
  clock?: boolean;
  bus?: boolean;
  bits?: number;
}

export function buildModel(build: Build, pal: Palette): BenchModel {
  const group = new THREE.Group();
  const parts = new Map<string, Part>();
  const wires: WirePart[] = [];
  const byId = new Map(build.nodes.map((n) => [n.id, n]));
  const depths = layoutDepths(build);

  /* ---------- columns & lanes ---------- */
  const columns = new Map<number, LNode[]>();
  for (const n of build.nodes) {
    const d = depths.get(n.id) ?? 0;
    if (!columns.has(d)) columns.set(d, []);
    columns.get(d)!.push(n);
  }
  const colKeys = [...columns.keys()].sort((a, b) => a - b);
  const pos = new Map<string, { x: number; z: number; w: number; d: number }>();

  // first pass: declaration order
  for (const k of colKeys) {
    columns.get(k)!.forEach((n, i) => {
      const f = footprint(n);
      pos.set(n.id, { x: k * COL_STEP, z: i * 2.2, w: f.w, d: f.d });
    });
  }
  // two barycentre passes to untangle wires
  for (let pass = 0; pass < 3; pass++) {
    for (const k of colKeys) {
      const nodes = columns.get(k)!;
      const scored = nodes.map((n) => {
        const refs = inputRefs(n);
        let sum = 0;
        let cnt = 0;
        for (const { ref } of refs) {
          const { id: sid } = parseRef(ref);
          const p = pos.get(sid);
          if (p) {
            sum += p.z;
            cnt++;
          }
        }
        return { n, key: cnt ? sum / cnt : (pos.get(n.id)?.z ?? 0) };
      });
      scored.sort((a, b) => a.key - b.key);
      const gap = 0.95;
      const spread = scored.reduce((a, s) => a + Math.max(footprint(s.n).d, 1.5) + gap, 0) - gap;
      let z = -spread / 2;
      for (const s of scored) {
        const f = footprint(s.n);
        const slot = Math.max(f.d, 1.5);
        pos.set(s.n.id, { x: k * COL_STEP, z: z + slot / 2, w: f.w, d: f.d });
        z += slot + gap;
      }
    }
  }

  const xs = [...pos.values()].map((p) => p.x);
  const zs = [...pos.values()].map((p) => p.z);
  const minX = Math.min(...xs, 0);
  const maxX = Math.max(...xs, 0);
  const minZ = Math.min(...zs, 0);
  const maxZ = Math.max(...zs, 0);
  const boardW = maxX - minX + 5.4;
  const boardD = maxZ - minZ + 4.6;
  const cx = (minX + maxX) / 2;
  const cz = (minZ + maxZ) / 2;
  // every local coordinate below is already expressed relative to the layout
  // centroid, so the assembly stays centred on the bench origin

  /* ---------- board ---------- */
  group.add(pcbBoard(boardW, boardD, pal));

  const title = labelSprite(build.title.toUpperCase(), pal, {
    scale: 1.35,
    color: pal.labelText,
    bg: "rgba(4,12,16,0.72)",
    border: "#" + pal.silk.toString(16).padStart(6, "0"),
    font: `700 44px "Chakra Petch", "IBM Plex Mono", monospace`,
  });
  title.position.set(minX - cx + 1.2, 1.05, maxZ - cz + 1.75);
  group.add(title);

  /* ---------- parts ---------- */
  for (const n of build.nodes) {
    const p = pos.get(n.id)!;
    let part: Part;
    switch (n.kind) {
      case "IN":
        part = toggleSwitch(pal, { label: n.label, color: 0xff6076 });
        break;
      case "INBUS":
        part = dipBank(pal, n.bits ?? 4, n.label);
        break;
      case "CLK":
        part = clockModule(pal, n.label || "CLOCK");
        break;
      case "OUT":
        part = ledLamp(pal, n.label);
        break;
      case "OUTBUS":
        part = n.disp === "seven" ? sevenSegment(pal, n.label) : ledBar(pal, n.bits ?? 4, n.label);
        break;
      case "GATE": {
        const g = new THREE.Group();
        const pins = (n.in?.length ?? 2) > 2 ? 16 : 14;
        g.add(icChip(pal, { part: n.part ?? "7400", label: n.label, pins, w: 1.7, d: 1.15 }));
        const sym = labelSprite(`${n.label ?? ""}`, pal, { scale: 0.62, y: 1.05 });
        g.add(sym);
        part = { group: g, kind: "chip" };
        break;
      }
      case "FF": {
        const g = new THREE.Group();
        g.add(
          icChip(pal, {
            part: n.part ?? "7474",
            label: n.label,
            pins: (n.bits ?? 1) > 1 ? 20 : 14,
            w: (n.bits ?? 1) > 1 ? 2.3 : 1.8,
            d: 1.3,
          }),
        );
        g.add(labelSprite(n.label, pal, { scale: 0.66, y: 1.1 }));
        part = { group: g, kind: "chip" };
        break;
      }
      case "MEM": {
        part = memoryArray(pal, {
          part: n.part ?? "6264",
          label: n.label,
          words: n.mem!.words,
          width: n.mem!.width,
        });
        part.group.add(labelSprite(n.label, pal, { scale: 0.9, y: 1.55 }));
        break;
      }
    }
    part.group.position.set(p.x - cx, BOARD_Y, p.z - cz);
    part.group.userData.nodeId = n.id;
    part.group.userData.width = p.w;
    group.add(part.group);
    parts.set(n.id, part);

    // decoupling capacitor detail beside silicon
    if (n.kind === "GATE" || n.kind === "FF" || n.kind === "MEM") {
      const cap = new THREE.Mesh(
        new THREE.CylinderGeometry(0.13, 0.13, 0.3, 14),
        new THREE.MeshStandardMaterial({ color: 0x1b4a55, roughness: 0.45, metalness: 0.3 }),
      );
      cap.position.set(p.x - cx + p.w / 2 - 0.15, BOARD_Y + 0.15, p.z - cz - p.d / 2 - 0.25);
      group.add(cap);
      const stripe = new THREE.Mesh(
        new THREE.CylinderGeometry(0.132, 0.132, 0.06, 14),
        new THREE.MeshStandardMaterial({ color: pal.metal, roughness: 0.3, metalness: 0.85 }),
      );
      stripe.position.copy(cap.position).setY(BOARD_Y + 0.26);
      group.add(stripe);
    }
  }

  /* ---------- edges & routing ---------- */
  const edges: Edge[] = [];
  for (const n of build.nodes) {
    for (const { ref, clock, bus } of inputRefs(n)) {
      if (CONST(ref) !== null) continue;
      const { id: sid, bit } = parseRef(ref);
      const src = byId.get(sid);
      if (!src) continue;
      const srcW = widthOf(src);
      if (bit >= 0) {
        edges.push({ src: sid, srcBit: bit, dst: n.id, clock, bus });
      } else if (bus && srcW > 1) {
        for (let b = 0; b < srcW; b++) edges.push({ src: sid, srcBit: b, dst: n.id, clock, bus: true, bits: srcW });
      } else {
        edges.push({ src: sid, srcBit: 0, dst: n.id, clock, bus });
      }
    }
  }

  const outSlot = new Map<string, number>();
  const inSlot = new Map<string, number>();
  const outCount = new Map<string, number>();
  const inCount = new Map<string, number>();
  for (const e of edges) {
    outCount.set(e.src, (outCount.get(e.src) ?? 0) + 1);
    inCount.set(e.dst, (inCount.get(e.dst) ?? 0) + 1);
  }

  const anchorZ = (id: string, idx: number, total: number) => {
    const p = pos.get(id)!;
    const spread = Math.min(p.d * 0.72, 0.34 * Math.max(total, 1));
    if (total <= 1) return p.z - cz;
    return p.z - cz - spread / 2 + (spread / (total - 1)) * idx;
  };

  for (const e of edges) {
    const si = outSlot.get(e.src) ?? 0;
    outSlot.set(e.src, si + 1);
    const di = inSlot.get(e.dst) ?? 0;
    inSlot.set(e.dst, di + 1);
    const sp = pos.get(e.src)!;
    const dp = pos.get(e.dst)!;
    const x0 = sp.x - cx + sp.w / 2;
    const x1 = dp.x - cx - dp.w / 2;
    const z0 = anchorZ(e.src, si, outCount.get(e.src) ?? 1);
    const z1 = anchorZ(e.dst, di, inCount.get(e.dst) ?? 1);
    const mid = (x0 + x1) / 2;
    const lift = BOARD_Y + 0.07 + Math.min(0.34, Math.abs(z1 - z0) * 0.06);
    const pts = [
      new THREE.Vector3(x0 - 0.12, BOARD_Y + 0.05, z0),
      new THREE.Vector3(x0 + 0.22, lift, z0),
      new THREE.Vector3(mid, lift + 0.05, (z0 + z1) / 2),
      new THREE.Vector3(x1 - 0.22, lift, z1),
      new THREE.Vector3(x1 + 0.1, BOARD_Y + 0.05, z1),
    ];
    const w = wire(pal, pts, { clock: e.clock, bus: e.bus });
    w.group.userData.edge = e;
    group.add(w.group);
    wires.push(w);
  }

  /* ---------- bounds ---------- */
  const bounds = new THREE.Box3().setFromObject(group);
  if (!isFinite(bounds.min.x)) bounds.set(new THREE.Vector3(-4, 0, -4), new THREE.Vector3(4, 2, 4));

  /* ---------- per-frame binding ---------- */
  const update = (sim: LogicSim, t: number) => {
    for (const [id, part] of parts) {
      const n = byId.get(id)!;
      if (n.kind === "MEM") {
        const grid = sim.memoryGrid(id);
        let addr = 0;
        n.mem!.addr.forEach((r, i) => {
          const { id: rid, bit } = parseRef(r);
          const v = sim.vec(rid)[bit < 0 ? 0 : bit] ?? 0;
          if (v) addr |= 1 << i;
        });
        const marked = grid.map((row, r) => row.map((b) => (r === addr ? b + 2 : b)));
        part.set?.(marked as unknown as number[], t);
        continue;
      }
      if (n.kind === "FF") {
        part.set?.(sim.readState(id) as unknown as number[], t);
        continue;
      }
      const v: Vec = sim.vec(id);
      part.set?.(v.length > 1 ? (v as unknown as number[]) : v[0] ?? 0, t);
    }
    for (const w of wires) {
      const e = w.group.userData.edge as Edge;
      const v = sim.vec(e.src);
      w.set?.(v[e.srcBit] ?? 0, t + w.group.id * 0.13);
    }
  };

  return {
    group,
    parts,
    wires,
    size: { w: boardW, d: boardD },
    bounds,
    update,
    focusOf(id: string) {
      const p = pos.get(id);
      if (!p) return null;
      return new THREE.Vector3(p.x - cx, 0.4, p.z - cz);
    },
  };
}
