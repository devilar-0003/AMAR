/**
 * DigiLab Pro — kit.ts
 * ------------------------------------------------------------------
 * Reusable three.js "lab hardware" primitives. Every part exposes:
 *   group     – the Object3D to add to the bench
 *   hotspots  – meshes that answer to pointer clicks
 *   set(...)  – cheap per-frame state update (no allocation)
 * Materials/geometries are created per part so the engine can dispose a
 * whole build in one traverse without touching shared resources.
 * ------------------------------------------------------------------
 */
import * as THREE from "three";
import { RoundedBoxGeometry } from "three/examples/jsm/geometries/RoundedBoxGeometry.js";

export type ThemeName = "dark" | "light";

export interface Palette {
  bg: number;
  bgTop: number;
  fog: number;
  board: number;
  boardEdge: number;
  silk: number;
  chip: number;
  chipSide: number;
  pin: number;
  plastic: number;
  metal: number;
  label: string;
  labelDim: string;
  labelText: string;
  wireOff: number;
  wireOn: number;
  wireClk: number;
  ledOn: number;
  ledOff: number;
  hemi: number;
  key: number;
  rim: number;
}

export const PALETTE: Record<ThemeName, Palette> = {
  dark: {
    bg: 0x04090c,
    bgTop: 0x08171f,
    fog: 0x04090c,
    board: 0x0a2029,
    boardEdge: 0x123642,
    silk: 0x2ad6f2,
    chip: 0x0c1418,
    chipSide: 0x161f24,
    pin: 0xb9c9cf,
    plastic: 0x111c22,
    metal: 0x8ea3ab,
    label: "rgba(6,16,20,0.86)",
    labelDim: "rgba(120,200,220,0.55)",
    labelText: "#bdf3ff",
    wireOff: 0x1d3a44,
    wireOn: 0x46ffa8,
    wireClk: 0x21e5ff,
    ledOn: 0x5cffb0,
    ledOff: 0x1c3a34,
    hemi: 0x1d4b5a,
    key: 0xd8fbff,
    rim: 0x1fd6ff,
  },
  light: {
    bg: 0xe7eef0,
    bgTop: 0xf6fbfc,
    fog: 0xe7eef0,
    board: 0x1f6b5a,
    boardEdge: 0x155043,
    silk: 0xeafff8,
    chip: 0x1b2327,
    chipSide: 0x2b3439,
    pin: 0xc9d4d8,
    plastic: 0x2a3439,
    metal: 0x9aa9af,
    label: "rgba(255,255,255,0.9)",
    labelDim: "rgba(10,60,72,0.6)",
    labelText: "#06222a",
    wireOff: 0x9fb6bb,
    wireOn: 0x00b46e,
    wireClk: 0x0091a8,
    ledOn: 0x00d17a,
    ledOff: 0xb6c9c4,
    hemi: 0xcfe4ea,
    key: 0xffffff,
    rim: 0x7fd8e8,
  },
};

/* ------------------------------------------------------------------ */
/* canvas text helpers                                                 */
/* ------------------------------------------------------------------ */

export function textTexture(
  text: string,
  opts: {
    w?: number;
    h?: number;
    font?: string;
    color?: string;
    bg?: string;
    align?: CanvasTextAlign;
    pad?: number;
    border?: string;
    sub?: string;
  } = {},
): THREE.CanvasTexture {
  const w = opts.w ?? 256;
  const h = opts.h ?? 96;
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const g = c.getContext("2d")!;
  if (opts.bg) {
    g.fillStyle = opts.bg;
    roundRect(g, 1, 1, w - 2, h - 2, 10);
    g.fill();
    if (opts.border) {
      g.strokeStyle = opts.border;
      g.lineWidth = 2;
      roundRect(g, 2, 2, w - 4, h - 4, 9);
      g.stroke();
    }
  }
  g.fillStyle = opts.color ?? "#d8f6ff";
  g.textAlign = opts.align ?? "center";
  g.textBaseline = "middle";
  const x = opts.align === "left" ? (opts.pad ?? 14) : w / 2;
  g.font = opts.font ?? `600 ${Math.round(h * 0.42)}px "IBM Plex Mono", monospace`;
  if (opts.sub) {
    g.fillText(text, x, h * 0.36, w - (opts.pad ?? 14) * 2);
    g.font = `500 ${Math.round(h * 0.22)}px "IBM Plex Mono", monospace`;
    g.fillStyle = opts.border ?? "rgba(140,200,220,0.7)";
    g.fillText(opts.sub, x, h * 0.72, w - (opts.pad ?? 14) * 2);
  } else {
    g.fillText(text, x, h / 2, w - (opts.pad ?? 14) * 2);
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  t.needsUpdate = true;
  return t;
}

function roundRect(g: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  g.beginPath();
  g.moveTo(x + r, y);
  g.arcTo(x + w, y, x + w, y + h, r);
  g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r);
  g.arcTo(x, y, x + w, y, r);
  g.closePath();
}

export interface SpriteOpts {
  scale?: number;
  color?: string;
  bg?: string;
  border?: string;
  sub?: string;
  font?: string;
  y?: number;
}

export function labelSprite(text: string, pal: Palette, o: SpriteOpts = {}): THREE.Sprite {
  const tex = textTexture(text, {
    w: 300,
    h: 96,
    color: o.color ?? pal.labelText,
    bg: o.bg ?? pal.label,
    border: o.border ?? pal.labelDim,
    sub: o.sub,
    font: o.font,
  });
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false });
  const s = new THREE.Sprite(mat);
  const sc = o.scale ?? 1;
  s.scale.set(1.5 * sc, 0.48 * sc, 1);
  if (o.y !== undefined) s.position.y = o.y;
  s.renderOrder = 5;
  return s;
}

/* ------------------------------------------------------------------ */
/* part interface                                                      */
/* ------------------------------------------------------------------ */

export interface Part {
  group: THREE.Group;
  hotspots?: THREE.Object3D[];
  set?: (v: number | number[], t: number) => void;
  focus?: THREE.Vector3;
  kind: string;
}

/* ------------------------------------------------------------------ */
/* PCB bench board                                                     */
/* ------------------------------------------------------------------ */

export function pcbBoard(w: number, d: number, pal: Palette): THREE.Group {
  const g = new THREE.Group();
  const cw = 1024;
  const ch = Math.max(256, Math.round((cw * d) / w));
  const c = document.createElement("canvas");
  c.width = cw;
  c.height = ch;
  const x = c.getContext("2d")!;
  x.fillStyle = "#" + pal.board.toString(16).padStart(6, "0");
  x.fillRect(0, 0, cw, ch);
  // solder-mask mottling
  for (let i = 0; i < 900; i++) {
    x.fillStyle = `rgba(255,255,255,${Math.random() * 0.03})`;
    x.fillRect(Math.random() * cw, Math.random() * ch, 3, 3);
  }
  // silkscreen grid
  x.strokeStyle = "#" + pal.silk.toString(16).padStart(6, "0");
  x.globalAlpha = 0.16;
  x.lineWidth = 1;
  const step = cw / 46;
  for (let i = 0; i <= 46; i++) {
    x.beginPath();
    x.moveTo(i * step, 0);
    x.lineTo(i * step, ch);
    x.stroke();
  }
  for (let j = 0; j * step <= ch; j++) {
    x.beginPath();
    x.moveTo(0, j * step);
    x.lineTo(cw, j * step);
    x.stroke();
  }
  x.globalAlpha = 1;
  // decorative traces + vias
  x.globalAlpha = 0.22;
  x.lineWidth = 2.4;
  for (let i = 0; i < 22; i++) {
    const sx = Math.random() * cw;
    const sy = Math.random() * ch;
    x.beginPath();
    x.moveTo(sx, sy);
    x.lineTo(sx + (Math.random() - 0.5) * 220, sy);
    x.lineTo(sx + (Math.random() - 0.5) * 220, sy + (Math.random() - 0.5) * 160);
    x.stroke();
  }
  x.globalAlpha = 0.3;
  for (let i = 0; i < 90; i++) {
    const px = Math.random() * cw;
    const py = Math.random() * ch;
    x.beginPath();
    x.arc(px, py, 3.4, 0, Math.PI * 2);
    x.stroke();
  }
  x.globalAlpha = 1;
  // border silk
  x.strokeStyle = "#" + pal.silk.toString(16).padStart(6, "0");
  x.globalAlpha = 0.5;
  x.lineWidth = 5;
  x.strokeRect(14, 14, cw - 28, ch - 28);
  x.globalAlpha = 1;

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  const board = new THREE.Mesh(
    new RoundedBoxGeometry(w, 0.24, d, 3, 0.06),
    new THREE.MeshStandardMaterial({ map: tex, roughness: 0.72, metalness: 0.12 }),
  );
  board.position.y = -0.12;
  board.receiveShadow = true;
  g.add(board);

  const rim = new THREE.Mesh(
    new RoundedBoxGeometry(w + 0.5, 0.1, d + 0.5, 2, 0.05),
    new THREE.MeshStandardMaterial({ color: pal.boardEdge, roughness: 0.4, metalness: 0.55 }),
  );
  rim.position.y = -0.29;
  g.add(rim);

  // corner standoffs
  const studGeo = new THREE.CylinderGeometry(0.13, 0.16, 0.34, 14);
  const studMat = new THREE.MeshStandardMaterial({ color: pal.metal, roughness: 0.3, metalness: 0.9 });
  for (const sx of [-1, 1])
    for (const sz of [-1, 1]) {
      const s = new THREE.Mesh(studGeo, studMat);
      s.position.set((sx * (w + 0.2)) / 2, -0.34, (sz * (d + 0.2)) / 2);
      g.add(s);
    }
  return g;
}

/* ------------------------------------------------------------------ */
/* DIP integrated circuit                                              */
/* ------------------------------------------------------------------ */

export function icChip(
  pal: Palette,
  opts: {
    part: string;
    label?: string;
    pins?: number;
    w?: number;
    d?: number;
    h?: number;
    glow?: number;
  },
): THREE.Group {
  const pins = Math.max(8, opts.pins ?? 14);
  const w = opts.w ?? 1.9;
  const d = opts.d ?? 0.55 + pins * 0.075;
  const h = opts.h ?? 0.34;
  const g = new THREE.Group();

  const body = new THREE.Mesh(
    new RoundedBoxGeometry(w, h, d, 3, 0.045),
    new THREE.MeshStandardMaterial({ color: pal.chip, roughness: 0.55, metalness: 0.18 }),
  );
  body.position.y = h / 2 + 0.14;
  body.castShadow = true;
  g.add(body);

  // orientation notch
  const notch = new THREE.Mesh(
    new THREE.TorusGeometry(0.1, 0.022, 8, 18, Math.PI),
    new THREE.MeshStandardMaterial({ color: pal.chipSide, roughness: 0.5 }),
  );
  notch.rotation.x = Math.PI / 2;
  notch.rotation.z = Math.PI / 2;
  notch.position.set(-w / 2 + 0.16, h + 0.145, 0);
  g.add(notch);

  // laser-etched marking
  const top = new THREE.Mesh(
    new THREE.PlaneGeometry(w * 0.86, d * 0.62),
    new THREE.MeshBasicMaterial({
      map: textTexture(opts.part, {
        w: 512,
        h: 128,
        color: "#cfe9ef",
        sub: opts.label,
        font: `600 62px "IBM Plex Mono", monospace`,
      }),
      transparent: true,
      depthWrite: false,
    }),
  );
  top.rotation.x = -Math.PI / 2;
  top.position.y = h + 0.145;
  g.add(top);

  // pin 1 dot
  const dot = new THREE.Mesh(
    new THREE.CircleGeometry(0.045, 14),
    new THREE.MeshBasicMaterial({ color: pal.silk }),
  );
  dot.rotation.x = -Math.PI / 2;
  dot.position.set(-w / 2 + 0.17, h + 0.146, d * 0.24);
  g.add(dot);

  // leads
  const legGeo = new THREE.BoxGeometry(0.075, 0.16, 0.055);
  const legMat = new THREE.MeshStandardMaterial({ color: pal.pin, roughness: 0.25, metalness: 0.95 });
  const perSide = Math.ceil(pins / 2);
  const span = d * 0.82;
  for (let i = 0; i < perSide; i++) {
    const z = -span / 2 + (span / Math.max(1, perSide - 1)) * i;
    for (const s of [-1, 1]) {
      const leg = new THREE.Mesh(legGeo, legMat);
      leg.position.set(s * (w / 2 - 0.02), 0.07, z);
      g.add(leg);
      const foot = new THREE.Mesh(
        new THREE.BoxGeometry(0.075, 0.03, 0.16),
        legMat,
      );
      foot.position.set(s * (w / 2 + 0.05), 0.015, z);
      g.add(foot);
    }
  }
  return g;
}

/* ------------------------------------------------------------------ */
/* toggle switch (single bit)                                          */
/* ------------------------------------------------------------------ */

export function toggleSwitch(pal: Palette, opts: { label: string; color?: number } = { label: "" }): Part {
  const g = new THREE.Group();
  const base = new THREE.Mesh(
    new RoundedBoxGeometry(0.62, 0.2, 0.5, 3, 0.04),
    new THREE.MeshStandardMaterial({ color: pal.plastic, roughness: 0.5, metalness: 0.3 }),
  );
  base.position.y = 0.1;
  base.castShadow = true;
  g.add(base);

  const pivot = new THREE.Group();
  pivot.position.set(0, 0.2, 0);
  g.add(pivot);

  const lever = new THREE.Mesh(
    new THREE.CylinderGeometry(0.05, 0.062, 0.52, 14),
    new THREE.MeshStandardMaterial({ color: pal.metal, roughness: 0.22, metalness: 0.95 }),
  );
  lever.position.y = 0.24;
  lever.castShadow = true;
  pivot.add(lever);

  const knob = new THREE.Mesh(
    new THREE.SphereGeometry(0.085, 18, 14),
    new THREE.MeshStandardMaterial({
      color: opts.color ?? 0xff5f6d,
      roughness: 0.28,
      metalness: 0.25,
      emissive: opts.color ?? 0xff5f6d,
      emissiveIntensity: 0.25,
    }),
  );
  knob.position.y = 0.5;
  pivot.add(knob);
  pivot.rotation.x = -0.5;

  const ring = new THREE.Mesh(
    new THREE.TorusGeometry(0.2, 0.022, 8, 26),
    new THREE.MeshStandardMaterial({ color: pal.metal, roughness: 0.3, metalness: 0.9 }),
  );
  ring.rotation.x = Math.PI / 2;
  ring.position.y = 0.205;
  g.add(ring);

  // status pilot lamp on the base
  const pilotMat = new THREE.MeshStandardMaterial({
    color: pal.ledOff,
    emissive: pal.ledOn,
    emissiveIntensity: 0,
    roughness: 0.2,
  });
  const pilot = new THREE.Mesh(new THREE.SphereGeometry(0.055, 12, 10), pilotMat);
  pilot.position.set(0, 0.2, 0.2);
  g.add(pilot);

  const label = labelSprite(opts.label, pal, { scale: 0.62, y: 0.95 });
  g.add(label);

  return {
    group: g,
    kind: "switch",
    hotspots: [base, lever, knob, ring],
    set: (v) => {
      const on = Array.isArray(v) ? v[0] : v;
      const target = on ? 0.5 : -0.5;
      pivot.rotation.x += (target - pivot.rotation.x) * 0.35;
      pilotMat.emissiveIntensity += ((on ? 1.6 : 0) - pilotMat.emissiveIntensity) * 0.3;
      (knob.material as THREE.MeshStandardMaterial).emissiveIntensity = on ? 0.9 : 0.12;
    },
  };
}

/* ------------------------------------------------------------------ */
/* DIP switch bank (multi-bit)                                         */
/* ------------------------------------------------------------------ */

export function dipBank(pal: Palette, bits: number, label: string): Part {
  const g = new THREE.Group();
  const w = 0.42 * bits + 0.34;
  const body = new THREE.Mesh(
    new RoundedBoxGeometry(w, 0.34, 0.72, 3, 0.04),
    new THREE.MeshStandardMaterial({ color: 0x14313a, roughness: 0.6, metalness: 0.15 }),
  );
  body.position.y = 0.17;
  body.castShadow = true;
  g.add(body);

  const hotspots: THREE.Object3D[] = [body];
  const caps: THREE.Mesh[] = [];
  const lamps: THREE.MeshStandardMaterial[] = [];
  for (let i = 0; i < bits; i++) {
    const x = -w / 2 + 0.3 + i * 0.42;
    const cap = new THREE.Mesh(
      new RoundedBoxGeometry(0.26, 0.26, 0.16, 2, 0.03),
      new THREE.MeshStandardMaterial({ color: 0xf2f6f7, roughness: 0.4 }),
    );
    cap.position.set(x, 0.2, 0.16);
    cap.userData.bit = i;
    g.add(cap);
    caps.push(cap);
    hotspots.push(cap);

    const lampMat = new THREE.MeshStandardMaterial({
      color: pal.ledOff,
      emissive: pal.ledOn,
      emissiveIntensity: 0,
      roughness: 0.25,
    });
    lamps.push(lampMat);
    const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.05, 0.1), lampMat);
    lamp.position.set(x, 0.36, -0.16);
    g.add(lamp);

    const idx = new THREE.Mesh(
      new THREE.PlaneGeometry(0.24, 0.2),
      new THREE.MeshBasicMaterial({
        map: textTexture(String(i), { w: 64, h: 64, color: pal.labelText, font: `600 44px "IBM Plex Mono", monospace` }),
        transparent: true,
      }),
    );
    idx.rotation.x = -Math.PI / 2;
    idx.position.set(x, 0.345, 0.16);
    g.add(idx);
  }
  g.add(labelSprite(label, pal, { scale: 0.66, y: 0.98 }));

  return {
    group: g,
    kind: "bank",
    hotspots,
    set: (v) => {
      const arr = Array.isArray(v) ? v : [v];
      for (let i = 0; i < bits; i++) {
        const on = arr[i] ? 1 : 0;
        const cap = caps[i];
        const target = on ? 0.1 : -0.1;
        cap.position.z += (0.16 + target - cap.position.z) * 0.3;
        lamps[i].emissiveIntensity += ((on ? 1.5 : 0) - lamps[i].emissiveIntensity) * 0.3;
      }
    },
  };
}

/* ------------------------------------------------------------------ */
/* indicator lamp                                                      */
/* ------------------------------------------------------------------ */

export function ledLamp(pal: Palette, label: string, opts: { color?: number } = {}): Part {
  const g = new THREE.Group();
  const onColor = opts.color ?? pal.ledOn;
  const housing = new THREE.Mesh(
    new THREE.CylinderGeometry(0.2, 0.24, 0.14, 20),
    new THREE.MeshStandardMaterial({ color: pal.plastic, roughness: 0.5, metalness: 0.35 }),
  );
  housing.position.y = 0.07;
  g.add(housing);

  const mat = new THREE.MeshStandardMaterial({
    color: pal.ledOff,
    emissive: onColor,
    emissiveIntensity: 0.05,
    roughness: 0.15,
    metalness: 0,
    transparent: true,
    opacity: 0.95,
  });
  const dome = new THREE.Mesh(new THREE.SphereGeometry(0.16, 20, 14), mat);
  dome.position.y = 0.2;
  dome.scale.y = 0.82;
  g.add(dome);

  const light = new THREE.PointLight(onColor, 0, 2.6, 2);
  light.position.y = 0.34;
  g.add(light);

  const halo = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: glowTexture(onColor),
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      opacity: 0,
    }),
  );
  halo.scale.set(1.5, 1.5, 1);
  halo.position.y = 0.24;
  g.add(halo);

  g.add(labelSprite(label, pal, { scale: 0.6, y: 0.86 }));

  return {
    group: g,
    kind: "lamp",
    set: (v) => {
      const on = Array.isArray(v) ? v[0] : v;
      const target = on ? 1 : 0;
      mat.emissiveIntensity += ((on ? 2.4 : 0.05) - mat.emissiveIntensity) * 0.28;
      mat.color.lerp(new THREE.Color(on ? onColor : pal.ledOff), 0.3);
      light.intensity += ((on ? 2.4 : 0) - light.intensity) * 0.25;
      (halo.material as THREE.SpriteMaterial).opacity +=
        ((on ? 0.85 : 0) - (halo.material as THREE.SpriteMaterial).opacity) * 0.25;
      halo.scale.setScalar(1.2 + target * 0.5);
    },
  };
}

let glowCache: Record<string, THREE.Texture> = {};
export function glowTexture(color: number): THREE.Texture {
  const key = String(color);
  if (glowCache[key]) return glowCache[key];
  const c = document.createElement("canvas");
  c.width = c.height = 128;
  const g = c.getContext("2d")!;
  const grd = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  const hex = "#" + color.toString(16).padStart(6, "0");
  grd.addColorStop(0, hex);
  grd.addColorStop(0.25, hex + "aa");
  grd.addColorStop(1, hex + "00");
  g.fillStyle = grd;
  g.fillRect(0, 0, 128, 128);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  (t as unknown as { __shared: boolean }).__shared = true; // survives per-build disposal
  glowCache[key] = t;
  return t;
}

/* ------------------------------------------------------------------ */
/* LED bar / bus readout                                               */
/* ------------------------------------------------------------------ */

export function ledBar(pal: Palette, bits: number, label: string): Part {
  const g = new THREE.Group();
  const lamps: Part[] = [];
  for (let i = 0; i < bits; i++) {
    const l = ledLamp(pal, ``, { color: pal.ledOn });
    l.group.position.x = (i - (bits - 1) / 2) * 0.56;
    l.group.scale.setScalar(0.85);
    // drop each lamp's own label — the bar carries one shared caption
    for (const child of [...l.group.children]) if (child instanceof THREE.Sprite) l.group.remove(child);
    g.add(l.group);
    lamps.push(l);
    const idx = new THREE.Mesh(
      new THREE.PlaneGeometry(0.3, 0.24),
      new THREE.MeshBasicMaterial({
        map: textTexture(String(bits - 1 - i), { w: 64, h: 64, color: pal.labelText, font: `600 44px "IBM Plex Mono", monospace` }),
        transparent: true,
      }),
    );
    idx.rotation.x = -Math.PI / 2;
    idx.position.set((i - (bits - 1) / 2) * 0.56, 0.005, 0.42);
    g.add(idx);
  }
  g.add(labelSprite(label, pal, { scale: 0.66, y: 0.95 }));
  return {
    group: g,
    kind: "bar",
    set: (v) => {
      const arr = Array.isArray(v) ? v : [v];
      // arr is LSB-first, display MSB-first (left = MSB)
      lamps.forEach((l, i) => l.set?.(arr[bits - 1 - i] ?? 0, 0));
    },
  };
}

/* ------------------------------------------------------------------ */
/* seven segment display                                               */
/* ------------------------------------------------------------------ */

const SEG_MAP = ["abcdef", "bc", "abdeg", "abcdg", "fgbc", "afgcd", "afgcde", "abc", "abcdefg", "abcdfg"];

export function sevenSegment(pal: Palette, label: string): Part {
  const g = new THREE.Group();
  const housing = new THREE.Mesh(
    new RoundedBoxGeometry(1.5, 0.2, 1.9, 3, 0.04),
    new THREE.MeshStandardMaterial({ color: 0x0a1114, roughness: 0.35, metalness: 0.2 }),
  );
  housing.position.y = 0.1;
  g.add(housing);

  const segGeoH = new RoundedBoxGeometry(0.46, 0.05, 0.14, 2, 0.02);
  const segGeoV = new RoundedBoxGeometry(0.14, 0.05, 0.42, 2, 0.02);
  const mats: THREE.MeshStandardMaterial[] = [];
  const defs: [string, THREE.Vector3, boolean][] = [
    ["a", new THREE.Vector3(0, 0.21, -0.55), true],
    ["b", new THREE.Vector3(0.3, 0.21, -0.28), false],
    ["c", new THREE.Vector3(0.3, 0.21, 0.28), false],
    ["d", new THREE.Vector3(0, 0.21, 0.55), true],
    ["e", new THREE.Vector3(-0.3, 0.21, 0.28), false],
    ["f", new THREE.Vector3(-0.3, 0.21, -0.28), false],
    ["g", new THREE.Vector3(0, 0.21, 0), true],
  ];
  for (const [, pos, horiz] of defs) {
    const m = new THREE.MeshStandardMaterial({
      color: 0x2a0d10,
      emissive: 0xff4d3d,
      emissiveIntensity: 0.06,
      roughness: 0.3,
    });
    mats.push(m);
    const seg = new THREE.Mesh(horiz ? segGeoH : segGeoV, m);
    seg.position.copy(pos);
    g.add(seg);
  }
  const dp = new THREE.Mesh(
    new THREE.CylinderGeometry(0.05, 0.05, 0.05, 12),
    new THREE.MeshStandardMaterial({ color: 0x2a0d10, emissive: 0xff4d3d, emissiveIntensity: 0.05 }),
  );
  dp.position.set(0.45, 0.21, 0.55);
  g.add(dp);

  const readout = labelSprite("0", pal, { scale: 0.6, y: 1.0, sub: label });
  g.add(readout);

  return {
    group: g,
    kind: "seven",
    set: (v) => {
      const arr = Array.isArray(v) ? v : [v];
      let n = 0;
      for (let i = 0; i < arr.length && i < 4; i++) if (arr[i]) n |= 1 << i;
      const active = SEG_MAP[n % 10] ?? "";
      const names = "abcdefg";
      mats.forEach((m, i) => {
        const on = active.includes(names[i]);
        m.emissiveIntensity += ((on ? 2.6 : 0.05) - m.emissiveIntensity) * 0.3;
      });
      // swap only the canvas texture — the sprite material is reused so a
      // free-running counter cannot leak GPU resources
      if (readout.userData.last !== n) {
        readout.userData.last = n;
        const mat = readout.material as THREE.SpriteMaterial;
        mat.map?.dispose();
        mat.map = textTexture(String(n), {
          w: 300,
          h: 96,
          color: pal.labelText,
          bg: pal.label,
          border: pal.labelDim,
          sub: label,
        });
        mat.needsUpdate = true;
      }
    },
  };
}

/* ------------------------------------------------------------------ */
/* memory array chip (visible cells)                                   */
/* ------------------------------------------------------------------ */

export function memoryArray(pal: Palette, opts: { part: string; label: string; words: number; width: number }): Part {
  const g = new THREE.Group();
  const chip = icChip(pal, { part: opts.part, label: opts.label, pins: 24, w: 3.0, d: 1.9, h: 0.36 });
  g.add(chip);

  const cells: THREE.MeshStandardMaterial[] = [];
  const cols = opts.width;
  const rows = opts.words;
  const cw = 2.3 / cols;
  const chh = 1.2 / rows;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const m = new THREE.MeshStandardMaterial({
        color: pal.ledOff,
        emissive: pal.ledOn,
        emissiveIntensity: 0.04,
        roughness: 0.3,
      });
      cells.push(m);
      const cell = new THREE.Mesh(new RoundedBoxGeometry(cw * 0.74, 0.05, chh * 0.66, 1, 0.01), m);
      cell.position.set(-1.15 + cw * (c + 0.5), 0.53, -0.6 + chh * (r + 0.5));
      g.add(cell);
    }
  }
  const addrLamp = new THREE.Mesh(
    new THREE.PlaneGeometry(2.6, 0.3),
    new THREE.MeshBasicMaterial({
      map: textTexture("CELL ARRAY", { w: 300, h: 64, color: pal.labelText, font: `600 34px "IBM Plex Mono", monospace` }),
      transparent: true,
    }),
  );
  addrLamp.rotation.x = -Math.PI / 2;
  addrLamp.position.set(0, 0.535, 0.78);
  g.add(addrLamp);

  return {
    group: g,
    kind: "mem",
    set: (v) => {
      const grid = v as unknown as number[][];
      if (!Array.isArray(grid)) return;
      let k = 0;
      for (let r = 0; r < rows; r++)
        for (let c = 0; c < cols; c++) {
          const raw = grid[r]?.[c] ?? 0;
          const on = raw & 1;
          const selected = raw >= 2; // row currently addressed
          const m = cells[k++];
          if (!m) continue;
          const target = on ? 2.1 : selected ? 0.85 : 0.04;
          m.emissiveIntensity += (target - m.emissiveIntensity) * 0.25;
          if (selected) m.emissive.setHex(pal.wireClk);
          else m.emissive.setHex(on ? pal.ledOn : pal.wireClk);
        }
    },
  };
}

/* ------------------------------------------------------------------ */
/* clock generator module                                              */
/* ------------------------------------------------------------------ */

export function clockModule(pal: Palette, label = "CLOCK"): Part {
  const g = new THREE.Group();
  const body = new THREE.Mesh(
    new RoundedBoxGeometry(0.95, 0.4, 0.7, 3, 0.05),
    new THREE.MeshStandardMaterial({ color: pal.plastic, roughness: 0.4, metalness: 0.45 }),
  );
  body.position.y = 0.2;
  body.castShadow = true;
  g.add(body);

  const screenMat = new THREE.MeshStandardMaterial({
    color: 0x03171c,
    emissive: pal.wireClk,
    emissiveIntensity: 0.35,
    roughness: 0.2,
  });
  const screen = new THREE.Mesh(new RoundedBoxGeometry(0.72, 0.06, 0.4, 2, 0.02), screenMat);
  screen.position.y = 0.42;
  g.add(screen);

  const knob = new THREE.Mesh(
    new THREE.CylinderGeometry(0.12, 0.14, 0.1, 18),
    new THREE.MeshStandardMaterial({ color: pal.metal, roughness: 0.25, metalness: 0.95 }),
  );
  knob.position.set(0.3, 0.44, 0);
  g.add(knob);
  g.add(labelSprite(label, pal, { scale: 0.6, y: 0.98 }));

  return {
    group: g,
    kind: "clock",
    set: (v, t) => {
      const on = Array.isArray(v) ? v[0] : v;
      screenMat.emissiveIntensity = 0.25 + (on ? 2.2 : 0) + Math.sin(t * 4) * 0.06;
      knob.rotation.y = t * (on ? 2.2 : 0.2);
    },
  };
}

/* ------------------------------------------------------------------ */
/* wires                                                               */
/* ------------------------------------------------------------------ */

export function wirePath(points: THREE.Vector3[]): THREE.CatmullRomCurve3 {
  const curve = new THREE.CatmullRomCurve3(points, false, "catmullrom", 0.02);
  return curve;
}

export interface WirePart extends Part {
  curve: THREE.CatmullRomCurve3;
  material: THREE.MeshStandardMaterial;
  pulse: THREE.Mesh;
  length: number;
}

export function wire(pal: Palette, points: THREE.Vector3[], opts: { clock?: boolean; bus?: boolean } = {}): WirePart {
  const g = new THREE.Group();
  const curve = wirePath(points);
  const length = curve.getLength();
  const radius = opts.bus ? 0.06 : 0.042;
  const geo = new THREE.TubeGeometry(curve, Math.min(96, Math.max(18, Math.round(length * 12))), radius, 7, false);
  const mat = new THREE.MeshStandardMaterial({
    color: pal.wireOff,
    emissive: opts.clock ? pal.wireClk : pal.wireOn,
    emissiveIntensity: 0.05,
    roughness: 0.42,
    metalness: 0.25,
  });
  const mesh = new THREE.Mesh(geo, mat);
  g.add(mesh);

  const pulseMat = new THREE.MeshBasicMaterial({
    color: opts.clock ? pal.wireClk : pal.wireOn,
    transparent: true,
    opacity: 0,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
  });
  const pulse = new THREE.Mesh(new THREE.SphereGeometry(radius * 2.6, 10, 8), pulseMat);
  g.add(pulse);

  return {
    group: g,
    kind: "wire",
    curve,
    material: mat,
    pulse,
    length,
    set: (v, t) => {
      const on = Array.isArray(v) ? v[0] : v;
      mat.emissiveIntensity += ((on ? (opts.clock ? 1.5 : 1.25) : 0.04) - mat.emissiveIntensity) * 0.25;
      mat.color.lerp(new THREE.Color(on ? (opts.clock ? pal.wireClk : pal.wireOn) : pal.wireOff), 0.22);
      if (on) {
        const u = (t * 0.55) % 1;
        curve.getPointAt(u, pulse.position);
        pulse.position.y += 0.02;
        pulseMat.opacity += (0.95 - pulseMat.opacity) * 0.2;
      } else {
        pulseMat.opacity += (0 - pulseMat.opacity) * 0.2;
      }
    },
  };
}
