/**
 * DigiLab Pro — library.ts
 * ------------------------------------------------------------------
 * The component knowledge base. Every record pairs teaching content
 * (overview, theory, parts, learning) with a `buildId` that points at a
 * real netlist in sim/builds.ts — so nothing in the catalogue is fake:
 * if a record exists it simulates.
 * ------------------------------------------------------------------
 */
import { BUILDS } from "@/sim/builds";
import type { GateKind } from "@/sim/logic";

export type CategoryId = "logic-gates" | "combinational" | "sequential" | "memory" | "special";

export interface Category {
  id: CategoryId;
  name: string;
  blurb: string;
  accent: string;
  glyph: string;
}

export const CATEGORIES: Category[] = [
  {
    id: "logic-gates",
    name: "Logic Gates",
    blurb: "The atomic Boolean operators every digital system is built from.",
    accent: "#21e5ff",
    glyph: "◣",
  },
  {
    id: "combinational",
    name: "Combinational Circuits",
    blurb: "Outputs depend only on the present input combination.",
    accent: "#46ffa8",
    glyph: "⊞",
  },
  {
    id: "sequential",
    name: "Sequential Circuits",
    blurb: "Memory + feedback: outputs depend on inputs and history.",
    accent: "#ffc256",
    glyph: "⟳",
  },
  {
    id: "memory",
    name: "Memory Circuits",
    blurb: "Volatile and non-volatile arrays that store machine state.",
    accent: "#ff8fb1",
    glyph: "▤",
  },
  {
    id: "special",
    name: "Special Circuits",
    blurb: "Shifters, counters and error-detection building blocks.",
    accent: "#9be86a",
    glyph: "⇶",
  },
];

export type SymbolKind = "gate" | "ff" | "block" | "adder" | "memory";

export interface PartItem {
  name: string;
  qty: string;
  fn: string;
}

export interface ComponentDoc {
  id: string;
  name: string;
  short: string;
  category: CategoryId;
  tags: string[];
  symbol: SymbolKind;
  gate?: GateKind;
  ic: string;
  description: string;
  working: string;
  boolean: string;
  parts: PartItem[];
  applications: string[];
  objectives: string[];
  examples: { title: string; body: string }[];
  notes: string[];
  buildId: string;
  fidelity: "gate-level" | "behavioural";
  difficulty: 1 | 2 | 3;
}

const boardParts = (extra: PartItem[]): PartItem[] => [
  ...extra,
  { name: "Breadboard / PCB bench", qty: "1", fn: "Mechanical substrate carrying the whole circuit." },
  { name: "Jumper wires", qty: "as needed", fn: "Route logic nets between IC pins." },
  { name: "5 V regulated supply", qty: "1", fn: "VCC rail for TTL/CMOS logic levels." },
];

export const COMPONENTS: ComponentDoc[] = [
  /* ============================ 1. LOGIC GATES ============================ */
  {
    id: "and-gate",
    name: "AND Gate",
    short: "Output is HIGH only when every input is HIGH.",
    category: "logic-gates",
    tags: ["basic gate", "7408", "series logic", "boolean product"],
    symbol: "gate",
    gate: "AND",
    ic: "7408 · 7411",
    description:
      "The AND gate is the Boolean product operator. It performs logical conjunction: the output assumes the HIGH state (logic 1) if and only if all of its inputs are HIGH simultaneously. With n inputs there are 2ⁿ possible input combinations and exactly one of them produces a HIGH output.",
    working:
      "In hardware the inputs drive series-connected switching elements. In classic DTL two input diodes and a pull-up resistor form a diode-AND; in modern CMOS a series stack of p-channel devices connects the output to VDD only when every input is HIGH, while a parallel stack of n-channel devices pulls the output to GND as soon as any input goes LOW. Because the conducting path is a chain, the gate behaves like a set of series switches.",
    boolean: "Y = A · B  (also written Y = AB)",
    parts: boardParts([
      { name: "7408 quad 2-input AND IC", qty: "1", fn: "Houses four independent AND gates; this lab uses two." },
      { name: "SPST toggle switch", qty: "2", fn: "Drives inputs A and B between logic 0 and logic 1." },
      { name: "LED + 330 Ω resistor", qty: "1", fn: "Visualises the output level Y and its complement Y′." },
      { name: "7404 hex inverter", qty: "1", fn: "Generates the complementary output Y′ shown on the bench." },
    ]),
    applications: [
      "Enable / gating circuits — a signal passes only when ENABLE is asserted",
      "Address decoding inside microprocessor memory maps",
      "Safety interlocks: a machine runs only when guard closed AND reset pressed",
      "Comparator bit-slices and carry generation in adders",
    ],
    objectives: [
      "Verify the 2-input AND truth table by exhaustive input testing",
      "Relate series switching behaviour to the Boolean product",
      "Observe how an unused gate input must be tied HIGH, never left floating",
    ],
    examples: [
      {
        title: "Two-key safety interlock",
        body: "A press only cycles when both palm buttons are held: Y = LEFT · RIGHT. Releasing either button drops the output within one propagation delay.",
      },
      {
        title: "Gated clock",
        body: "CLK · ENABLE produces clock pulses only while a peripheral is selected — the exact technique used by the 4-bit register in this library.",
      },
    ],
    notes: [
      "TTL inputs left floating read as HIGH; CMOS inputs float to an undefined level and can oscillate — always terminate them.",
      "Cascading gates adds propagation delay (≈ 8–20 ns for 74-series TTL) per stage.",
      "AND is not universal on its own: it cannot produce inversion.",
    ],
    buildId: "and-gate",
    fidelity: "gate-level",
    difficulty: 1,
  },
  {
    id: "or-gate",
    name: "OR Gate",
    short: "Output is HIGH when at least one input is HIGH.",
    category: "logic-gates",
    tags: ["basic gate", "7432", "parallel logic", "boolean sum"],
    symbol: "gate",
    gate: "OR",
    ic: "7432 · 7427",
    description:
      "The OR gate implements logical disjunction (Boolean sum). Its output is HIGH whenever one or more inputs are HIGH, and LOW only when every input is LOW. It is the dual of the AND gate.",
    working:
      "Switching elements are placed in parallel across the output node. In CMOS the pull-up network is a parallel set of p-channel transistors (any HIGH input connects the output to VDD) while the pull-down network is a series chain of n-channel devices (all inputs LOW needed to pull the output to GND). Diode-OR realisations simply wire-OR the inputs through diodes into a pull-down resistor.",
    boolean: "Y = A + B",
    parts: boardParts([
      { name: "7432 quad 2-input OR IC", qty: "1", fn: "Provides the OR function and the final sum-of-products stage." },
      { name: "SPST toggle switch", qty: "2", fn: "Inputs A and B." },
      { name: "LED + 330 Ω resistor", qty: "1", fn: "Indicates Y and Y′." },
      { name: "7404 hex inverter", qty: "1", fn: "Complementary output buffer." },
    ]),
    applications: [
      "Interrupt / request merging — several sources share one service line",
      "Sum-of-products expression collection in PLAs",
      "Alarm aggregation: any sensor fault raises the alarm bus",
      "Carry propagation stages of ripple-carry adders",
    ],
    objectives: [
      "Confirm the inclusive nature of Boolean OR (1+1 = 1, not 2)",
      "Contrast the parallel pull-up network with AND's series network",
      "Build a 3-input OR from two 2-input gates and verify equivalence",
    ],
    examples: [
      {
        title: "Any-key wake-up",
        body: "Y = KEY1 + KEY2 + KEY3 wakes a sleeping controller from whichever button is pressed first.",
      },
      {
        title: "Full adder carry",
        body: "Cout = A·B + (A⊕B)·Cin — the OR gate merges the two carry-producing conditions.",
      },
    ],
    notes: [
      "Wired-OR is only legal with open-collector/open-drain outputs plus a pull-up resistor.",
      "OR alone cannot implement negation and is therefore not a universal gate.",
    ],
    buildId: "or-gate",
    fidelity: "gate-level",
    difficulty: 1,
  },
  {
    id: "not-gate",
    name: "NOT Gate (Inverter)",
    short: "The single-input complement operator.",
    category: "logic-gates",
    tags: ["inverter", "7404", "complement", "buffer"],
    symbol: "gate",
    gate: "NOT",
    ic: "7404",
    description:
      "The NOT gate (inverter) produces the logical complement of its single input. It is the only unary Boolean operator and the building block of every active-low signal, complementary output pair and oscillator.",
    working:
      "A CMOS inverter stacks one p-channel device over one n-channel device with the gates tied together. A LOW input turns the p-device on and the n-device off, connecting the output to VDD; a HIGH input does the opposite. The pair never conducts simultaneously in steady state, so static power draw is essentially leakage only. Six inverters form the 7404 package.",
    boolean: "Y = Ā  (Y = A′)",
    parts: boardParts([
      { name: "7404 hex inverter IC", qty: "1", fn: "Six independent NOT gates in one 14-pin DIP." },
      { name: "SPST toggle switch", qty: "1", fn: "Drives input A." },
      { name: "LED + 330 Ω resistor", qty: "1", fn: "Shows the complemented output." },
    ]),
    applications: [
      "Generating active-low control signals (C̄S̄, W̄Ē, R̄ĒS̄ĒT̄)",
      "Complementary drive for push-pull and half-bridge outputs",
      "Ring oscillators and crystal oscillator feedback",
      "Bus buffering and level restoration between logic families",
    ],
    objectives: [
      "Verify that a single input produces exactly two states and one transition",
      "Use an inverter to create the Q̄ output of a flip-flop",
      "Measure the effect of cascading an even number of inverters (identity buffer)",
    ],
    examples: [
      {
        title: "Borrow generation",
        body: "A half subtractor needs Ā·B; the inverter creates Ā before the AND stage.",
      },
      {
        title: "Johnson counter feedback",
        body: "Q̄ of the last stage is inverted and fed back to the first, giving 2n states instead of n.",
      },
    ],
    notes: [
      "Two cascaded inverters form a non-inverting buffer with improved drive strength.",
      "An odd number of inverters connected in a loop oscillates — the basis of the ring oscillator.",
    ],
    buildId: "not-gate",
    fidelity: "gate-level",
    difficulty: 1,
  },
  {
    id: "nand-gate",
    name: "NAND Gate",
    short: "The universal gate — any Boolean function can be built from it.",
    category: "logic-gates",
    tags: ["universal", "7400", "active low", "bubble output"],
    symbol: "gate",
    gate: "NAND",
    ic: "7400",
    description:
      "The NAND gate is the complement of AND: its output is LOW only when all inputs are HIGH. Together with the NOR gate it is functionally complete, meaning every other logic function — including NOT, AND, OR and XOR — can be constructed from NAND gates alone.",
    working:
      "CMOS NAND inverts the AND topology: the pull-down network is a series chain of n-channel devices (all inputs HIGH to pull the output LOW) while the pull-up network is parallel p-channel devices (any LOW input raises the output). The output bubble in the symbol denotes this active-low behaviour, which makes NAND the natural choice for chip-select and write-enable decoding.",
    boolean: "Y = (A · B)′ = Ā + B̄  (De Morgan)",
    parts: boardParts([
      { name: "7400 quad 2-input NAND IC", qty: "1", fn: "The classic universal-gate package." },
      { name: "SPST toggle switch", qty: "2", fn: "Inputs A and B." },
      { name: "LED + 330 Ω resistor", qty: "1", fn: "Shows Y and the re-inverted AND result Y′." },
      { name: "7404 hex inverter", qty: "1", fn: "Demonstrates Y′ = A·B via double negation." },
    ]),
    applications: [
      "Universal logic synthesis — entire CPUs have been built from NAND only",
      "Active-low chip select and strobe decoding",
      "SR latch from two cross-coupled NAND gates",
      "Synchronous counter carry look-ahead trees",
    ],
    objectives: [
      "Prove functional completeness by building NOT, AND and OR from NAND gates",
      "Apply De Morgan's theorem to read the bubble output as Ā + B̄",
      "Construct a bistable SR latch from cross-coupled NAND gates",
    ],
    examples: [
      {
        title: "NAND as NOT",
        body: "Tie both inputs together: Y = (A·A)′ = Ā. One package yields six inverters.",
      },
      {
        title: "NAND latch",
        body: "Two cross-coupled NAND gates hold a bit; S̄=0 forces Q=1, R̄=0 forces Q=0, both high holds state.",
      },
    ],
    notes: [
      "NAND is typically the fastest and cheapest gate in a given logic family.",
      "Active-low decoding means the asserted state is the LOW one — mind the bubbles on schematics.",
    ],
    buildId: "nand-gate",
    fidelity: "gate-level",
    difficulty: 1,
  },
  {
    id: "nor-gate",
    name: "NOR Gate",
    short: "Universal gate with an active-low output; basis of the SR latch.",
    category: "logic-gates",
    tags: ["universal", "7402", "latch", "active low"],
    symbol: "gate",
    gate: "NOR",
    ic: "7402",
    description:
      "The NOR gate is the complement of OR: the output is HIGH only when every input is LOW. Like NAND it is functionally complete, and cross-coupled NOR gates form the canonical SR latch.",
    working:
      "CMOS NOR mirrors the OR structure with inverted output: a series pull-up network of p-channel devices (all inputs LOW to raise the output) and a parallel pull-down network of n-channel devices (any HIGH input pulls the output LOW). Cross-coupling two NOR gates creates positive feedback — each output drives the input of the other — which stores one bit of state.",
    boolean: "Y = (A + B)′ = Ā · B̄  (De Morgan)",
    parts: boardParts([
      { name: "7402 quad 2-input NOR IC", qty: "1", fn: "Provides NOR functions and the SR-latch pair." },
      { name: "SPST toggle switch", qty: "2", fn: "Inputs A and B." },
      { name: "LED + 330 Ω resistor", qty: "1", fn: "Indicates Y and Y′." },
      { name: "7404 hex inverter", qty: "1", fn: "Re-inverts the output to demonstrate A + B." },
    ]),
    applications: [
      "SR latch (two cross-coupled NOR gates)",
      "Active-high output decoding and 'none of the above' detectors",
      "Address decode with a single asserted-line output",
      "Asterisk: NOR-based RTL was the technology of the Apollo guidance computer",
    ],
    objectives: [
      "Verify the NOR truth table and its De Morgan equivalent Ā·B̄",
      "Build and test a cross-coupled NOR SR latch including the forbidden state",
      "Explain why positive feedback creates memory",
    ],
    examples: [
      {
        title: "NOR SR latch",
        body: "Q = (S + Q′)′ and Q′ = (R + Q)′. S=R=1 forces both outputs LOW — the forbidden condition.",
      },
      {
        title: "All-clear detector",
        body: "Y = (F1 + F2 + F3)′ goes HIGH only when no fault flag is set, a handy 'system healthy' signal.",
      },
    ],
    notes: [
      "NOR gates scale poorly with input count in CMOS because the series p-network grows resistive.",
      "In a latch, avoid S = R = 1: the outputs become equal and the next state is unpredictable.",
    ],
    buildId: "nor-gate",
    fidelity: "gate-level",
    difficulty: 1,
  },
  {
    id: "xor-gate",
    name: "XOR Gate",
    short: "Odd-function detector — HIGH when the inputs differ.",
    category: "logic-gates",
    tags: ["exclusive or", "7486", "parity", "sum bit"],
    symbol: "gate",
    gate: "XOR",
    ic: "7486",
    description:
      "The XOR (exclusive OR) gate outputs HIGH when an odd number of its inputs are HIGH. For two inputs this means 'the inputs differ'. XOR is the arithmetic heart of binary addition, parity generation and pseudo-random sequence generation.",
    working:
      "A two-input CMOS XOR is usually built as a transmission-gate multiplexer or as a four-NAND-gate network. The key algebraic property is self-inverse: A ⊕ A = 0 and A ⊕ 0 = A, so XORing twice with the same value cancels out — the basis of parity checking and of simple stream ciphers.",
    boolean: "Y = A ⊕ B = Ā·B + A·B̄",
    parts: boardParts([
      { name: "7486 quad 2-input XOR IC", qty: "1", fn: "Exclusive-OR functions; two gates used per lab." },
      { name: "SPST toggle switch", qty: "2", fn: "Inputs A and B." },
      { name: "LED + 330 Ω resistor", qty: "1", fn: "Shows Y and Y′ (the XNOR result)." },
      { name: "7404 hex inverter", qty: "1", fn: "Produces the complement output Y′." },
    ]),
    applications: [
      "SUM output of half and full adders",
      "Parity generation and checking for error detection",
      "Controlled inversion / two's-complement units",
      "LFSR pseudo-random number generation and CRC engines",
    ],
    objectives: [
      "Verify the 'difference detector' behaviour of a 2-input XOR",
      "Extend XOR to more than two inputs and confirm odd-parity semantics",
      "Build a half adder from one XOR and one AND gate",
    ],
    examples: [
      {
        title: "Half adder",
        body: "SUM = A ⊕ B and CARRY = A·B — two gates produce a 1-bit adder.",
      },
      {
        title: "Parity tree",
        body: "Cascading XOR gates gives P = D0 ⊕ D1 ⊕ D2 ⊕ D3, the even-parity bit of a 4-bit word.",
      },
    ],
    notes: [
      "Multi-input XOR means 'odd number of ones', not the two-input 'exactly one' rule.",
      "XOR gates are slower than AND/OR in most families — keep adder carry paths AND/OR based.",
    ],
    buildId: "xor-gate",
    fidelity: "gate-level",
    difficulty: 1,
  },
  {
    id: "xnor-gate",
    name: "XNOR Gate",
    short: "Equivalence detector — HIGH when the inputs match.",
    category: "logic-gates",
    tags: ["exclusive nor", "74266", "comparator", "coincidence"],
    symbol: "gate",
    gate: "XNOR",
    ic: "74266",
    description:
      "The XNOR gate is the complement of XOR and is often called the equivalence or coincidence gate. Its output is HIGH when both inputs are at the same level, making it the natural 1-bit comparator.",
    working:
      "Internally an XNOR is an XOR followed by an inverter (or a transmission-gate multiplexer with swapped select lines). Cascading XNOR gates produces an 'even parity' function: the output is HIGH when an even number of inputs are HIGH — the exact inverse of the XOR tree.",
    boolean: "Y = (A ⊕ B)′ = A·B + Ā·B̄ = A ⊙ B",
    parts: boardParts([
      { name: "74266 quad 2-input XNOR IC", qty: "1", fn: "Equivalence gates with open-drain outputs on some variants." },
      { name: "SPST toggle switch", qty: "2", fn: "Inputs A and B." },
      { name: "LED + 330 Ω resistor", qty: "1", fn: "Indicates Y and Y′." },
      { name: "7404 hex inverter", qty: "1", fn: "Shows the XOR complement Y′." },
    ]),
    applications: [
      "Bit-wise equality comparison in magnitude comparators",
      "Even-parity checking of received data words",
      "Synchronous demodulation and phase comparison",
      "Error-correcting syndrome computation",
    ],
    objectives: [
      "Verify the equivalence truth table of XNOR",
      "Use XNOR gates to build the A = B output of a magnitude comparator",
      "Contrast even-parity (XNOR tree) with odd-parity (XOR tree)",
    ],
    examples: [
      {
        title: "2-bit equality",
        body: "EQ = (A1 ⊙ B1) · (A0 ⊙ B0) — the comparator in this library uses exactly this structure.",
      },
      {
        title: "Even parity check",
        body: "E = (D0 ⊕ D1 ⊕ D2 ⊕ D3 ⊕ P)′ is HIGH when the received word carries correct even parity.",
      },
    ],
    notes: [
      "74266 outputs are open-drain on many variants and require a pull-up resistor.",
      "Do not mix XOR and XNOR in the same parity tree without recomputing the polarity.",
    ],
    buildId: "xnor-gate",
    fidelity: "gate-level",
    difficulty: 1,
  },

  /* ======================= 2. COMBINATIONAL CIRCUITS ======================= */
  {
    id: "half-adder",
    name: "Half Adder",
    short: "Adds two single bits, producing SUM and CARRY.",
    category: "combinational",
    tags: ["arithmetic", "xor", "and", "sum carry"],
    symbol: "adder",
    ic: "7486 + 7408",
    description:
      "A half adder is the simplest arithmetic circuit: it adds two 1-bit operands A and B and produces a 2-bit result — SUM (the least significant bit) and CARRY (the most significant bit). It is called 'half' because it cannot accept a carry-in from a previous stage.",
    working:
      "Binary addition of two bits has four cases: 0+0=00, 0+1=01, 1+0=01, 1+1=10. The SUM column is exactly the XOR function (odd number of ones) and the CARRY column is exactly the AND function (both ones). Two gates therefore implement the whole circuit, with no feedback and no memory.",
    boolean: "SUM = A ⊕ B ;  CARRY = A · B",
    parts: boardParts([
      { name: "7486 quad XOR IC", qty: "1", fn: "Generates the SUM output." },
      { name: "7408 quad AND IC", qty: "1", fn: "Generates the CARRY output." },
      { name: "SPST toggle switch", qty: "2", fn: "Operands A and B." },
      { name: "LED indicators", qty: "2", fn: "SUM and CARRY readout." },
    ]),
    applications: [
      "The first stage of many adder trees",
      "Parity generators (SUM is the parity bit, CARRY flags a double set)",
      "Teaching vehicle for deriving logic from a truth table",
    ],
    objectives: [
      "Derive both output expressions from the 4-row truth table using Karnaugh maps",
      "Build and test the circuit with XOR and AND gates",
      "Explain precisely why a half adder cannot be cascaded without a full adder",
    ],
    examples: [
      { title: "1 + 1", body: "A=1, B=1 → SUM=0, CARRY=1, i.e. binary 10 = decimal 2." },
      { title: "0 + 1", body: "A=0, B=1 → SUM=1, CARRY=0, i.e. binary 01 = decimal 1." },
    ],
    notes: [
      "No carry-in input exists — chaining half adders will not produce a multi-bit adder.",
      "SUM and CARRY are computed in parallel; the critical path is a single gate delay.",
    ],
    buildId: "half-adder",
    fidelity: "gate-level",
    difficulty: 1,
  },
  {
    id: "full-adder",
    name: "Full Adder",
    short: "Adds three bits: A, B and a carry-in.",
    category: "combinational",
    tags: ["arithmetic", "carry", "ripple", "alu"],
    symbol: "adder",
    ic: "7483 · 74283",
    description:
      "A full adder adds three 1-bit values — operands A and B plus a carry-in Cin — producing SUM and Cout. Because it accepts a carry, full adders can be chained to any width, forming ripple-carry adders and the arithmetic core of an ALU.",
    working:
      "The circuit is built from two half adders plus an OR gate. The first XOR forms A⊕B; a second XOR folds in Cin to make SUM. Carry is produced by two conditions: A·B (both operands set) or (A⊕B)·Cin (one operand set and a carry arrives). The OR gate merges them. The carry chain, not the sum path, is the critical timing path.",
    boolean: "SUM = A ⊕ B ⊕ Cin ;  Cout = A·B + Cin·(A ⊕ B)",
    parts: boardParts([
      { name: "7486 quad XOR IC", qty: "1", fn: "Two XOR gates produce the intermediate and final sums." },
      { name: "7408 quad AND IC", qty: "1", fn: "Two AND gates form the carry conditions." },
      { name: "7432 quad OR IC", qty: "1", fn: "Merges the two carry terms into Cout." },
      { name: "SPST toggle switch", qty: "3", fn: "A, B and Cin." },
      { name: "LED indicators", qty: "2", fn: "SUM and Cout." },
    ]),
    applications: [
      "Ripple-carry and carry-look-ahead adders of any bit width",
      "ALU add/subtract stage (with XOR-controlled operand inversion)",
      "Population-count / bit-count circuits",
      "Address incrementers inside counters and program counters",
    ],
    objectives: [
      "Build the full adder from nine gates and verify all eight input combinations",
      "Show that two half adders plus an OR gate are logically equivalent",
      "Cascade four full adders into a 4-bit ripple-carry adder and observe carry propagation delay",
    ],
    examples: [
      { title: "1 + 1 + 1", body: "A=B=Cin=1 → SUM=1, Cout=1 → binary 11 = decimal 3." },
      { title: "Chaining", body: "Cout of bit i drives Cin of bit i+1; an n-bit adder settles after roughly n carry delays." },
    ],
    notes: [
      "Ripple carry is simple but slow: delay grows linearly with word length. Carry-look-ahead replaces the ripple with parallel generate/propagate logic.",
      "Overflow in signed arithmetic is detected separately from Cout (XOR of the last two carry bits).",
    ],
    buildId: "full-adder",
    fidelity: "gate-level",
    difficulty: 2,
  },
  {
    id: "half-subtractor",
    name: "Half Subtractor",
    short: "Subtracts two bits, producing DIFFERENCE and BORROW.",
    category: "combinational",
    tags: ["arithmetic", "subtraction", "borrow"],
    symbol: "adder",
    ic: "7486 + 7404 + 7408",
    description:
      "The half subtractor computes A − B for two single bits, yielding DIFFERENCE and BORROW. Like the half adder it has no input for a borrow from a previous stage, so it can only serve as the least-significant stage of a subtractor chain.",
    working:
      "The difference column of the subtraction truth table is again the XOR function. Borrow is asserted only when A=0 and B=1 — that is Ā·B — so one inverter and one AND gate complete the circuit. The asymmetry between A and B (unlike the adder) comes from the Ā term.",
    boolean: "DIFF = A ⊕ B ;  BORROW = Ā · B",
    parts: boardParts([
      { name: "7486 quad XOR IC", qty: "1", fn: "Produces DIFFERENCE." },
      { name: "7404 hex inverter", qty: "1", fn: "Creates Ā for the borrow term." },
      { name: "7408 quad AND IC", qty: "1", fn: "Produces BORROW = Ā·B." },
      { name: "SPST toggle switch", qty: "2", fn: "Minuend A and subtrahend B." },
      { name: "LED indicators", qty: "2", fn: "DIFF and BORROW." },
    ]),
    applications: [
      "Least-significant stage of a ripple-borrow subtractor",
      "Magnitude comparison helpers",
      "Two's-complement arithmetic teaching blocks",
    ],
    objectives: [
      "Derive DIFF and BORROW from the 4-row truth table",
      "Explain why the circuit is not symmetric in A and B",
      "Compare the half subtractor with the half adder gate by gate",
    ],
    examples: [
      { title: "0 − 1", body: "A=0, B=1 → DIFF=1, BORROW=1 (result −1 requires a borrow from the next stage)." },
      { title: "1 − 1", body: "A=1, B=1 → DIFF=0, BORROW=0." },
    ],
    notes: [
      "Subtraction is normally performed by adding the two's complement, so dedicated subtractors are rare inside modern ALUs.",
      "No borrow-in input exists; use a full subtractor for multi-bit chains.",
    ],
    buildId: "half-subtractor",
    fidelity: "gate-level",
    difficulty: 1,
  },
  {
    id: "full-subtractor",
    name: "Full Subtractor",
    short: "Subtracts three bits: A, B and a borrow-in.",
    category: "combinational",
    tags: ["arithmetic", "borrow chain", "subtraction"],
    symbol: "adder",
    ic: "7486 + 7404 + 7408 + 7432",
    description:
      "The full subtractor computes A − B − Bin and outputs DIFFERENCE and Bout. Accepting a borrow-in makes it chainable into ripple-borrow subtractors of arbitrary width.",
    working:
      "Two XOR stages fold the three inputs together for DIFFERENCE = A ⊕ B ⊕ Bin, identical in form to the full adder sum. The borrow is asserted when Ā·B is true, or when the intermediate (A⊕B) is 0 while Bin is 1; an OR gate merges these two conditions. The structure mirrors the full adder with the AND/OR borrow network replacing the carry network.",
    boolean: "DIFF = A ⊕ B ⊕ Bin ;  Bout = Ā·B + Bin·(A ⊕ B)′",
    parts: boardParts([
      { name: "7486 quad XOR IC", qty: "1", fn: "Two XOR gates form DIFFERENCE." },
      { name: "7404 hex inverter", qty: "1", fn: "Creates Ā and (A⊕B)′." },
      { name: "7408 quad AND IC", qty: "1", fn: "Two AND gates build the borrow terms." },
      { name: "7432 quad OR IC", qty: "1", fn: "Merges the borrow terms into Bout." },
      { name: "SPST toggle switch", qty: "3", fn: "A, B and Bin." },
      { name: "LED indicators", qty: "2", fn: "DIFF and Bout." },
    ]),
    applications: [
      "Multi-bit ripple-borrow subtractors",
      "Digit-serial arithmetic units",
      "Difference engines in DSP teaching kits",
    ],
    objectives: [
      "Verify all eight combinations against the derived expressions",
      "Compare gate counts between the full adder and full subtractor",
      "Cascade two full subtractors and observe borrow propagation",
    ],
    examples: [
      { title: "0 − 1 − 1", body: "A=0, B=1, Bin=1 → DIFF=0, Bout=1 (equivalent to −2)." },
      { title: "1 − 0 − 1", body: "A=1, B=0, Bin=1 → DIFF=0, Bout=0." },
    ],
    notes: [
      "Borrow chains are slower than carry chains in most implementations because of the extra inversion.",
      "Adding the two's complement of B with a full adder is usually faster than a subtractor chain.",
    ],
    buildId: "full-subtractor",
    fidelity: "gate-level",
    difficulty: 2,
  },
  {
    id: "multiplexer",
    name: "Multiplexer (4:1)",
    short: "Selects one of several data lines onto a single output.",
    category: "combinational",
    tags: ["mux", "data selector", "74153", "any-function generator"],
    symbol: "block",
    ic: "74153 · 74151",
    description:
      "A multiplexer (MUX, data selector) routes one of 2ⁿ data inputs to a single output under control of n select lines. The 4:1 MUX modelled here uses S1 and S0 to choose between D0, D1, D2 and D3.",
    working:
      "Each data input is ANDed with the unique minterm of the select lines that addresses it, and all products are ORed together. Only one AND gate can be enabled at a time, so exactly one data value reaches the output. Transmission-gate implementations replace the AND-OR array with pass transistors gated by the decoded select signals.",
    boolean: "Y = D0·S̄1·S̄0 + D1·S̄1·S0 + D2·S1·S̄0 + D3·S1·S0",
    parts: boardParts([
      { name: "7411 triple 3-input AND IC", qty: "1", fn: "Forms the four select·data product terms (with a second package)." },
      { name: "7427 triple 3-input OR IC", qty: "1", fn: "Collects the first three product terms." },
      { name: "7432 quad OR IC", qty: "1", fn: "Final output OR stage." },
      { name: "7404 hex inverter", qty: "1", fn: "Generates S̄1 and S̄0." },
      { name: "SPST toggle switch", qty: "6", fn: "S1, S0 and data inputs D0–D3." },
      { name: "LED indicator", qty: "1", fn: "Selected output Y." },
    ]),
    applications: [
      "Data routing in buses, ALUs and register files",
      "Implementing any Boolean function of n+1 variables with a 2ⁿ:1 MUX",
      "Parallel-to-serial conversion",
      "Video/audio source switching and scan-chain selection",
    ],
    objectives: [
      "Verify the select-to-output mapping for all 64 input combinations",
      "Implement a 3-input logic function using only the 4:1 MUX",
      "Measure the propagation delay from select change to output change",
    ],
    examples: [
      {
        title: "Function generator",
        body: "Tie D0..D3 to 0, 1, C and C̄ with selects A, B and the MUX realises any 3-variable function.",
      },
      {
        title: "2:1 MUX from a 4:1",
        body: "Ignore S0 and use D0/D2 as the two data inputs with S1 as select.",
      },
    ],
    notes: [
      "Unused data inputs should be tied to a defined level, never left floating.",
      "Glitches can appear on Y while the select lines transition — add a strobe or register the output for clean timing.",
    ],
    buildId: "multiplexer",
    fidelity: "gate-level",
    difficulty: 2,
  },
  {
    id: "demultiplexer",
    name: "Demultiplexer (1:4)",
    short: "Routes a single input to one of many selected outputs.",
    category: "combinational",
    tags: ["demux", "distributor", "decoder", "74155"],
    symbol: "block",
    ic: "74155 · 74138",
    description:
      "A demultiplexer performs the inverse of the MUX: one data input is steered to exactly one of 2ⁿ outputs according to the select lines. All other outputs remain inactive.",
    working:
      "Each output is the AND of the data input with one unique minterm of the select lines. Because only one minterm can be true at a time, the input value appears on exactly one output. Structurally it is a decoder with the enable pin used as the data input.",
    boolean: "Y0 = I·S̄1·S̄0,  Y1 = I·S̄1·S0,  Y2 = I·S1·S̄0,  Y3 = I·S1·S0",
    parts: boardParts([
      { name: "7411 triple 3-input AND IC", qty: "2", fn: "Build the four I·minterm output terms." },
      { name: "7404 hex inverter", qty: "1", fn: "Generates S̄1 and S̄0." },
      { name: "SPST toggle switch", qty: "3", fn: "Data input I and selects S1, S0." },
      { name: "LED indicators", qty: "4", fn: "Outputs Y0–Y3." },
    ]),
    applications: [
      "Serial-to-parallel conversion",
      "Memory and peripheral address decoding (one chip selected at a time)",
      "Distribution of a signal to time-slot destinations",
      "LED/bar-graph drivers with decoded addressing",
    ],
    objectives: [
      "Confirm that exactly one output is HIGH for each select code when I=1",
      "Demonstrate that a demultiplexer is a decoder with a data enable",
      "Build a 1-to-8 demultiplexer by combining two 1-to-4 devices",
    ],
    examples: [
      { title: "Serial to parallel", body: "A time-multiplexed stream plus a 2-bit counter on the selects rebuilds four parallel outputs." },
      { title: "Device select", body: "Y0..Y3 act as chip-select lines for four peripherals sharing one data bus." },
    ],
    notes: [
      "If I is LOW all outputs are LOW — the data input doubles as a global enable.",
      "Output hazards appear during select transitions; register the selects in synchronous designs.",
    ],
    buildId: "demultiplexer",
    fidelity: "gate-level",
    difficulty: 2,
  },
  {
    id: "encoder",
    name: "Encoder (4-to-2)",
    short: "Converts an active input line into its binary code.",
    category: "combinational",
    tags: ["encoder", "code converter", "priority", "74148"],
    symbol: "block",
    ic: "74148 (priority)",
    description:
      "An encoder has 2ⁿ input lines and n output lines. When exactly one input is active, the outputs present the binary index of that line — the inverse operation of a decoder.",
    working:
      "Each output bit is the OR of every input line whose index has that bit set: A1 = D2 + D3 and A0 = D1 + D3 for a 4-to-2 encoder. A VALID flag is produced by ORing all inputs. When more than one input can be active simultaneously a priority encoder is required, which resolves conflicts by always reporting the highest-numbered active line.",
    boolean: "A1 = D2 + D3 ;  A0 = D1 + D3 ;  VALID = D0 + D1 + D2 + D3",
    parts: boardParts([
      { name: "7432 quad OR IC", qty: "1", fn: "Forms A1, A0 and the VALID flag." },
      { name: "SPST toggle switch", qty: "4", fn: "Input lines D0–D3." },
      { name: "LED indicators", qty: "3", fn: "A1, A0 and VALID." },
    ]),
    applications: [
      "Keyboard and keypad scanning (key position → binary code)",
      "Interrupt priority resolution in CPU interfaces",
      "Position sensors with many discrete outputs",
      "Reducing many status lines into a compact code for telemetry",
    ],
    objectives: [
      "Verify the 4-to-2 encoding for all sixteen input patterns",
      "Identify the ambiguous outputs when two inputs are active at once",
      "Extend the design to a priority encoder with a 'none active' flag",
    ],
    examples: [
      { title: "Keypad read", body: "Row/column decoders plus an encoder convert 16 switches into a 4-bit key code." },
      { title: "Priority variant", body: "The 74148 encodes the highest active line of eight and outputs the complement plus EO/GS flags." },
    ],
    notes: [
      "A plain encoder assumes one-hot input; simultaneous activation produces an incorrect code.",
      "Real encoders output active-low codes (74148) — remember to invert when interfacing.",
    ],
    buildId: "encoder",
    fidelity: "gate-level",
    difficulty: 2,
  },
  {
    id: "decoder",
    name: "Decoder (2-to-4)",
    short: "Turns a binary code into one asserted output line.",
    category: "combinational",
    tags: ["decoder", "address decode", "74139", "enable"],
    symbol: "block",
    ic: "74139 · 74138 · 7447",
    description:
      "A decoder converts an n-bit binary input code into 2ⁿ mutually exclusive output lines, of which exactly one is asserted. The ENABLE input gates the whole device: when it is inactive every output is deselected.",
    working:
      "Each output is the AND of the enable with one minterm of the address inputs (using inverted or true forms as required). Because minterms are mutually exclusive, only one AND gate can conduct at a time. Seven-segment display drivers such as the 7447 are decoders with additional segment-shaping logic.",
    boolean: "Y0 = EN·Ā1·Ā0, Y1 = EN·Ā1·A0, Y2 = EN·A1·Ā0, Y3 = EN·A1·A0",
    parts: boardParts([
      { name: "7411 triple 3-input AND IC", qty: "2", fn: "Build the four enable·minterm outputs." },
      { name: "7404 hex inverter", qty: "1", fn: "Creates Ā1 and Ā0." },
      { name: "SPST toggle switch", qty: "3", fn: "A1, A0 and EN." },
      { name: "LED indicators", qty: "4", fn: "Outputs Y0–Y3." },
    ]),
    applications: [
      "Memory chip-select generation from address bits",
      "Driving one of many peripherals, LEDs or relays",
      "Demultiplexing when the enable pin is used as data",
      "BCD-to-seven-segment conversion (7447/7448)",
    ],
    objectives: [
      "Verify that exactly one output is asserted for each address with EN high",
      "Observe that EN low forces all outputs inactive",
      "Cascade 2-to-4 decoders into a 3-to-8 or 4-to-16 decoder using the enable tree",
    ],
    examples: [
      { title: "Memory map", body: "A15..A12 decoded into four chip-select lines gives four 1 KB windows in a 64 KB address space." },
      { title: "One-hot control", body: "A 2-bit mode register decoded to four enables selects one datapath at a time." },
    ],
    notes: [
      "Commercial decoders usually have active-low outputs (74138); the minterm structure is identical, just inverted.",
      "Address decoding glitches during transitions can cause spurious chip selects — synchronise with a phase clock.",
    ],
    buildId: "decoder",
    fidelity: "gate-level",
    difficulty: 1,
  },
  {
    id: "comparator",
    name: "Comparator (2-bit)",
    short: "Compares two binary numbers: A>B, A=B or A<B.",
    category: "combinational",
    tags: ["magnitude", "7485", "comparison", "xnor"],
    symbol: "block",
    ic: "7485",
    description:
      "A magnitude comparator examines two binary words and asserts exactly one of three outputs: A greater than B, A equal to B, or A less than B. The 2-bit version modelled here compares A1A0 with B1B0.",
    working:
      "Equality requires every bit pair to match, so EQ is the AND of all XNOR results. For A>B the most significant differing bit must favour A: either A1=1 and B1=0, or the high bits match and A0=1 while B0=0. A<B is the mirror image. The 7485 extends this with cascading inputs so several chips can compare wider words.",
    boolean:
      "EQ = (A1⊙B1)·(A0⊙B0) ;  GT = A1·B̄1 + (A1⊙B1)·A0·B̄0 ;  LT = Ā1·B1 + (A1⊙B1)·Ā0·B0",
    parts: boardParts([
      { name: "74266 quad XNOR IC", qty: "1", fn: "Bit-wise equality detection." },
      { name: "7404 hex inverter", qty: "1", fn: "Generates Ā1, Ā0, B̄1, B̄0." },
      { name: "7408 quad AND IC", qty: "2", fn: "Product terms for GT, LT and EQ." },
      { name: "7432 quad OR IC", qty: "1", fn: "Combines the GT and LT terms." },
      { name: "SPST toggle switch", qty: "4", fn: "A1, A0, B1, B0." },
      { name: "LED indicators", qty: "3", fn: "A>B, A=B, A<B." },
    ]),
    applications: [
      "ALU condition codes (zero, greater, less flags)",
      "Window comparators and limit detection in instrumentation",
      "Password / keycode verification",
      "Sorting networks and search engines",
    ],
    objectives: [
      "Verify all sixteen comparison cases against the truth table",
      "Derive the GT and LT expressions from a Karnaugh map",
      "Cascade two 2-bit comparators into a 4-bit comparator",
    ],
    examples: [
      { title: "A=2, B=1", body: "A1A0=10, B1B0=01 → GT asserted, EQ and LT low." },
      { title: "A=3, B=3", body: "11 vs 11 → EQ asserted; every XNOR is high." },
    ],
    notes: [
      "Exactly one output is HIGH for any input pair — the three outputs are mutually exclusive.",
      "Cascading inputs on the 7485 must be tied to the 'equal' state (GT=0, EQ=1, LT=0) when unused.",
    ],
    buildId: "comparator",
    fidelity: "gate-level",
    difficulty: 3,
  },

  /* ======================== 3. SEQUENTIAL CIRCUITS ======================== */
  {
    id: "sr-flipflop",
    name: "SR Flip-Flop",
    short: "The simplest bistable: set, reset or hold one bit.",
    category: "sequential",
    tags: ["latch", "bistable", "7402", "set reset"],
    symbol: "ff",
    ic: "7402 (latch) · 7474 style",
    description:
      "The SR (Set-Reset) flip-flop is the most elementary memory element. A pulse on S stores a 1, a pulse on R stores a 0, and with both inactive the device holds its previous state. The clocked version shown here changes state only on a rising clock edge.",
    working:
      "Two cross-coupled NOR (or NAND) gates form a positive-feedback loop with two stable states. Gating the inputs with the clock produces the synchronous SR flip-flop: while the clock is high the S and R inputs propagate around the loop; when it returns low the loop freezes, storing the last value. The condition S = R = 1 is forbidden because it drives both outputs to the same level, leaving the next state undefined.",
    boolean: "Q(t+1) = S + R̄·Q(t)   with the constraint S·R = 0",
    parts: boardParts([
      { name: "7402 quad NOR IC", qty: "1", fn: "Cross-coupled pair forming the bistable latch." },
      { name: "7408 quad AND IC", qty: "1", fn: "Clock gating of S and R inputs." },
      { name: "7404 hex inverter", qty: "1", fn: "Buffers the complementary output Q̄." },
      { name: "SPST toggle switch", qty: "2", fn: "S and R inputs." },
      { name: "Clock module", qty: "1", fn: "Manual pulse or free-running square wave." },
      { name: "LED indicators", qty: "2", fn: "Q and Q̄." },
    ]),
    applications: [
      "Switch debouncing — one clean transition per mechanical press",
      "Start/stop latch control for motors and pumps",
      "Flag and status bit storage inside control units",
      "The storage cell inside larger SRAM arrays",
    ],
    objectives: [
      "Verify the characteristic table for all four S/R combinations",
      "Demonstrate the hold state and the forbidden S=R=1 condition",
      "Explain how positive feedback creates two stable states",
    ],
    examples: [
      { title: "Debounced switch", body: "A bouncing contact toggles S then R; the latch outputs one clean edge regardless of contact chatter." },
      { title: "Motor start/stop", body: "START sets the latch, STOP resets it; the contactor holds after either button is released." },
    ],
    notes: [
      "S = R = 1 makes Q = Q̄ = 0 in a NOR latch — both outputs equal, which breaks the complementary contract.",
      "Level-sensitive latches are transparent while enabled; edge-triggered flip-flops are not. Do not use the words interchangeably.",
    ],
    buildId: "sr-flipflop",
    fidelity: "gate-level",
    difficulty: 2,
  },
  {
    id: "jk-flipflop",
    name: "JK Flip-Flop",
    short: "Race-free SR flip-flop with a toggle mode.",
    category: "sequential",
    tags: ["7476", "master slave", "toggle", "universal ff"],
    symbol: "ff",
    ic: "7476 · 74112",
    description:
      "The JK flip-flop removes the forbidden state of the SR device. J sets, K resets, both low holds, and both high toggles the output on every clock edge — making the JK flip-flop the most versatile of the four basic types.",
    working:
      "A master-slave arrangement (or edge-triggered gating) samples J and K on the clock edge. The toggle mode is produced by feeding Q̄ back into the gating network so that J=K=1 always inverts the stored state. Because the feedback resolves what would have been the SR forbidden condition, no input combination is illegal.",
    boolean: "Q(t+1) = J·Q̄(t) + K̄·Q(t)",
    parts: boardParts([
      { name: "7476 dual JK flip-flop IC", qty: "1", fn: "Two negative-edge JK flip-flops with preset and clear." },
      { name: "7404 hex inverter", qty: "1", fn: "Buffers Q̄ for the indicator and feedback." },
      { name: "SPST toggle switch", qty: "2", fn: "J and K inputs." },
      { name: "Clock module", qty: "1", fn: "Supplies the triggering edge." },
      { name: "LED indicators", qty: "2", fn: "Q and Q̄." },
    ]),
    applications: [
      "Frequency division by two (J=K=1) and ripple counters",
      "Universal flip-flop when other types are unavailable",
      "Control state machines with set/reset/toggle requirements",
      "Shift register stages with recirculation",
    ],
    objectives: [
      "Verify all eight rows of the characteristic table (J, K × Q)",
      "Observe the divide-by-two behaviour with J=K=1",
      "Explain how the JK structure avoids the SR race condition",
    ],
    examples: [
      { title: "Toggle mode", body: "With J=K=1 a 1 kHz clock yields a 500 Hz square wave on Q — the basis of every binary counter stage." },
      { title: "T flip-flop conversion", body: "Tie J=K=T and the device becomes a T flip-flop." },
    ],
    notes: [
      "Master-slave JK devices are level-sensitive during the clock high phase — keep J/K stable until the edge.",
      "Asynchronous preset/clear override the clock and must be de-asserted during normal operation.",
    ],
    buildId: "jk-flipflop",
    fidelity: "gate-level",
    difficulty: 2,
  },
  {
    id: "d-flipflop",
    name: "D Flip-Flop",
    short: "Delay element — captures D on the clock edge.",
    category: "sequential",
    tags: ["7474", "delay", "register cell", "edge triggered"],
    symbol: "ff",
    ic: "7474 · 74175",
    description:
      "The D (delay) flip-flop copies its single data input to the output on the active clock edge. It is the fundamental storage element of registers, pipeline stages, shift registers and synchronous state machines.",
    working:
      "Internally a D flip-flop is an SR cell with the input arranged so that S = D and R = D̄ — making the forbidden state impossible. Two latches in a master-slave chain, or an edge-detector feeding a latch, ensure the output changes only at the clock edge and is otherwise isolated from the input.",
    boolean: "Q(t+1) = D",
    parts: boardParts([
      { name: "7474 dual D flip-flop IC", qty: "1", fn: "Two positive-edge D flip-flops with preset and clear." },
      { name: "7404 hex inverter", qty: "1", fn: "Produces Q̄ and the internal D̄." },
      { name: "SPST toggle switch", qty: "1", fn: "Data input D." },
      { name: "Clock module", qty: "1", fn: "Positive-edge trigger source." },
      { name: "LED indicators", qty: "2", fn: "Q and Q̄." },
    ]),
    applications: [
      "Registers, pipeline stages and retiming buffers",
      "Shift register cells and serial-to-parallel converters",
      "Frequency division and jitter cleanup (re-clocking)",
      "Synchronous state machine memory",
    ],
    objectives: [
      "Verify Q(t+1) = D for both current states",
      "Demonstrate that D changes between clock edges have no effect",
      "Measure setup and hold time requirements conceptually",
    ],
    examples: [
      { title: "Re-clocking", body: "Passing a noisy asynchronous signal through a D flip-flop aligns it to the system clock domain." },
      { title: "Divide by two", body: "Connect Q̄ back to D and each clock edge toggles the output: fout = fclk / 2." },
    ],
    notes: [
      "Setup time is the minimum interval D must be stable before the edge; hold time is the minimum after it.",
      "Metastability occurs when D changes during the sampling window — use two flip-flops to synchronise asynchronous inputs.",
    ],
    buildId: "d-flipflop",
    fidelity: "gate-level",
    difficulty: 1,
  },
  {
    id: "t-flipflop",
    name: "T Flip-Flop",
    short: "Toggle flip-flop — the counter's basic cell.",
    category: "sequential",
    tags: ["toggle", "divide by two", "counter", "7476 derived"],
    symbol: "ff",
    ic: "7474 / 7476 configured",
    description:
      "The T (toggle) flip-flop changes state on every clock edge while T is HIGH and holds while T is LOW. With T permanently HIGH it divides the clock frequency by two, which is exactly what a binary counter stage must do.",
    working:
      "A T flip-flop is realised by feeding Q̄ back to the D input of a D flip-flop through a gate controlled by T, or by tying J = K = T on a JK flip-flop. On the active edge the feedback path presents the complement of the current state whenever T is asserted, so the cell toggles.",
    boolean: "Q(t+1) = T ⊕ Q(t)",
    parts: boardParts([
      { name: "7474 dual D flip-flop IC", qty: "1", fn: "Configured as a toggle cell with feedback." },
      { name: "7486 quad XOR IC", qty: "1", fn: "Implements T ⊕ Q feedback." },
      { name: "7404 hex inverter", qty: "1", fn: "Q̄ output buffer." },
      { name: "SPST toggle switch", qty: "1", fn: "Toggle control input T." },
      { name: "Clock module", qty: "1", fn: "Trigger source." },
      { name: "LED indicators", qty: "2", fn: "Q and Q̄." },
    ]),
    applications: [
      "Binary ripple and synchronous counters",
      "Clock frequency division (÷2 per stage)",
      "Square-wave generation from a crystal clock",
      "State toggling in control FSMs (e.g. run/stop latching)",
    ],
    objectives: [
      "Verify the two-row characteristic table for T = 0 and T = 1",
      "Confirm the divide-by-two output frequency with the free-running clock",
      "Derive the T flip-flop from a JK flip-flop by tying J = K = T",
    ],
    examples: [
      { title: "÷8 divider", body: "Three cascaded T flip-flops with T=1 divide an 8 MHz clock down to 1 MHz." },
      { title: "Counter stage", body: "In a synchronous counter, Ti = Q0·Q1···Qi-1 makes stage i toggle only when all lower stages are 1." },
    ],
    notes: [
      "There is no single commercial 'T flip-flop' IC — the function is always derived from D or JK devices.",
      "With T held high the output is a perfect 50 % duty square wave only if the clock duty cycle is stable.",
    ],
    buildId: "t-flipflop",
    fidelity: "gate-level",
    difficulty: 2,
  },
  {
    id: "registers",
    name: "Registers (4-bit parallel)",
    short: "Stores a multi-bit word on a gated clock edge.",
    category: "sequential",
    tags: ["74175", "parallel in parallel out", "storage", "pipelining"],
    symbol: "block",
    ic: "74175 · 74273 · 74374",
    description:
      "A register is a bank of flip-flops sharing a common clock, storing an n-bit word. The 4-bit parallel-in parallel-out register modelled here loads D0–D3 when LOAD ENABLE is high and a clock edge arrives, and holds the value otherwise.",
    working:
      "Each bit is stored in one D flip-flop. The load enable is ANDed with the clock so that flip-flop clocks only pulse when a load is requested — clock gating. A master clear asynchronously forces all stages to zero. Because all stages share the same gated clock, the whole word updates simultaneously on one edge.",
    boolean: "Q_i(t+1) = LD · D_i  (hold when LD = 0)",
    parts: boardParts([
      { name: "74175 quad D flip-flop IC", qty: "1", fn: "Four synchronous D stages with common clock and clear." },
      { name: "7408 quad AND IC", qty: "1", fn: "Clock gating with the LOAD ENABLE line." },
      { name: "4-position DIP switch", qty: "1", fn: "Parallel data input D0–D3." },
      { name: "SPST toggle switch", qty: "2", fn: "LOAD ENABLE and MASTER CLEAR." },
      { name: "Clock module", qty: "1", fn: "Load trigger." },
      { name: "Seven-segment display + LED bar", qty: "1", fn: "Stored word shown as hex and binary." },
    ]),
    applications: [
      "CPU general-purpose registers and pipeline stage storage",
      "Buffering data between asynchronous bus domains",
      "Temporary operand holding inside ALUs",
      "Configuration registers of peripherals",
    ],
    objectives: [
      "Load four different words and verify each is held between clock pulses",
      "Show that LD = 0 blocks the clock so the register ignores new data",
      "Demonstrate the effect of MASTER CLEAR mid-operation",
    ],
    examples: [
      { title: "Pipeline stage", body: "Placing a register between two combinational blocks shortens the critical path and raises the maximum clock frequency." },
      { title: "Bus hold", body: "Capturing a value on the shared bus the moment it is valid, then releasing the bus for other devices." },
    ],
    notes: [
      "Clock gating must be glitch-free; use an integrated clock-gating cell rather than a bare AND gate in ASIC/FPGA flows.",
      "Three-state outputs (74374) are required when several registers share one bus.",
    ],
    buildId: "registers",
    fidelity: "gate-level",
    difficulty: 2,
  },
  {
    id: "counters",
    name: "Counters (mod-16 synchronous)",
    short: "Counts clock edges using toggle flip-flops.",
    category: "sequential",
    tags: ["74161", "synchronous", "mod-n", "divide"],
    symbol: "block",
    ic: "74161 · 74160 · 74193",
    description:
      "A counter is a register that advances through a defined sequence on every clock pulse. The 4-bit synchronous counter here counts 0000 → 1111 → 0000 (mod-16), with a count enable and an asynchronous reset.",
    working:
      "Each stage is a T flip-flop. Stage 0 toggles on every enabled clock; stage i toggles only when all lower stages are high, so its toggle input is Ti = EN·Q0·Q1···Qi−1. Because every stage sees the same clock, all bits change simultaneously — that is what makes the counter synchronous and free of the ripple delays of asynchronous designs.",
    boolean: "T0 = EN ;  Ti = EN · Q0 · Q1 · … · Q(i−1)",
    parts: boardParts([
      { name: "74161 4-bit synchronous counter IC", qty: "1", fn: "Four toggle stages with parallel load, enable and clear." },
      { name: "7408 / 7411 AND ICs", qty: "2", fn: "Generate the toggle terms T1, T2 and T3." },
      { name: "SPST toggle switch", qty: "2", fn: "RESET and COUNT ENABLE." },
      { name: "Clock module", qty: "1", fn: "Counting pulse source, manual or free-running." },
      { name: "Seven-segment display", qty: "1", fn: "Decimal readout of the current count." },
    ]),
    applications: [
      "Frequency division and timing generation",
      "Address generation for memory and ADC scanning",
      "Event counting in instrumentation and tachometers",
      "Sequencing control states in finite state machines",
    ],
    objectives: [
      "Verify the full 16-state count sequence with the sequence table",
      "Show the effect of COUNT ENABLE = 0 (the count freezes)",
      "Compare synchronous counting with ripple counting and their timing differences",
    ],
    examples: [
      { title: "Mod-10 counter", body: "Detect 1010 with a NAND gate and asynchronously clear the counter to build a decimal (BCD) counter." },
      { title: "1 Hz from 32.768 kHz", body: "Fifteen divide-by-two stages turn a watch crystal frequency into a one-second tick." },
    ],
    notes: [
      "Synchronous counters have a constant critical path (one stage delay plus the toggle AND tree), so they scale far better than ripple counters.",
      "Terminal count / carry outputs allow several chips to cascade into wider counters.",
    ],
    buildId: "counters",
    fidelity: "gate-level",
    difficulty: 3,
  },

  /* ========================== 4. MEMORY CIRCUITS ========================== */
  {
    id: "ram",
    name: "RAM (16 × 4)",
    short: "Random-access read/write memory array.",
    category: "memory",
    tags: ["volatile", "read write", "2114", "main memory"],
    symbol: "memory",
    ic: "2114 · 6116",
    description:
      "Random Access Memory stores words at numeric addresses and allows both reading and writing in any order with equal speed. This model provides a 16-word × 4-bit array with a 4-bit address bus, 4-bit data-in bus, write enable and synchronous write.",
    working:
      "The address decoder selects one word line; the selected cells connect to the bit lines through pass transistors. With WRITE ENABLE low the array drives the data-out bus (read). With WRITE ENABLE high, the incoming data is driven onto the bit lines and stored on the rising clock edge. 'Random access' means access time is independent of the address.",
    boolean: "READ:  DOUT = MEM[ADDR] when WE = 0 ;  WRITE:  MEM[ADDR] ← DIN on CLK↑ when WE = 1",
    parts: boardParts([
      { name: "2114 1K×4 static RAM IC", qty: "1", fn: "The storage array, decoders and sense amplifiers." },
      { name: "4-position DIP switch", qty: "2", fn: "Address bus A0–A3 and data-in bus D0–D3." },
      { name: "SPST toggle switch", qty: "1", fn: "WRITE ENABLE." },
      { name: "Clock module", qty: "1", fn: "Synchronises the write operation." },
      { name: "LED bar", qty: "1", fn: "Data-out bus readback." },
    ]),
    applications: [
      "Main memory and scratchpad RAM in computers",
      "Frame buffers and sample storage in audio/video systems",
      "Look-up tables that must change at run time",
      "Stacks, heaps and queue storage",
    ],
    objectives: [
      "Write four different words to four addresses, then read them back",
      "Confirm that data is retained only while power is applied (volatility)",
      "Observe that a write requires a clock edge while a read is immediate",
    ],
    examples: [
      { title: "Store and recall", body: "Set ADDR=0011, DIN=1010, WE=1, pulse the clock; then set WE=0 and ADDR=0011 to read 1010 back on DOUT." },
      { title: "Look-up table", body: "Pre-filling RAM with computed values replaces slow run-time arithmetic in waveform generators." },
    ],
    notes: [
      "RAM is volatile: contents vanish when power is removed.",
      "Reading a word never destroys it; only a write modifies the array.",
      "This lab models the array behaviourally — a real cell is six transistors per bit.",
    ],
    buildId: "ram",
    fidelity: "behavioural",
    difficulty: 2,
  },
  {
    id: "rom",
    name: "ROM (16 × 4)",
    short: "Non-volatile read-only memory pre-programmed with Gray code.",
    category: "memory",
    tags: ["non-volatile", "2716", "lookup", "microcode"],
    symbol: "memory",
    ic: "2716 · 2732 · 27C256",
    description:
      "Read Only Memory holds data written once at manufacture (or by a programmer) and retains it without power. The device modelled here is a 16-word × 4-bit ROM programmed with the 4-bit Gray code sequence, a classic character-generator use case.",
    working:
      "Address lines are decoded to select one of the stored words; the output drivers present that word combinationally, with no clock and no write path. Because there is no write circuitry, access is purely a decode-plus-read operation. In mask ROM the bit pattern is formed by the presence or absence of transistors at each cell intersection.",
    boolean: "DOUT = ROM[ADDR]   (no write operation exists)",
    parts: boardParts([
      { name: "2716 2K×8 EPROM IC", qty: "1", fn: "The programmed storage matrix and output buffers." },
      { name: "4-position DIP switch", qty: "1", fn: "Address bus A0–A3." },
      { name: "LED bar", qty: "1", fn: "Data-out readback of the programmed word." },
    ]),
    applications: [
      "Firmware and boot code storage",
      "Character generators for displays and printers",
      "Combinational logic replacement — any truth table can be burned into a ROM",
      "Waveform and font look-up tables",
    ],
    objectives: [
      "Sweep all sixteen addresses and record the stored words",
      "Verify that the contents match the 4-bit Gray code sequence",
      "Explain why a ROM can replace an arbitrary combinational logic network",
    ],
    examples: [
      { title: "Gray code table", body: "Address 0→0000, 1→0001, 2→0011, 3→0010, 4→0110 … each successive word differs by exactly one bit." },
      { title: "Arbitrary function", body: "A 256×4 ROM implements any four Boolean functions of eight variables with no gates at all." },
    ],
    notes: [
      "ROM is non-volatile — data survives power-off indefinitely.",
      "EPROM variants are erased with UV light; EEPROM and flash are erased electrically.",
      "Output access time (typically 45–200 ns) is slower than SRAM.",
    ],
    buildId: "rom",
    fidelity: "behavioural",
    difficulty: 1,
  },
  {
    id: "sram",
    name: "SRAM (8 × 4)",
    short: "Static RAM — fast, volatile, no refresh required.",
    category: "memory",
    tags: ["static", "6264", "cache", "fast"],
    symbol: "memory",
    ic: "6264 · 6116 · 62256",
    description:
      "Static RAM keeps each bit in a bistable flip-flop cell, so data persists as long as power is applied and no refresh circuitry is needed. This model is an 8-word × 4-bit SRAM with chip select, write enable and synchronous write.",
    working:
      "Each cell is a six-transistor cross-coupled inverter pair with two access transistors. The address decoder asserts one word line, connecting the selected cells to the bit lines. Reading senses the small voltage difference on the bit-line pair; writing drives the bit lines hard enough to overpower the cell's feedback and flip it. The chip select must be active for either operation.",
    boolean: "CS=1, WE=0 → DOUT = MEM[ADDR] ;  CS=1, WE=1 → MEM[ADDR] ← DIN on CLK↑",
    parts: boardParts([
      { name: "6264 8K×8 static RAM IC", qty: "1", fn: "Flip-flop cell array, decoders and I/O buffers." },
      { name: "3-position DIP switch", qty: "1", fn: "Address bus A0–A2." },
      { name: "4-position DIP switch", qty: "1", fn: "Data-in bus D0–D3." },
      { name: "SPST toggle switch", qty: "2", fn: "CHIP SELECT and WRITE ENABLE." },
      { name: "Clock module", qty: "1", fn: "Synchronises writes in this lab model." },
      { name: "LED bar", qty: "1", fn: "Data-out readback." },
    ]),
    applications: [
      "CPU level-1/level-2/level-3 caches",
      "Register files and fast scratchpad memory in DSPs",
      "Buffers where low latency matters more than density",
      "Battery-backed non-volatile RAM modules",
    ],
    objectives: [
      "Verify that CHIP SELECT low disables the device (outputs high-impedance in real parts)",
      "Store and recall several words without any refresh operation",
      "Contrast cell complexity, speed and density against DRAM",
    ],
    examples: [
      { title: "Cache hit", body: "A tag match reads the SRAM line in 1–3 ns, avoiding a 60 ns main-memory access." },
      { title: "Dual-port use", body: "Two SRAMs with separate ports let a CPU and a DMA engine work simultaneously." },
    ],
    notes: [
      "Six transistors per bit make SRAM roughly 100× less dense than DRAM, but far faster.",
      "No refresh means simpler control logic and deterministic access timing.",
      "Standby current is low but non-zero; battery-backed designs rely on this mode.",
    ],
    buildId: "sram",
    fidelity: "behavioural",
    difficulty: 2,
  },
  {
    id: "dram",
    name: "DRAM (8 × 4)",
    short: "Dynamic RAM — dense capacitor storage that must be refreshed.",
    category: "memory",
    tags: ["dynamic", "4116", "refresh", "capacitor"],
    symbol: "memory",
    ic: "4116 · 4164 · SDRAM",
    description:
      "Dynamic RAM stores each bit as charge on a tiny capacitor, giving very high density at the cost of leakage. This model is an 8-word × 4-bit array that visibly loses its contents a few seconds after a write unless the REFRESH line is pulsed.",
    working:
      "One transistor and one capacitor form each cell. A word line opens the access transistor and the charge flows onto a bit line, where a sense amplifier detects and restores it. Because the capacitor leaks, every row must be read and rewritten (refreshed) typically every 2–64 ms. Refresh is performed by a counter stepping through all row addresses while normal access is suspended or interleaved.",
    boolean: "WRITE: MEM[ADDR] ← DIN on CLK↑ when WE=1 ;  REFRESH: rising edge of REF restores all cells",
    parts: boardParts([
      { name: "4116 16K×1 dynamic RAM IC", qty: "1", fn: "Capacitor cell array with on-chip sense amplifiers." },
      { name: "3-position DIP switch", qty: "1", fn: "Address bus A0–A2 (multiplexed RAS/CAS in real parts)." },
      { name: "4-position DIP switch", qty: "1", fn: "Data-in bus D0–D3." },
      { name: "SPST toggle switch", qty: "3", fn: "WRITE ENABLE, CHIP SELECT and REFRESH." },
      { name: "Clock module", qty: "1", fn: "Synchronises writes." },
      { name: "LED bar + leak warning", qty: "1", fn: "Data-out readback; warning when cells have leaked." },
    ]),
    applications: [
      "Main system memory in every personal computer and server",
      "Graphics memory (GDDR) and video frame stores",
      "High-density embedded memory in SoCs",
      "Any application where cost per bit dominates",
    ],
    objectives: [
      "Write a word, wait for the decay interval and observe the contents vanish",
      "Pulse REFRESH before the decay interval and confirm the data survives",
      "Explain why refresh circuitry and RAS/CAS multiplexing exist",
    ],
    examples: [
      { title: "Leak demo", body: "In this lab data decays after 6 s. Watch the DATA OUT LEDs and the leak indicator: write, wait, then refresh to recover." },
      { title: "Address multiplexing", body: "Real DRAMs present the row then the column address on the same pins, halving the pin count — hence RAS and CAS strobes." },
    ],
    notes: [
      "Reading a DRAM cell is destructive; the sense amplifier restores the charge as part of every read.",
      "Refresh consumes bandwidth — modern controllers interleave refresh with access in idle slots.",
      "One transistor per bit gives DRAM its density advantage over SRAM's six.",
    ],
    buildId: "dram",
    fidelity: "behavioural",
    difficulty: 3,
  },

  /* ========================= 5. SPECIAL CIRCUITS ========================= */
  {
    id: "shift-registers",
    name: "Shift Registers (SIPO)",
    short: "Moves data one stage per clock — serial in, parallel out.",
    category: "special",
    tags: ["7495", "sipo", "serial", "delay line"],
    symbol: "block",
    ic: "7495 · 74164 · 74595",
    description:
      "A shift register is a chain of flip-flops in which each clock pulse moves every stored bit one stage along. The 4-bit SIPO (serial-in parallel-out) model here accepts one bit per clock on SERIAL INPUT and presents the whole word on Q0–Q3.",
    working:
      "The output of each flip-flop feeds the data input of the next (Q0→D1, Q1→D2, Q2→D3) while the serial input feeds D0. On the rising clock edge all stages capture simultaneously, so the bit pattern marches towards the MSB. Reversing the connections yields a right shift; adding parallel load paths creates universal (74194) registers.",
    boolean: "Q0(t+1) = SIN ;  Q(i+1)(t+1) = Qi(t)",
    parts: boardParts([
      { name: "7495 4-bit shift register IC", qty: "1", fn: "Four D flip-flops with serial and parallel paths." },
      { name: "SPST toggle switch", qty: "2", fn: "SERIAL INPUT and MASTER CLEAR." },
      { name: "Clock module", qty: "1", fn: "Shift trigger — one stage per pulse." },
      { name: "LED bar", qty: "1", fn: "Parallel output Q3–Q0." },
      { name: "LED indicator", qty: "1", fn: "SERIAL OUT (Q3) for cascading." },
    ]),
    applications: [
      "Serial-to-parallel and parallel-to-serial conversion (UART, SPI)",
      "Digital delay lines and pulse stretching",
      "LED strip and seven-segment display drivers (74595)",
      "Sequence detectors and pattern matching pipelines",
    ],
    objectives: [
      "Shift a known 4-bit pattern in and verify it emerges on the parallel outputs",
      "Count the clock pulses needed to fill the register completely",
      "Cascade two devices through SERIAL OUT and confirm 8-bit operation",
    ],
    examples: [
      { title: "SPI input", body: "Eight clocks with MOSI on SERIAL IN turn a serial byte into a parallel bus the microcontroller can use directly." },
      { title: "Running light", body: "Feed a '1' into a cleared register and pulse the clock: a single lit LED walks from Q0 to Q3." },
    ],
    notes: [
      "Data appearing at SERIAL OUT after n clocks makes cascading trivial.",
      "Master clear must be released before shifting, or every pulse loads zeros.",
    ],
    buildId: "shift-registers",
    fidelity: "gate-level",
    difficulty: 2,
  },
  {
    id: "ring-counter",
    name: "Ring Counter",
    short: "A single ‘1’ recirculating through n flip-flops.",
    category: "special",
    tags: ["circular shift", "mod-n", "sequencer", "one-hot"],
    symbol: "block",
    ic: "74175 + feedback",
    description:
      "A ring counter is a circular shift register initialised with exactly one bit set. That bit travels around the loop, so an n-stage ring counter has n distinct states and produces one-hot output — one line active at a time, in sequence.",
    working:
      "The output of the last stage is fed back to the input of the first (Q3 → D0). Each clock pulse rotates the pattern one position. Because only one flip-flop is set at any moment, the outputs are already decoded: no extra decoder is needed to drive n sequential control lines. A preset path loads the initial 0001 pattern.",
    boolean: "D0 = Q(n−1) ;  Di = Q(i−1)   → modulus = n",
    parts: boardParts([
      { name: "74175 quad D flip-flop IC", qty: "1", fn: "The four recirculating stages." },
      { name: "SPST toggle switch", qty: "2", fn: "PRESET 1000 and MASTER CLEAR." },
      { name: "Clock module", qty: "1", fn: "Rotation trigger." },
      { name: "LED bar", qty: "1", fn: "One-hot state display Q3–Q0." },
    ]),
    applications: [
      "Sequential control and stepper-motor phase generation",
      "Timing ring / state sequencers in controllers",
      "Round-robin arbitration and token passing",
      "Driving n devices in turn without a decoder",
    ],
    objectives: [
      "Preset the counter and verify the four-state rotation",
      "Confirm the modulus equals the number of stages (n states, not 2ⁿ)",
      "Compare decoded output requirements against a binary counter",
    ],
    examples: [
      { title: "Four-phase stepper", body: "Q0–Q3 in sequence energise the four coils of a stepper motor, one phase per clock pulse." },
      { title: "Token ring", body: "Each output acts as a 'your turn' grant line for one of four bus masters." },
    ],
    notes: [
      "If the counter ever enters an invalid state (more than one bit set), it will keep circulating that error — add self-correcting logic in safety-critical designs.",
      "Uses n flip-flops for only n states, so it is less efficient than a binary counter but needs no decoder.",
    ],
    buildId: "ring-counter",
    fidelity: "gate-level",
    difficulty: 2,
  },
  {
    id: "johnson-counter",
    name: "Johnson Counter",
    short: "Twisted-ring counter giving 2n states from n flip-flops.",
    category: "special",
    tags: ["twisted ring", "mod-2n", "walking pattern", "decade"],
    symbol: "block",
    ic: "7495 + 7404 · 4017",
    description:
      "The Johnson (twisted-ring or Möbius) counter feeds the complement of the last stage back to the first. With n stages it produces 2n distinct states — twice the efficiency of a plain ring counter — and the output pattern is a travelling block of ones.",
    working:
      "D0 = Q̄(n−1) while all other stages shift as usual. Starting from 0000 the pattern fills with ones from the right, then empties again, giving 0000 → 1000 → 1100 → 1110 → 1111 → 0111 → 0011 → 0001 → 0000. Only two consecutive states differ per clock, and adjacent codes overlap, which makes decoding simple with two-input gates.",
    boolean: "D0 = Q̄(n−1) ;  Di = Q(i−1)   → modulus = 2n",
    parts: boardParts([
      { name: "7495 4-bit shift register IC", qty: "1", fn: "The recirculating shift chain." },
      { name: "7404 hex inverter", qty: "1", fn: "Twists the feedback (Q̄3 → D0)." },
      { name: "SPST toggle switch", qty: "1", fn: "MASTER CLEAR." },
      { name: "Clock module", qty: "1", fn: "Advance trigger." },
      { name: "LED bar", qty: "1", fn: "Travelling pattern display." },
    ]),
    applications: [
      "Decade counters and frequency dividers (÷2n)",
      "Stepper motor and phase-sequence generators",
      "LED chaser and lighting effects",
      "State machines needing a long sequence from few flip-flops",
    ],
    objectives: [
      "Verify the eight-state sequence of a 4-stage Johnson counter",
      "Show that the modulus is 2n rather than n",
      "Decode two adjacent states with a single two-input gate",
    ],
    examples: [
      { title: "Divide by 8", body: "Four stages give eight states, so any single output runs at fclk/8 with a 50 % duty cycle." },
      { title: "4017 decade counter", body: "The CMOS 4017 is a five-stage Johnson counter with ten decoded one-hot outputs." },
    ],
    notes: [
      "Invalid states exist (e.g. 1010); a stuck counter can be recovered by gating the feedback with the complement of an earlier stage.",
      "Johnson outputs are glitch-free between adjacent states, which is valuable for driving analog switches.",
    ],
    buildId: "johnson-counter",
    fidelity: "gate-level",
    difficulty: 3,
  },
  {
    id: "parity-generator",
    name: "Parity Generator (even)",
    short: "Appends a check bit so the word contains an even number of ones.",
    category: "special",
    tags: ["error detection", "xor tree", "7486", "transmit"],
    symbol: "block",
    ic: "7486 · 74280",
    description:
      "A parity generator computes one extra bit that is transmitted alongside a data word. For even parity the appended bit makes the total number of ones in the transmitted word even; odd parity makes it odd.",
    working:
      "An XOR tree folds the data bits pairwise: P = D0 ⊕ D1 ⊕ D2 ⊕ D3. Because XOR is associative and commutative, the tree can be balanced for speed. The result is 1 whenever the data word contains an odd number of ones, which is precisely what even parity requires.",
    boolean: "P(even) = D0 ⊕ D1 ⊕ … ⊕ D(n−1) ;  P(odd) = P(even) ⊕ 1",
    parts: boardParts([
      { name: "7486 quad XOR IC", qty: "1", fn: "Three XOR gates form the balanced parity tree." },
      { name: "4-position DIP switch", qty: "1", fn: "Data word D3–D0." },
      { name: "LED indicator", qty: "1", fn: "Generated parity bit P." },
      { name: "LED bar", qty: "1", fn: "Echo of the transmitted data word." },
    ]),
    applications: [
      "UART / serial link framing bits",
      "Memory ECC pre-stage and RAID parity",
      "Bus and backplane data integrity checking",
      "Simple error detection in telemetry frames",
    ],
    objectives: [
      "Verify P for all sixteen 4-bit data words",
      "Confirm the XOR tree is order-independent",
      "Convert the generator to odd parity with a single inverter",
    ],
    examples: [
      { title: "1011 → P = 1", body: "Three ones in the data, so even parity appends a 1 giving 10111 (four ones)." },
      { title: "1100 → P = 0", body: "Two ones already, so the parity bit is 0 and the word stays even." },
    ],
    notes: [
      "Parity detects only an odd number of bit errors — two simultaneous errors cancel out.",
      "Generator and checker must agree on the polarity (even vs odd) or every word will be flagged.",
    ],
    buildId: "parity-generator",
    fidelity: "gate-level",
    difficulty: 1,
  },
  {
    id: "parity-checker",
    name: "Parity Checker (even)",
    short: "Detects single-bit errors in a received word.",
    category: "special",
    tags: ["error detection", "xor tree", "7486", "receive"],
    symbol: "block",
    ic: "7486 · 74280",
    description:
      "A parity checker receives the data word together with its transmitted parity bit and reports whether the combination still satisfies the agreed parity rule. A mismatch means at least one bit was corrupted in transit.",
    working:
      "The checker XORs all received bits including the parity bit. For even parity the total number of ones must be even, so the XOR of every bit must be 0; a result of 1 raises the ERROR flag. An inverter provides the complementary VALID output. The circuit is a parity generator with one additional input.",
    boolean: "ERROR = D0 ⊕ D1 ⊕ D2 ⊕ D3 ⊕ P ;  VALID = ERROR′",
    parts: boardParts([
      { name: "7486 quad XOR IC", qty: "1", fn: "Four XOR gates fold the five received bits." },
      { name: "7404 hex inverter", qty: "1", fn: "Produces the VALID flag from ERROR." },
      { name: "5-position DIP switch", qty: "1", fn: "Received word D3–D0 plus parity bit P." },
      { name: "LED indicators", qty: "2", fn: "ERROR and VALID." },
    ]),
    applications: [
      "Serial receiver error flags (UART parity error)",
      "Memory scrubbing and soft-error detection",
      "Communication frame validation",
      "Safety-critical input verification",
    ],
    objectives: [
      "Verify ERROR = 0 for correctly parity-coded words",
      "Flip any single bit and confirm ERROR is asserted",
      "Flip two bits and observe that the error is missed — the fundamental limit of parity",
    ],
    examples: [
      { title: "Valid word 1010 + P=0", body: "Two ones in the data, even parity bit 0 → XOR of all bits = 0 → VALID." },
      { title: "Corrupted word 1011 + P=0", body: "Three ones with parity 0 → XOR = 1 → ERROR is asserted." },
    ],
    notes: [
      "Parity detects any odd number of errors but no even number — it cannot locate the fault either.",
      "Hamming codes extend this idea with multiple overlapping parity groups to correct single-bit errors.",
    ],
    buildId: "parity-checker",
    fidelity: "gate-level",
    difficulty: 2,
  },
];

/* ---------------- derived helpers ---------------- */

export const COMPONENT_MAP: Record<string, ComponentDoc> = Object.fromEntries(
  COMPONENTS.map((c) => [c.id, c]),
);

export const CATEGORY_MAP: Record<CategoryId, Category> = Object.fromEntries(
  CATEGORIES.map((c) => [c.id, c]),
) as Record<CategoryId, Category>;

export const TOTAL_COMPONENTS = COMPONENTS.length;

export const countByCategory = (id: CategoryId): number =>
  COMPONENTS.filter((c) => c.category === id).length;

/** components whose netlist actually exists and solves */
export const isSimulatable = (id: string): boolean => Boolean(BUILDS[COMPONENT_MAP[id]?.buildId ?? ""]);

export const SIMULATABLE_COUNT = COMPONENTS.filter((c) => isSimulatable(c.id)).length;

export function searchComponents(q: string, list: ComponentDoc[] = COMPONENTS): ComponentDoc[] {
  const t = q.trim().toLowerCase();
  if (!t) return list;
  const terms = t.split(/\s+/);
  return list.filter((c) => {
    const hay = [
      c.name,
      c.short,
      c.description,
      c.working,
      c.boolean,
      c.ic,
      CATEGORY_MAP[c.category].name,
      ...c.tags,
      ...c.applications,
    ]
      .join(" ")
      .toLowerCase();
    return terms.every((term) => hay.includes(term));
  });
}
