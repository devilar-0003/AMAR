/**
 * DigiLab Pro — Interactive 3D Digital Electronics Platform
 * Application shell: theme, navigation, persistent favourites/history and
 * the two main surfaces (Component Library ⇄ Component Detail).
 */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { COMPONENTS, COMPONENT_MAP, TOTAL_COMPONENTS, type ComponentDoc } from "@/data/library";
import { getBuild } from "@/sim/builds";
import type { ThemeName } from "@/sim/kit";
import { useSimSession } from "@/hooks/useSimSession";
import { Sidebar, type LibraryFilter } from "@/components/Sidebar";
import { LibraryView, type SortMode } from "@/components/LibraryView";
import { ComponentDetail } from "@/components/ComponentDetail";
import { Icon } from "@/components/Icons";
import { Badge, Btn, Led } from "@/components/ui";

/* ---------------- persistence ---------------- */

function useStored<T>(key: string, initial: T): [T, (v: T | ((p: T) => T)) => void] {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initial;
    } catch {
      return initial;
    }
  });
  const set = useCallback(
    (v: T | ((p: T) => T)) => {
      setValue((prev) => {
        const next = typeof v === "function" ? (v as (p: T) => T)(prev) : v;
        try {
          localStorage.setItem(key, JSON.stringify(next));
        } catch {
          /* storage unavailable — session-only state */
        }
        return next;
      });
    },
    [key],
  );
  return [value, set];
}

/* ---------------- shell ---------------- */

export default function App() {
  const [theme, setTheme] = useStored<ThemeName>("digilab.theme", "dark");
  const [favorites, setFavorites] = useStored<string[]>("digilab.favorites", []);
  const [recent, setRecent] = useStored<string[]>("digilab.recent", []);
  const [filter, setFilter] = useState<LibraryFilter>("all");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useStored<SortMode>("digilab.sort", "az");
  const [dense, setDense] = useStored<boolean>("digilab.dense", false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [drawer, setDrawer] = useState(false);
  const searchRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  const doc: ComponentDoc | undefined = selectedId ? COMPONENT_MAP[selectedId] : undefined;
  const build = useMemo(() => (doc ? getBuild(doc.buildId) : undefined), [doc]);
  const session = useSimSession(build);

  /* -------- navigation -------- */

  const open = useCallback(
    (id: string) => {
      if (!COMPONENT_MAP[id]) return;
      setSelectedId(id);
      setDrawer(false);
      setRecent((prev) => [id, ...prev.filter((x) => x !== id)].slice(0, 12));
    },
    [setRecent],
  );

  const openLibrary = useCallback(() => setSelectedId(null), []);

  const toggleFavorite = useCallback(
    (id: string) => setFavorites((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id])),
    [setFavorites],
  );

  /* -------- ordered navigation list (respects the current filter) -------- */
  const ordered = useMemo(() => {
    let base = COMPONENTS;
    if (filter === "favorites") base = base.filter((c) => favorites.includes(c.id));
    else if (filter === "recent") base = recent.map((id) => COMPONENT_MAP[id]).filter(Boolean) as ComponentDoc[];
    else if (filter !== "all") base = base.filter((c) => c.category === filter);
    return base;
  }, [filter, favorites, recent]);

  const step = useCallback(
    (dir: 1 | -1) => {
      if (!selectedId || ordered.length === 0) return;
      const i = ordered.findIndex((c) => c.id === selectedId);
      if (i < 0) return;
      open(ordered[(i + dir + ordered.length) % ordered.length].id);
    },
    [ordered, selectedId, open],
  );

  /* -------- keyboard shortcuts -------- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const typing = (e.target as HTMLElement)?.tagName === "INPUT" || (e.target as HTMLElement)?.tagName === "TEXTAREA";
      if (e.key === "/" && !typing) {
        e.preventDefault();
        setSelectedId(null);
        // the library surface has to mount before its input can take focus
        window.setTimeout(() => searchRef.current?.focus(), 40);
      } else if (e.key === "Escape") {
        if (drawer) setDrawer(false);
        else if (selectedId) setSelectedId(null);
        else if (query) setQuery("");
      } else if (e.key === "ArrowRight" && e.altKey && selectedId) {
        e.preventDefault();
        step(1);
      } else if (e.key === "ArrowLeft" && e.altKey && selectedId) {
        e.preventDefault();
        step(-1);
      } else if ((e.key === "f" || e.key === "F") && !typing && selectedId) {
        toggleFavorite(selectedId);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [selectedId, drawer, query, step, toggleFavorite]);

  return (
    <div className="relative flex h-screen w-full flex-col overflow-hidden bg-bg text-fg">
      <Backdrop />

      {/* ================= top bar ================= */}
      <header className="relative z-30 flex h-14 shrink-0 items-center gap-3 border-b border-line bg-panel/80 px-3 backdrop-blur-md sm:px-4">
        <button
          onClick={() => setDrawer(true)}
          className="grid h-9 w-9 shrink-0 place-items-center rounded-[3px] border border-line bg-panel2 text-dim transition-colors hover:border-cyan/50 hover:text-cyan lg:hidden focus-ring"
          aria-label="Open navigation"
        >
          <Icon name="menu" size={17} />
        </button>

        <button onClick={openLibrary} className="group flex shrink-0 items-center gap-2.5 focus-ring" title="DigiLab Pro home">
          <span className="relative grid h-9 w-9 place-items-center rounded-[3px] border border-cyan/50 bg-cyan/10">
            <Icon name="cpu" size={18} className="text-cyan transition-transform duration-500 group-hover:rotate-90" />
            <span className="absolute -bottom-[3px] -right-[3px] h-2 w-2 rounded-full bg-green shadow-[0_0_8px_var(--green)]" />
          </span>
          <span className="hidden leading-none sm:block">
            <span className="block font-display text-[15.5px] font-bold uppercase tracking-[0.18em] text-fg">
              Digi<span className="text-cyan">Lab</span> Pro
            </span>
            <span className="mt-[3px] block font-mono text-[8.5px] uppercase tracking-[0.22em] text-mute">
              3D digital electronics platform
            </span>
          </span>
        </button>

        {/* breadcrumb / status rail */}
        <div className="mx-1 hidden min-w-0 flex-1 items-center gap-2 md:flex">
          <span className="h-5 w-px bg-line" />
          <nav className="flex min-w-0 items-center gap-2 font-mono text-[10px] uppercase tracking-[0.14em] text-mute">
            <button onClick={openLibrary} className="transition-colors hover:text-cyan focus-ring">
              Library
            </button>
            <span className="opacity-40">/</span>
            {doc ? (
              <>
                <span className="truncate text-dim">{doc.category}</span>
                <span className="opacity-40">/</span>
                <span className="truncate text-fg">{doc.name}</span>
              </>
            ) : (
              <span className="text-dim">{TOTAL_COMPONENTS} components</span>
            )}
          </nav>
        </div>

        <div className="ml-auto flex items-center gap-1.5">
          {doc && (
            <div className="hidden items-center gap-1 sm:flex">
              <Btn size="xs" variant="ghost" icon="chevronLeft" onClick={() => step(-1)} title="Previous component (Alt+←)" />
              <Btn size="xs" variant="ghost" icon="chevronRight" onClick={() => step(1)} title="Next component (Alt+→)" />
              <span className="h-5 w-px bg-line" />
            </div>
          )}
          <span className="hidden items-center gap-2 rounded-[3px] border border-line bg-panel2/60 px-2.5 py-1.5 lg:flex">
            <Led on size={7} color="var(--green)" />
            <span className="font-mono text-[9.5px] uppercase tracking-[0.14em] text-mute">
              kernel <span className="text-green">ready</span>
            </span>
          </span>
          <Btn
            size="sm"
            variant="ghost"
            icon={theme === "dark" ? "sun" : "moon"}
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            title={`Switch to ${theme === "dark" ? "light" : "dark"} theme`}
          >
            <span className="hidden sm:inline">{theme === "dark" ? "Light" : "Dark"}</span>
          </Btn>
        </div>
      </header>

      {/* ================= body ================= */}
      <div className="relative z-10 flex min-h-0 flex-1">
        <div className="hidden lg:block">
          <Sidebar
            filter={filter}
            onFilter={setFilter}
            onOpenLibrary={openLibrary}
            onSelect={open}
            activeId={selectedId}
            favorites={favorites}
            recent={recent}
            onToggleFavorite={toggleFavorite}
            libraryOpen={!selectedId}
            onClose={() => undefined}
          />
        </div>

        {drawer && (
          <div className="fixed inset-0 z-40 lg:hidden">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px]" onClick={() => setDrawer(false)} />
            <div className="absolute inset-y-0 left-0 w-[290px] max-w-[86vw] anim-pop">
              <Sidebar
                filter={filter}
                onFilter={setFilter}
                onOpenLibrary={openLibrary}
                onSelect={open}
                activeId={selectedId}
                favorites={favorites}
                recent={recent}
                onToggleFavorite={toggleFavorite}
                libraryOpen={!selectedId}
                onClose={() => setDrawer(false)}
              />
            </div>
          </div>
        )}

        <main className="relative min-w-0 flex-1 overflow-hidden">
          {doc ? (
            <ComponentDetail
              key={doc.id}
              doc={doc}
              build={build}
              session={session}
              theme={theme}
              onBack={openLibrary}
              favorite={favorites.includes(doc.id)}
              onToggleFavorite={() => toggleFavorite(doc.id)}
            />
          ) : (
            <LibraryViewWithRef
              filter={filter}
              setFilter={setFilter}
              query={query}
              setQuery={setQuery}
              sort={sort}
              setSort={setSort}
              favorites={favorites}
              recent={recent}
              onToggleFavorite={toggleFavorite}
              onSelect={open}
              dense={dense}
              setDense={setDense}
              searchRef={searchRef}
            />
          )}
        </main>
      </div>

      {/* ================= status bar ================= */}
      <footer className="relative z-20 flex h-7 shrink-0 items-center gap-4 border-t border-line bg-panel/85 px-3 font-mono text-[9.5px] uppercase tracking-[0.14em] text-mute backdrop-blur-md sm:px-4">
        <span className="flex items-center gap-1.5">
          <Led on={session.ready} size={6} color="var(--cyan)" />
          {doc ? `${doc.name} · netlist loaded` : `library · ${TOTAL_COMPONENTS} components`}
        </span>
        <span className="hidden sm:inline">{filter === "all" ? "all families" : filter}</span>
        {build && (
          <span className="hidden md:inline">
            {build.nodes.length} nodes · {build.clocked ? "clocked" : "combinational"}
          </span>
        )}
        <span className="ml-auto hidden items-center gap-2 lg:flex">
          <Badge tone="dim">/ search</Badge>
          <Badge tone="dim">esc back</Badge>
          <Badge tone="dim">alt ← → navigate</Badge>
          <Badge tone="dim">f favourite</Badge>
        </span>
      </footer>
    </div>
  );
}

/* ---------------- library wrapper (forwards the search ref) ---------------- */

function LibraryViewWithRef(
  props: React.ComponentProps<typeof LibraryView> & { searchRef: React.RefObject<HTMLInputElement | null> },
) {
  const { searchRef, ...rest } = props;
  const localRef = useRef<HTMLInputElement | null>(null);
  useEffect(() => {
    searchRef.current = localRef.current;
  });
  return <LibraryView {...rest} searchRef={localRef} />;
}

/* ---------------- ambient backdrop ---------------- */

function Backdrop() {
  return (
    <div className="pointer-events-none absolute inset-0 z-0 overflow-hidden">
      <div className="bench-grid absolute inset-0 opacity-70" />
      <div
        className="absolute inset-x-0 bottom-0 h-1/2"
        style={{ background: "radial-gradient(120% 90% at 50% 130%, color-mix(in srgb, var(--cyan) 16%, transparent), transparent 62%)" }}
      />
      <div
        className="absolute inset-x-0 top-0 h-40"
        style={{ background: "linear-gradient(to bottom, color-mix(in srgb, var(--green) 7%, transparent), transparent)" }}
      />
      <svg className="absolute inset-0 h-full w-full opacity-[0.16]" aria-hidden>
        <defs>
          <linearGradient id="trace-fade" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="var(--trace)" stopOpacity="0" />
            <stop offset="50%" stopColor="var(--trace)" stopOpacity="1" />
            <stop offset="100%" stopColor="var(--trace)" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[16, 34, 58, 77, 91].map((y, i) => (
          <path
            key={y}
            d={`M-40 ${y} H ${20 + i * 14} L ${44 + i * 14} ${y + 12} H 1400`}
            fill="none"
            stroke="url(#trace-fade)"
            strokeWidth="1"
          />
        ))}
      </svg>
      <div
        className="absolute inset-0"
        style={{ background: "radial-gradient(120% 100% at 50% 50%, transparent 45%, color-mix(in srgb, var(--bg) 82%, transparent))" }}
      />
    </div>
  );
}
