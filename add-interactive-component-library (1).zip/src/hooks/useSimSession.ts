/**
 * DigiLab Pro — useSimSession
 * Owns a LogicSim instance for the active component plus the transport
 * controls (manual pulse, free-run clock, demo script playback).
 * The three.js engine reads the same instance, so 3D, truth table and
 * logic diagram can never drift apart.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Bit, Build, Vec } from "@/sim/logic";
import { LogicSim } from "@/sim/logic";

export interface SimSession {
  sim: LogicSim | null;
  version: number;
  running: boolean;
  speed: number;
  step: number;
  leak: boolean;
  setBit(id: string, bit: Bit, index?: number): void;
  toggle(id: string, index?: number): void;
  setBus(id: string, v: Vec): void;
  pulse(): void;
  reset(): void;
  applyRow(values: Record<string, Vec>): void;
  setRunning(b: boolean): void;
  setSpeed(hz: number): void;
  ready: boolean;
}

export function useSimSession(build: Build | undefined): SimSession {
  const simRef = useRef<LogicSim | null>(null);
  const [version, setVersion] = useState(0);
  const [running, setRunning] = useState(false);
  const [speed, setSpeed] = useState(2);
  const [step, setStep] = useState(0);
  const [leak, setLeak] = useState(false);
  const [ready, setReady] = useState(false);
  const stepRef = useRef(0);
  const lowTimer = useRef<number | null>(null);

  // (re)create the kernel whenever the component changes
  useEffect(() => {
    setRunning(false);
    setReady(false);
    stepRef.current = 0;
    setStep(0);
    if (!build) {
      simRef.current = null;
      return;
    }
    try {
      simRef.current = new LogicSim(build);
      setReady(true);
    } catch (err) {
      console.error("[DigiLab] simulation init failed", err);
      simRef.current = null;
      setReady(false);
    }
    setVersion((v) => v + 1);
    return () => {
      if (lowTimer.current) window.clearTimeout(lowTimer.current);
    };
  }, [build]);

  const bump = useCallback(() => {
    setVersion((v) => v + 1);
    if (simRef.current) setLeak(simRef.current.leak);
  }, []);

  // DRAM leakage + wall clock
  useEffect(() => {
    if (!ready) return;
    const id = window.setInterval(() => {
      simRef.current?.tick(120);
      if (simRef.current?.leak !== leak) bump();
    }, 120);
    return () => window.clearInterval(id);
  }, [ready, leak, bump]);

  // free-running clock with demo-script playback
  useEffect(() => {
    if (!running || !ready || !build) return;
    const period = 1000 / Math.max(0.25, speed);
    const id = window.setInterval(() => {
      const sim = simRef.current;
      if (!sim) return;
      const s = stepRef.current;
      for (const ev of build.script ?? []) if (ev.at === s) sim.setInputs(ev.set);
      sim.setClock(true);
      stepRef.current = s + 1;
      setStep(stepRef.current);
      sim.tick(period);
      bump();
      if (lowTimer.current) window.clearTimeout(lowTimer.current);
      lowTimer.current = window.setTimeout(() => {
        simRef.current?.setClock(false);
        simRef.current?.tick(period * 0.45);
        bump();
      }, period * 0.45);
    }, period);
    return () => {
      window.clearInterval(id);
      if (lowTimer.current) window.clearTimeout(lowTimer.current);
    };
  }, [running, ready, speed, build, bump]);

  const setBit = useCallback(
    (id: string, bit: Bit, index = 0) => {
      simRef.current?.setInput(id, bit, index);
      setRunning(false);
      bump();
    },
    [bump],
  );

  const toggle = useCallback(
    (id: string, index = 0) => {
      simRef.current?.toggle(id, index);
      setRunning(false);
      bump();
    },
    [bump],
  );

  const setBus = useCallback(
    (id: string, v: Vec) => {
      v.forEach((b, i) => simRef.current?.setInput(id, b, i));
      setRunning(false);
      bump();
    },
    [bump],
  );

  const pulse = useCallback(() => {
    const sim = simRef.current;
    if (!sim || !build) return;
    setRunning(false);
    const s = stepRef.current;
    for (const ev of build.script ?? []) if (ev.at === s) sim.setInputs(ev.set);
    sim.setClock(true);
    bump();
    if (lowTimer.current) window.clearTimeout(lowTimer.current);
    lowTimer.current = window.setTimeout(() => {
      simRef.current?.setClock(false);
      bump();
    }, 160);
    stepRef.current = s + 1;
    setStep(stepRef.current);
  }, [build, bump]);

  const reset = useCallback(() => {
    simRef.current?.reset();
    stepRef.current = 0;
    setStep(0);
    setRunning(false);
    setLeak(false);
    bump();
  }, [bump]);

  const applyRow = useCallback(
    (values: Record<string, Vec>) => {
      const sim = simRef.current;
      if (!sim || !build) return;
      setRunning(false);
      // memory builds keep their contents: clicking a memory-map row must only
      // move the address pointer, never wipe the array
      if (build.tableMode !== "memory") sim.reset();
      for (const id of build.controls) {
        const node = sim.node(id);
        if (!node || node.kind === "CLK") continue;
        // match by node label because table columns are labelled
        const entry = Object.entries(values).find(([label]) => label === (build.colLabels?.[id] ?? id));
        if (entry) entry[1].forEach((b, i) => sim.setInput(id, b, i));
      }
      if (build.clocked) sim.pulse();
      bump();
    },
    [build, bump],
  );

  return useMemo(
    () => ({
      sim: simRef.current,
      version,
      running,
      speed,
      step,
      leak,
      setBit,
      toggle,
      setBus,
      pulse,
      reset,
      applyRow,
      setRunning,
      setSpeed,
      ready,
    }),
    [version, running, speed, step, leak, setBit, toggle, setBus, pulse, reset, applyRow, ready],
  );
}
