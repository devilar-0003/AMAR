/**
 * DigiLab Pro — Sidebar.tsx
 * Left rail: the Component Library launcher, category browser, favourites
 * and recently viewed history.
 */
import { CATEGORIES, COMPONENT_MAP, TOTAL_COMPONENTS, countByCategory, type CategoryId } from "@/data/library";
import { Icon } from "./Icons";
import { Led } from "./ui";

export type LibraryFilter = "all" | "favorites" | "recent" | CategoryId;

export function Sidebar({
  filter,
  onFilter,
  onOpenLibrary,
  onSelect,
  activeId,
  favorites,
  recent,
  onToggleFavorite,
  libraryOpen,
  onClose,
}: {
  filter: LibraryFilter;
  onFilter: (f: LibraryFilter) => void;
  onOpenLibrary: () => void;
  onSelect: (id: string) => void;
  activeId: string | null;
  favorites: string[];
  recent: string[];
  onToggleFavorite: (id: string) => void;
  libraryOpen: boolean;
  onClose: () => void;
}) {
  return (
    <aside className="flex h-full w-full flex-col border-r border-line bg-panel/85 backdrop-blur-sm lg:w-[286px] lg:shrink-0">
      <div className="scroll-thin flex-1 overflow-y-auto px-3 py-3.5">
        {/* ---------- library launcher ---------- */}
        <button
          onClick={() => {
            onOpenLibrary();
            onClose();
          }}
          className={[
            "group relative w-full overflow-hidden rounded-[4px] border p-3.5 text-left transition-all duration-250 focus-ring",
            libraryOpen
              ? "border-cyan/70 bg-cyan/10 shadow-[0_0_34px_-14px_var(--cyan)]"
              : "border-line bg-panel2/70 hover:border-cyan/55 hover:bg-cyan/6",
          ].join(" ")}
        >
          <span className="pointer-events-none absolute inset-x-0 top-0 h-[2px] overflow-hidden">
            <span className="rail-pulse block h-full w-full" />
          </span>
          <span className="flex items-start gap-3">
            <span
              className="relative mt-0.5 grid h-10 w-10 shrink-0 place-items-center rounded-[3px] border border-cyan/45 bg-cyan/10 text-cyan transition-transform duration-300 group-hover:scale-105"
              aria-hidden
            >
              <Icon name="layers" size={19} />
              <span className="absolute -right-1 -top-1 h-2 w-2 rounded-full bg-green anim-blink" />
            </span>
            <span className="min-w-0">
              <span className="block font-display text-[15px] font-bold uppercase leading-tight tracking-[0.13em] text-fg">
                Component
                <br />
                Library
              </span>
              <span className="mt-1 block text-[11px] leading-snug text-dim">
                Browse all digital electronics components
              </span>
            </span>
          </span>
          <span className="mt-3 flex items-center justify-between border-t border-line/70 pt-2.5">
            <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-mute">Total components</span>
            <span className="flex items-baseline gap-1">
              <span className="font-display text-[22px] font-bold leading-none text-cyan">{TOTAL_COMPONENTS}</span>
              <span className="font-mono text-[10px] text-mute">units</span>
            </span>
          </span>
        </button>

        {/* ---------- categories ---------- */}
        <NavHeading>Catalogue</NavHeading>
        <nav className="space-y-[3px]">
          <SideLink
            icon="grid"
            label="All components"
            count={TOTAL_COMPONENTS}
            active={filter === "all" && libraryOpen}
            onClick={() => {
              onFilter("all");
              onOpenLibrary();
              onClose();
            }}
          />
          {CATEGORIES.map((c) => (
            <SideLink
              key={c.id}
              label={c.name}
              glyph={c.glyph}
              accent={c.accent}
              count={countByCategory(c.id)}
              active={filter === c.id}
              onClick={() => {
                onFilter(c.id);
                onOpenLibrary();
                onClose();
              }}
            />
          ))}
        </nav>

        {/* ---------- favourites ---------- */}
        <NavHeading
          right={
            <span className="font-mono text-[9.5px] text-mute">
              {favorites.length}/{TOTAL_COMPONENTS}
            </span>
          }
        >
          Favourites
        </NavHeading>
        {favorites.length === 0 ? (
          <p className="rounded-[3px] border border-dashed border-line px-2.5 py-3 text-[11px] leading-relaxed text-mute">
            Star any component to pin it here for one-click access.
          </p>
        ) : (
          <nav className="space-y-[3px]">
            {favorites.slice(0, 8).map((id) => (
              <MiniRow
                key={id}
                id={id}
                active={activeId === id}
                onSelect={onSelect}
                onToggleFavorite={onToggleFavorite}
                tone="amber"
              />
            ))}
          </nav>
        )}

        {/* ---------- recent ---------- */}
        <NavHeading>Recently viewed</NavHeading>
        {recent.length === 0 ? (
          <p className="rounded-[3px] border border-dashed border-line px-2.5 py-3 text-[11px] leading-relaxed text-mute">
            Components you open will be listed here.
          </p>
        ) : (
          <nav className="space-y-[3px]">
            {recent.slice(0, 6).map((id) => (
              <MiniRow key={id} id={id} active={activeId === id} onSelect={onSelect} onToggleFavorite={onToggleFavorite} />
            ))}
          </nav>
        )}
      </div>

      {/* ---------- footer ---------- */}
      <div className="border-t border-line bg-panel2/50 px-3.5 py-2.5">
        <div className="flex items-center justify-between font-mono text-[9.5px] uppercase tracking-[0.14em] text-mute">
          <span className="flex items-center gap-1.5">
            <Led on size={7} /> kernel online
          </span>
          <span>v2.4 · bench</span>
        </div>
      </div>
    </aside>
  );
}

function NavHeading({ children, right }: { children: React.ReactNode; right?: React.ReactNode }) {
  return (
    <div className="mb-1.5 mt-5 flex items-center justify-between gap-2 px-0.5">
      <h3 className="hud">{children}</h3>
      {right}
    </div>
  );
}

function SideLink({
  label,
  count,
  active,
  onClick,
  icon,
  glyph,
  accent,
}: {
  label: string;
  count: number;
  active: boolean;
  onClick: () => void;
  icon?: "grid";
  glyph?: string;
  accent?: string;
}) {
  return (
    <button
      onClick={onClick}
      className={[
        "group flex w-full items-center gap-2.5 rounded-[3px] border px-2.5 py-[7px] text-left transition-all duration-150 focus-ring",
        active
          ? "border-cyan/55 bg-cyan/10 text-fg"
          : "border-transparent text-dim hover:border-line hover:bg-panel2/70 hover:text-fg",
      ].join(" ")}
    >
      <span
        className="grid h-5 w-5 shrink-0 place-items-center rounded-[2px] border font-mono text-[10px] transition-colors"
        style={{
          borderColor: active ? "var(--cyan)" : "var(--line)",
          color: accent ?? (active ? "var(--cyan)" : "var(--mute)"),
          background: active ? "color-mix(in srgb, var(--cyan) 12%, transparent)" : "transparent",
        }}
      >
        {icon ? <Icon name={icon} size={11} /> : glyph}
      </span>
      <span className="min-w-0 flex-1 truncate text-[12px] font-medium">{label}</span>
      <span
        className="shrink-0 rounded-[2px] px-1.5 py-[1px] font-mono text-[9.5px] tabular-nums transition-colors"
        style={{
          background: active ? "color-mix(in srgb, var(--cyan) 18%, transparent)" : "var(--panel3)",
          color: active ? "var(--cyan)" : "var(--mute)",
        }}
      >
        {count}
      </span>
    </button>
  );
}

function MiniRow({
  id,
  active,
  onSelect,
  onToggleFavorite,
  tone,
}: {
  id: string;
  active: boolean;
  onSelect: (id: string) => void;
  onToggleFavorite: (id: string) => void;
  tone?: "amber";
}) {
  const c = COMPONENT_MAP[id];
  if (!c) return null;
  return (
    <div
      className={[
        "group flex items-center gap-1.5 rounded-[3px] border px-2 py-[5px] transition-all duration-150",
        active ? "border-cyan/50 bg-cyan/8" : "border-transparent hover:border-line hover:bg-panel2/70",
      ].join(" ")}
    >
      <button onClick={() => onSelect(id)} className="min-w-0 flex-1 text-left focus-ring">
        <span className="block truncate text-[11.5px] text-fg">{c.name}</span>
      </button>
      <button
        onClick={() => onToggleFavorite(id)}
        title={tone ? "Remove from favourites" : "Add to favourites"}
        className="shrink-0 text-mute transition-colors hover:text-amber focus-ring"
        style={{ color: tone ? "var(--amber)" : undefined }}
      >
        <Icon name={tone ? "starFilled" : "star"} size={12} />
      </button>
    </div>
  );
}
