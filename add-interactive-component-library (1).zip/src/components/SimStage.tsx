/**
 * DigiLab Pro — SimStage.tsx
 * The interactive 3D bench: mounts BenchEngine, mirrors every control in an
 * accessible HTML rack, and exposes the transport (pulse / free-run / reset /
 * view / fullscreen / snapshot).
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { BenchEngine } from "@/sim/engine";
import type { Build } from "@/sim/logic";
import type { SimSession } from "@/hooks/useSimSession";
import type { ThemeName } from "@/sim/kit";
import { Btn, Led, Panel, Spinner } from "./ui";
import { Icon } from "./Icons";

export function SimStage({
  build,
  session,
  theme,
}: {
  build: Build;
  session: SimSession;
  theme: ThemeName;
}) {
  const hostRef = useRef<HTMLDivElement | null>(null);
  const frameRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<BenchEngine | null>(null);
  const [loading, setLoading] = useState(true);
  const [fps, setFps] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [hover, setHover] = useState<string | null>(null);
  const [full, setFull] = useState(false);
  const [bloom, setBloom] = useState(true);

  const onPick = useCallback(
    (nodeId: string, bit: number) => session.toggle(nodeId, bit),
    [session],
  );

  /* ---- engine lifecycle ---- */
  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    setLoading(true);
    setError(null);
    const engine = new BenchEngine(host, {
      onPick,
      onHover: (id) => setHover(id),
      onError: (err) => {
        console.error("[DigiLab] renderer error", err);
        setError(err instanceof Error ? err.message : "WebGL renderer failed to start.");
      },
      onFrame: (f) => setFps(f),
    });
    engineRef.current = engine;
    if (!engine.ready) {
      setError("WebGL is unavailable in this browser — the 3D bench cannot start.");
      setLoading(false);
    }
    return () => {
      engine.dispose();
      engineRef.current = null;
    };
    // onPick identity changes with the session object, which is stable per build
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [build.id]);

  useEffect(() => {
    const engine = engineRef.current;
    if (!engine || !session.sim) return;
    engine.load(build, session.sim);
    setLoading(false);
  }, [build, session.sim]);

  useEffect(() => {
    engineRef.current?.setTheme(theme);
  }, [theme]);

  useEffect(() => {
    engineRef.current?.setBloom(bloom && theme === "dark");
  }, [bloom, theme]);

  useEffect(() => {
    const onFs = () => setFull(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  const toggleFullscreen = () => {
    const el = frameRef.current;
    if (!el) return;
    if (document.fullscreenElement) document.exitFullscreen().catch(() => undefined);
    else el.requestFullscreen?.().catch(() => setError("Fullscreen was blocked by the browser."));
  };

  const snapshot = () => {
    const url = engineRef.current?.snapshot();
    if (!url) return;
    const a = document.createElement("a");
    a.href = url;
    a.download = `${build.id}-bench.png`;
    a.click();
  };

  return (
    <div
      ref={frameRef}
      className={`grid gap-3 ${full ? "h-full grid-rows-[1fr_auto] bg-bg p-3" : "lg:grid-cols-[minmax(0,1fr)_310px]"}`}
    >
      {/* ---------------- viewport ---------------- */}
      <div className="panel corner-ticks relative min-h-[330px] overflow-hidden rounded-[4px]">
        <div ref={hostRef} className="absolute inset-0" />

        {loading && (
          <div className="absolute inset-0 z-20 grid place-items-center bg-bg/85 backdrop-blur-[2px]">
            <div className="flex flex-col items-center gap-3">
              <Spinner size={26} />
              <span className="hud">initialising bench · compiling silicon</span>
            </div>
          </div>
        )}

        {error && (
          <div className="absolute inset-0 z-30 grid place-items-center bg-bg/92 p-6">
            <div className="max-w-sm text-center">
              <Icon name="alert" size={26} className="mx-auto text-amber" />
              <h4 className="mt-2 font-display text-[14px] uppercase tracking-[0.14em] text-fg">Renderer offline</h4>
              <p className="mt-1.5 text-[12px] leading-relaxed text-dim">{error}</p>
              <p className="mt-2 text-[11.5px] text-mute">
                The logic simulation, truth table and logic diagram below remain fully functional.
              </p>
            </div>
          </div>
        )}

        {/* HUD */}
        <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-3 p-3">
          <div className="pointer-events-auto flex items-center gap-2 rounded-[3px] border border-line bg-bg/70 px-2.5 py-1.5 backdrop-blur-sm">
            <Led on={!error} color="var(--cyan)" size={8} />
            <span className="font-display text-[11.5px] font-semibold uppercase tracking-[0.16em] text-fg">{build.title}</span>
            <span className="font-mono text-[9.5px] uppercase tracking-[0.14em] text-mute">
              {build.nodes.length} nodes · {build.clocked ? "clocked" : "combinational"}
            </span>
          </div>
          <div className="pointer-events-auto flex items-center gap-1.5">
            <span className="rounded-[3px] border border-line bg-bg/70 px-2 py-1 font-mono text-[9.5px] uppercase tracking-[0.14em] text-mute backdrop-blur-sm">
              {fps} fps
            </span>
            <Btn size="xs" variant="ghost" icon="camera" onClick={snapshot} title="Save a PNG of the bench" />
            <Btn
              size="xs"
              variant="ghost"
              icon={full ? "minimize" : "maximize"}
              onClick={toggleFullscreen}
              title={full ? "Exit fullscreen" : "Fullscreen bench"}
            />
          </div>
        </div>

        {hover && (
          <div className="pointer-events-none absolute bottom-14 left-3 z-10 rounded-[3px] border border-cyan/40 bg-bg/80 px-2 py-1 font-mono text-[10px] uppercase tracking-[0.14em] text-cyan backdrop-blur-sm">
            {hover} · click to toggle
          </div>
        )}

        {/* transport */}
        <div className="absolute inset-x-0 bottom-0 z-10 flex flex-wrap items-center gap-1.5 border-t border-line bg-bg/78 px-2.5 py-2 backdrop-blur-sm">
          <Btn size="xs" variant="accent" icon="step" onClick={session.pulse} disabled={!build.clocked} title="Single clock pulse">
            Pulse
          </Btn>
          <Btn
            size="xs"
            variant={session.running ? "solid" : "outline"}
            icon={session.running ? "pause" : "play"}
            onClick={() => session.setRunning(!session.running)}
            disabled={!build.clocked}
          >
            {session.running ? "Running" : "Run"}
          </Btn>
          <label className="flex items-center gap-2 rounded-[3px] border border-line bg-panel2/50 px-2 py-1">
            <span className="font-mono text-[9.5px] uppercase tracking-[0.14em] text-mute">Hz</span>
            <input
              type="range"
              min={0.5}
              max={8}
              step={0.5}
              value={session.speed}
              onChange={(e) => session.setSpeed(Number(e.target.value))}
              className="h-1 w-20 cursor-pointer"
              disabled={!build.clocked}
            />
            <span className="w-6 font-mono text-[10px] text-cyan">{session.speed}</span>
          </label>
          <Btn size="xs" variant="ghost" icon="reset" onClick={session.reset} title="Reset all inputs and state">
            Reset circuit
          </Btn>
          <Btn size="xs" variant="ghost" icon="target" onClick={() => engineRef.current?.resetView()} title="Re-frame camera">
            View
          </Btn>
          <Btn
            size="xs"
            variant="ghost"
            icon="zap"
            active={bloom}
            onClick={() => setBloom(!bloom)}
            title="Neon bloom (dark theme)"
          >
            Bloom
          </Btn>
          <span className="ml-auto hidden font-mono text-[9.5px] uppercase tracking-[0.12em] text-mute md:block">
            drag orbit · scroll zoom · right-drag pan
          </span>
          {build.clocked && (
            <span className="font-mono text-[9.5px] uppercase tracking-[0.14em] text-mute">
              CLK ↑ <span className="text-cyan">{session.step}</span>
            </span>
          )}
        </div>
      </div>

      {/* ---------------- control rack ---------------- */}
      <div className="flex flex-col gap-3">
        <Panel title="Input rack" icon="wrench" className="anim-in">
          <div className="space-y-1.5">
            {build.controls.map((id) => {
              const node = build.nodes.find((n) => n.id === id)!;
              if (node.kind === "INBUS") {
                const v = session.sim?.vec(id) ?? [];
                return (
                  <div key={id} className="rounded-[3px] border border-line bg-panel2/40 p-2">
                    <div className="mb-1.5 flex items-center justify-between">
                      <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-dim">{node.label}</span>
                      <span className="font-mono text-[11px] text-green">
                        {[...v].reverse().map((b) => b).join("") || "0000"}
                      </span>
                    </div>
                    <div className="flex gap-1.5">
                      {Array.from({ length: node.bits ?? 4 }).map((_, i) => (
                        <button
                          key={i}
                          onClick={() => session.setBit(id, (v[i] ? 0 : 1) as 0 | 1, i)}
                          className="group flex h-9 flex-1 flex-col items-center justify-center rounded-[3px] border transition-all duration-150 focus-ring"
                          style={{
                            borderColor: v[i] ? "var(--green)" : "var(--line)",
                            background: v[i] ? "color-mix(in srgb, var(--green) 16%, transparent)" : "var(--panel)",
                          }}
                          title={`Toggle bit ${i}`}
                        >
                          <span className="font-mono text-[9px] text-mute">2^{i}</span>
                          <span className="font-mono text-[13px] font-bold" style={{ color: v[i] ? "var(--green)" : "var(--dim)" }}>
                            {v[i] ? 1 : 0}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                );
              }
              if (node.kind === "CLK") {
                const on = (session.sim?.vec(id)[0] ?? 0) === 1;
                return (
                  <div
                    key={id}
                    className="flex items-center justify-between rounded-[3px] border px-2.5 py-2 transition-colors"
                    style={{ borderColor: on ? "var(--cyan)" : "var(--line)", background: on ? "color-mix(in srgb, var(--cyan) 12%, transparent)" : "transparent" }}
                  >
                    <span className="flex items-center gap-2">
                      <Icon name="wave" size={14} className="text-cyan" />
                      <span className="font-mono text-[11px] uppercase tracking-[0.12em] text-fg">Clock</span>
                    </span>
                    <span className="font-mono text-[13px] font-bold" style={{ color: on ? "var(--cyan)" : "var(--mute)" }}>
                      {on ? "HIGH" : "LOW"}
                    </span>
                  </div>
                );
              }
              const on = (session.sim?.vec(id)[0] ?? 0) === 1;
              return (
                <RackSwitch key={id} label={node.label} hint={id} on={on} onToggle={() => session.toggle(id)} />
              );
            })}
          </div>
        </Panel>

        <Panel title="Output monitor" icon="zap" className="anim-in">
          <div className="space-y-1.5">
            {build.readouts.map((id) => {
              const node = build.nodes.find((n) => n.id === id)!;
              const raw = session.sim ? (node.kind === "FF" ? session.sim.readState(id) : session.sim.vec(id)) : [];
              const anyOn = raw.some((b) => b === 1);
              const width = raw.length;
              return (
                <div
                  key={id}
                  className="flex items-center justify-between gap-2 rounded-[3px] border px-2.5 py-2 transition-all duration-200"
                  style={{
                    borderColor: anyOn ? "var(--green)" : "var(--line)",
                    background: anyOn ? "color-mix(in srgb, var(--green) 10%, transparent)" : "var(--panel2)",
                    boxShadow: anyOn ? "0 0 20px -12px var(--green)" : "none",
                  }}
                >
                  <span className="flex min-w-0 items-center gap-2">
                    <Led on={anyOn} />
                    <span className="truncate font-mono text-[11px] uppercase tracking-[0.12em] text-fg">
                      {build.colLabels?.[id] ?? node.label}
                    </span>
                  </span>
                  {width > 1 ? (
                    <span className="flex items-center gap-2">
                      <span className="flex gap-[3px]">
                        {[...raw].reverse().map((b, i) => (
                          <span
                            key={i}
                            className="inline-block h-3.5 w-2 rounded-[1px] border"
                            style={{
                              borderColor: b ? "var(--green)" : "var(--line)",
                              background: b ? "var(--green)" : "transparent",
                            }}
                          />
                        ))}
                      </span>
                      <span className="font-mono text-[11px] text-mute">
                        {[...raw].reverse().join("")} = {raw.reduce<number>((a, b, i) => a | (b << i), 0)}
                      </span>
                    </span>
                  ) : (
                    <span className="font-mono text-[13px] font-bold" style={{ color: anyOn ? "var(--green)" : "var(--mute)" }}>
                      {anyOn ? "1" : "0"}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
          {build.script && build.script.length > 0 && (
            <p className="mt-2.5 flex items-start gap-1.5 text-[11px] leading-relaxed text-mute">
              <Icon name="info" size={12} className="mt-[2px] shrink-0 text-cyan" />
              Press <span className="text-cyan">Run</span> to replay the scripted demo pattern on the clock.
            </p>
          )}
        </Panel>
      </div>
    </div>
  );
}

function RackSwitch({
  label,
  hint,
  on,
  onToggle,
}: {
  label: string;
  hint: string;
  on: boolean;
  onToggle: () => void;
}) {
  return (
    <button
      onClick={onToggle}
      className="group flex w-full items-center justify-between gap-3 rounded-[3px] border px-2.5 py-2 text-left transition-all duration-150 focus-ring"
      style={{
        borderColor: on ? "var(--green)" : "var(--line)",
        background: on ? "color-mix(in srgb, var(--green) 11%, transparent)" : "var(--panel2)",
      }}
    >
      <span className="min-w-0">
        <span className="block truncate font-mono text-[11px] uppercase tracking-[0.12em] text-fg">{label}</span>
        <span className="block font-mono text-[9px] uppercase tracking-[0.14em] text-mute">{hint}</span>
      </span>
      <span className="flex items-center gap-2">
        <Led on={on} />
        <span className="font-mono text-[13px] font-bold" style={{ color: on ? "var(--green)" : "var(--mute)" }}>
          {on ? "1" : "0"}
        </span>
      </span>
    </button>
  );
}
