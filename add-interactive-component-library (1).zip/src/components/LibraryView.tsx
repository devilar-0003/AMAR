/**
 * DigiLab Pro — LibraryView.tsx
 * Searchable, filterable, sortable catalogue of every component.
 */
import { useMemo } from "react";
import {
  CATEGORIES,
  CATEGORY_MAP,
  COMPONENTS,
  SIMULATABLE_COUNT,
  TOTAL_COMPONENTS,
  searchComponents,
  type ComponentDoc,
} from "@/data/library";
import { getBuild } from "@/sim/builds";
import { Icon } from "./Icons";
import { Badge, Btn, EmptyState } from "./ui";
import type { LibraryFilter } from "./Sidebar";

export type SortMode = "az" | "za" | "category" | "difficulty";

export function LibraryView({
  filter,
  setFilter,
  query,
  setQuery,
  sort,
  setSort,
  favorites,
  recent,
  onToggleFavorite,
  onSelect,
  dense,
  setDense,
  searchRef,
}: {
  filter: LibraryFilter;
  setFilter: (f: LibraryFilter) => void;
  query: string;
  setQuery: (q: string) => void;
  sort: SortMode;
  setSort: (s: SortMode) => void;
  favorites: string[];
  recent: string[];
  onToggleFavorite: (id: string) => void;
  onSelect: (id: string) => void;
  dense: boolean;
  setDense: (b: boolean) => void;
  searchRef?: React.RefObject<HTMLInputElement | null>;
}) {
  const list = useMemo(() => {
    let base = COMPONENTS;
    if (filter === "favorites") base = base.filter((c) => favorites.includes(c.id));
    else if (filter === "recent") base = recent.map((id) => COMPONENTS.find((c) => c.id === id)).filter(Boolean) as ComponentDoc[];
    else if (filter !== "all") base = base.filter((c) => c.category === filter);

    const found = searchComponents(query, base);
    const sorted = [...found];
    const catIndex = (id: string) => CATEGORIES.findIndex((c) => c.id === id);
    switch (sort) {
      case "az":
        sorted.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case "za":
        sorted.sort((a, b) => b.name.localeCompare(a.name));
        break;
      case "category":
        sorted.sort((a, b) => catIndex(a.category) - catIndex(b.category) || a.name.localeCompare(b.name));
        break;
      case "difficulty":
        sorted.sort((a, b) => a.difficulty - b.difficulty || a.name.localeCompare(b.name));
        break;
    }
    if (filter === "recent" && sort === "az") return found; // keep recency order
    return sorted;
  }, [filter, query, sort, favorites, recent]);

  const title =
    filter === "all"
      ? "All components"
      : filter === "favorites"
        ? "Favourites"
        : filter === "recent"
          ? "Recently viewed"
          : CATEGORY_MAP[filter].name;

  return (
    <div className="anim-in flex h-full flex-col">
      {/* ---------- header ---------- */}
      <header className="shrink-0 border-b border-line bg-panel/60 px-4 py-3.5 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-x-6 gap-y-3">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="h-4 w-[3px] rounded-full bg-cyan shadow-[0_0_10px_var(--cyan)]" />
              <h1 className="font-display text-[21px] font-bold uppercase leading-none tracking-[0.1em] text-fg sm:text-[26px]">
                {title}
              </h1>
            </div>
            <p className="mt-2 max-w-2xl text-[12.5px] leading-relaxed text-dim">
              {filter !== "all" && filter !== "favorites" && filter !== "recent"
                ? CATEGORY_MAP[filter].blurb
                : "Every circuit below is wired from a real gate-level netlist — open one to inspect its symbol, drive its inputs, watch the 3D bench respond and verify the truth table against the live simulation."}
            </p>
          </div>
          <div className="flex items-center gap-4 font-mono text-[10px] uppercase tracking-[0.14em] text-mute">
            <Meta value={TOTAL_COMPONENTS} label="catalogued" />
            <Meta value={SIMULATABLE_COUNT} label="simulatable" tone="var(--green)" />
            <Meta value={CATEGORIES.length} label="families" />
            <Meta value={favorites.length} label="starred" tone="var(--amber)" />
          </div>
        </div>

        {/* ---------- toolbar ---------- */}
        <div className="mt-3.5 flex flex-wrap items-center gap-2">
          <div className="relative min-w-[210px] flex-1 sm:max-w-sm">
            <Icon name="search" size={14} className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-mute" />
            <input
              ref={searchRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search gates, ICs, applications…  ( / )"
              aria-label="Search components"
              className="h-9 w-full rounded-[3px] border border-line bg-panel2/70 pl-8 pr-8 font-mono text-[12px] text-fg placeholder:text-mute focus:border-cyan/70 focus:outline-none focus:ring-0"
            />
            {query && (
              <button
                onClick={() => setQuery("")}
                title="Clear search"
                aria-label="Clear search"
                className="absolute right-1.5 top-1/2 grid h-6 w-6 -translate-y-1/2 place-items-center rounded-[2px] text-mute transition-colors hover:bg-panel3 hover:text-red focus-ring"
              >
                <Icon name="x" size={13} />
              </button>
            )}
          </div>

          <div className="flex items-center gap-1 rounded-[3px] border border-line bg-panel2/60 p-[3px]">
            <span className="pl-1.5 pr-1 font-mono text-[9.5px] uppercase tracking-[0.14em] text-mute">Sort</span>
            {(
              [
                ["az", "A→Z"],
                ["za", "Z→A"],
                ["category", "Family"],
                ["difficulty", "Level"],
              ] as [SortMode, string][]
            ).map(([id, label]) => (
              <button
                key={id}
                onClick={() => setSort(id)}
                className={[
                  "rounded-[2px] px-2 py-1 font-mono text-[10px] uppercase tracking-[0.1em] transition-colors focus-ring",
                  sort === id ? "bg-cyan/16 text-cyan" : "text-mute hover:text-fg",
                ].join(" ")}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 rounded-[3px] border border-line bg-panel2/60 p-[3px]">
            <button
              onClick={() => setDense(false)}
              title="Comfortable grid"
              className={`grid h-7 w-7 place-items-center rounded-[2px] transition-colors focus-ring ${!dense ? "bg-cyan/16 text-cyan" : "text-mute hover:text-fg"}`}
            >
              <Icon name="grid" size={13} />
            </button>
            <button
              onClick={() => setDense(true)}
              title="Compact list"
              className={`grid h-7 w-7 place-items-center rounded-[2px] transition-colors focus-ring ${dense ? "bg-cyan/16 text-cyan" : "text-mute hover:text-fg"}`}
            >
              <Icon name="list" size={13} />
            </button>
          </div>

          {(query || filter !== "all") && (
            <Btn
              size="sm"
              variant="ghost"
              icon="x"
              onClick={() => {
                setQuery("");
                setFilter("all");
              }}
            >
              Clear
            </Btn>
          )}
        </div>

        {/* ---------- category chips ---------- */}
        <div className="mt-2.5 flex flex-wrap gap-1.5">
          <Chip active={filter === "all"} onClick={() => setFilter("all")} label={`All · ${TOTAL_COMPONENTS}`} />
          {CATEGORIES.map((c) => (
            <Chip
              key={c.id}
              active={filter === c.id}
              onClick={() => setFilter(c.id)}
              label={`${c.name} · ${COMPONENTS.filter((x) => x.category === c.id).length}`}
              accent={c.accent}
              glyph={c.glyph}
            />
          ))}
          <Chip active={filter === "favorites"} onClick={() => setFilter("favorites")} label={`★ Favourites · ${favorites.length}`} accent="var(--amber)" />
          <Chip active={filter === "recent"} onClick={() => setFilter("recent")} label={`↺ Recent · ${recent.length}`} />
        </div>
      </header>

      {/* ---------- results ---------- */}
      <div className="scroll-thin flex-1 overflow-y-auto px-4 py-4 sm:px-6">
        <div className="mb-2.5 flex items-center justify-between">
          <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-mute">
            showing <span className="text-cyan">{list.length}</span> of {TOTAL_COMPONENTS} components
            {query && (
              <>
                {" "}
                for “<span className="text-fg">{query}</span>”
              </>
            )}
          </span>
        </div>

        {list.length === 0 ? (
          <EmptyState
            icon={filter === "favorites" ? "star" : filter === "recent" ? "history" : "search"}
            title={
              filter === "favorites"
                ? "No favourites yet"
                : filter === "recent"
                  ? "Nothing viewed yet"
                  : "No components match that search"
            }
            body={
              filter === "favorites"
                ? "Tap the star on any component card to pin it here for fast access from the sidebar."
                : filter === "recent"
                  ? "Open any component and it will appear here with its full history."
                  : "Try a shorter query, an IC number such as 7408, or clear the category filter to search the whole catalogue."
            }
            action={
              <Btn
                variant="accent"
                size="md"
                icon="reset"
                onClick={() => {
                  setQuery("");
                  setFilter("all");
                }}
              >
                Reset filters
              </Btn>
            }
          />
        ) : dense ? (
          <ul className="divide-y divide-line/70 border border-line rounded-[4px] bg-panel/50">
            {list.map((c) => (
              <li key={c.id}>
                <DenseRow
                  doc={c}
                  fav={favorites.includes(c.id)}
                  onFav={() => onToggleFavorite(c.id)}
                  onOpen={() => onSelect(c.id)}
                />
              </li>
            ))}
          </ul>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
            {list.map((c, i) => (
              <Card
                key={c.id}
                doc={c}
                index={i}
                fav={favorites.includes(c.id)}
                onFav={() => onToggleFavorite(c.id)}
                onOpen={() => onSelect(c.id)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */

function Meta({ value, label, tone }: { value: number; label: string; tone?: string }) {
  return (
    <span className="flex items-baseline gap-1.5">
      <span className="font-display text-[17px] font-bold leading-none" style={{ color: tone ?? "var(--fg)" }}>
        {value}
      </span>
      <span>{label}</span>
    </span>
  );
}

function Chip({
  label,
  active,
  onClick,
  accent,
  glyph,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
  accent?: string;
  glyph?: string;
}) {
  return (
    <button
      onClick={onClick}
      className={[
        "group flex items-center gap-1.5 rounded-[3px] border px-2.5 py-[5px] font-mono text-[10.5px] uppercase tracking-[0.1em] transition-all duration-150 focus-ring",
        active ? "border-transparent text-bg" : "border-line bg-panel2/50 text-dim hover:border-cyan/45 hover:text-fg",
      ].join(" ")}
      style={active ? { background: accent ?? "var(--cyan)", boxShadow: `0 0 20px -8px ${accent ?? "var(--cyan)"}` } : undefined}
    >
      {glyph && <span className={active ? "" : "opacity-70"}>{glyph}</span>}
      {label}
    </button>
  );
}

function Card({
  doc,
  index,
  fav,
  onFav,
  onOpen,
}: {
  doc: ComponentDoc;
  index: number;
  fav: boolean;
  onFav: () => void;
  onOpen: () => void;
}) {
  const cat = CATEGORY_MAP[doc.category];
  const build = getBuild(doc.buildId);
  return (
    <article
      className="anim-in group relative flex flex-col overflow-hidden rounded-[4px] border border-line bg-panel/70 transition-all duration-250 hover:-translate-y-[3px] hover:border-cyan/50 hover:shadow-[0_18px_40px_-26px_var(--cyan)]"
      style={{ animationDelay: `${Math.min(index * 26, 420)}ms` }}
    >
      <span className="absolute inset-x-0 top-0 h-[2px]" style={{ background: `linear-gradient(90deg, ${cat.accent}, transparent 72%)`, opacity: 0.55 }} />
      <div className="flex items-start gap-3 p-3.5">
        <span
          className="grid h-11 w-11 shrink-0 place-items-center rounded-[3px] border bg-panel2 transition-all duration-250 group-hover:scale-[1.06]"
          style={{ borderColor: `color-mix(in srgb, ${cat.accent} 45%, transparent)` }}
        >
          <MiniMark doc={doc} accent={cat.accent} />
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-display text-[14.5px] font-bold leading-tight tracking-[0.02em] text-fg">{doc.name}</h3>
            <button
              onClick={onFav}
              title={fav ? "Remove from favourites" : "Add to favourites"}
              aria-label={fav ? "Remove from favourites" : "Add to favourites"}
              className="shrink-0 rounded-[2px] p-1 transition-all duration-150 hover:scale-110 focus-ring"
              style={{ color: fav ? "var(--amber)" : "var(--mute)" }}
            >
              <Icon name={fav ? "starFilled" : "star"} size={14} />
            </button>
          </div>
          <p className="mt-0.5 font-mono text-[9.5px] uppercase tracking-[0.14em]" style={{ color: cat.accent }}>
            {cat.name}
          </p>
        </div>
      </div>

      <p className="line-clamp-2 px-3.5 text-[12px] leading-relaxed text-dim">{doc.short}</p>

      <div className="mt-3 flex flex-wrap items-center gap-1.5 px-3.5">
        <Badge tone="cyan" icon="cpu">
          {doc.ic.split(" ")[0]}
        </Badge>
        <Badge tone={doc.fidelity === "gate-level" ? "green" : "amber"}>
          {doc.fidelity === "gate-level" ? "gate-level" : "behavioural"}
        </Badge>
        <Badge tone="dim">
          {build ? `${build.controls.length}in · ${build.readouts.length}out` : "no model"}
        </Badge>
      </div>

      <button
        onClick={onOpen}
        className="mt-3.5 flex items-center justify-between gap-2 border-t border-line/80 bg-panel2/40 px-3.5 py-2.5 text-left transition-colors duration-200 hover:bg-cyan/10 focus-ring"
      >
        <span className="flex items-center gap-1.5">
          <Difficulty level={doc.difficulty} />
          <span className="font-mono text-[9.5px] uppercase tracking-[0.14em] text-mute">
            level {doc.difficulty}
          </span>
        </span>
        <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-cyan">
          Open lab
          <Icon name="arrowRight" size={13} className="transition-transform duration-200 group-hover:translate-x-1" />
        </span>
      </button>
    </article>
  );
}

function DenseRow({
  doc,
  fav,
  onFav,
  onOpen,
}: {
  doc: ComponentDoc;
  fav: boolean;
  onFav: () => void;
  onOpen: () => void;
}) {
  const cat = CATEGORY_MAP[doc.category];
  return (
    <div className="group flex items-center gap-3 px-3 py-2 transition-colors duration-150 hover:bg-cyan/6">
      <span className="h-7 w-7 shrink-0 rounded-[3px] border p-[3px]" style={{ borderColor: `color-mix(in srgb, ${cat.accent} 40%, transparent)` }}>
        <MiniMark doc={doc} accent={cat.accent} />
      </span>
      <button onClick={onOpen} className="min-w-0 flex-1 text-left focus-ring">
        <span className="block truncate text-[12.5px] font-semibold text-fg">{doc.name}</span>
        <span className="block truncate text-[11px] text-mute">{doc.short}</span>
      </button>
      <span className="hidden w-28 shrink-0 font-mono text-[9.5px] uppercase tracking-[0.12em] sm:block" style={{ color: cat.accent }}>
        {cat.name}
      </span>
      <span className="hidden w-20 shrink-0 font-mono text-[10px] text-dim md:block">{doc.ic.split(" ")[0]}</span>
      <button
        onClick={onFav}
        title="Toggle favourite"
        className="shrink-0 rounded-[2px] p-1 transition-colors hover:text-amber focus-ring"
        style={{ color: fav ? "var(--amber)" : "var(--mute)" }}
      >
        <Icon name={fav ? "starFilled" : "star"} size={13} />
      </button>
      <Btn size="xs" variant="ghost" icon="arrowRight" onClick={onOpen} className="shrink-0 opacity-0 transition-opacity group-hover:opacity-100" />
    </div>
  );
}

function Difficulty({ level }: { level: number }) {
  return (
    <span className="flex items-end gap-[2px]">
      {[1, 2, 3].map((i) => (
        <span
          key={i}
          className="w-[3px] rounded-[1px]"
          style={{
            height: 4 + i * 3,
            background: i <= level ? "var(--cyan)" : "var(--line)",
          }}
        />
      ))}
    </span>
  );
}

/** compact 24px mark used on cards — derived from the real symbol kind */
function MiniMark({ doc, accent }: { doc: ComponentDoc; accent: string }) {
  const s = { stroke: accent, fill: "none", strokeWidth: 1.6 } as const;
  if (doc.symbol === "gate" && doc.gate) {
    const g = doc.gate;
    const bubble = g === "NAND" || g === "NOR" || g === "NOT" || g === "XNOR";
    return (
      <svg viewBox="0 0 24 24" className="h-full w-full">
        {g === "AND" || g === "NAND" ? <path d="M4 6h7a6 6 0 0 1 0 12H4z" {...s} /> : null}
        {g === "OR" || g === "NOR" || g === "XOR" || g === "XNOR" ? (
          <path d="M4 6q4 6 0 12 8 0 13-6Q12 6 4 6z" {...s} />
        ) : null}
        {(g === "XOR" || g === "XNOR") && <path d="M2 6q4 6 0 12" {...s} />}
        {g === "NOT" && <path d="M5 5l12 7-12 7z" {...s} />}
        {bubble && <circle cx="19" cy="12" r="1.8" {...s} />}
      </svg>
    );
  }
  if (doc.symbol === "ff")
    return (
      <svg viewBox="0 0 24 24" className="h-full w-full">
        <rect x="5" y="4" width="14" height="16" rx="1.5" {...s} />
        <path d="M5 15l2.5 2L5 19" {...s} />
        <text x="12" y="12.5" textAnchor="middle" fontSize="7" fill={accent} fontFamily="var(--font-mono)">
          {doc.name.slice(0, 2).toUpperCase()}
        </text>
      </svg>
    );
  if (doc.symbol === "memory")
    return (
      <svg viewBox="0 0 24 24" className="h-full w-full">
        <rect x="4" y="4" width="16" height="16" rx="1.5" {...s} />
        {[0, 1, 2].map((r) =>
          [0, 1, 2].map((c) => (
            <rect key={`${r}-${c}`} x={7 + c * 3.6} y={7 + r * 3.6} width="2.6" height="2.6" fill={accent} opacity={0.25 + ((r + c) % 3) * 0.28} />
          )),
        )}
      </svg>
    );
  if (doc.symbol === "adder")
    return (
      <svg viewBox="0 0 24 24" className="h-full w-full">
        <rect x="4" y="4" width="16" height="16" rx="1.5" {...s} />
        <path d="M12 8v8M8.5 11.5h7" {...s} />
      </svg>
    );
  return (
    <svg viewBox="0 0 24 24" className="h-full w-full">
      <rect x="4" y="5" width="16" height="14" rx="1.5" {...s} />
      <path d="M1 9h3M1 15h3M20 9h3M20 15h3" {...s} />
      <circle cx="12" cy="12" r="2.4" {...s} />
    </svg>
  );
}
