/**
 * DigiLab Pro — Icons.tsx
 * Inline stroke icon set (no icon dependency, no emoji).
 */
import type { ReactElement, SVGProps } from "react";

export type IconName =
  | "search"
  | "x"
  | "star"
  | "starFilled"
  | "chevronLeft"
  | "chevronRight"
  | "chevronDown"
  | "grid"
  | "cube"
  | "table"
  | "book"
  | "cpu"
  | "layers"
  | "graduation"
  | "sun"
  | "moon"
  | "play"
  | "pause"
  | "step"
  | "reset"
  | "maximize"
  | "minimize"
  | "camera"
  | "sort"
  | "clock"
  | "check"
  | "alert"
  | "info"
  | "menu"
  | "zap"
  | "filter"
  | "list"
  | "history"
  | "target"
  | "wrench"
  | "wave"
  | "plus"
  | "arrowRight";

const PATHS: Record<IconName, ReactElement> = {
  search: (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-3.6-3.6" />
    </>
  ),
  x: <path d="M18 6 6 18M6 6l12 12" />,
  star: <path d="m12 3.6 2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8L3.5 9.8l5.9-.9z" />,
  starFilled: (
    <path
      d="m12 3.6 2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8L3.5 9.8l5.9-.9z"
      fill="currentColor"
    />
  ),
  chevronLeft: <path d="m14.5 5-7 7 7 7" />,
  chevronRight: <path d="m9.5 5 7 7-7 7" />,
  chevronDown: <path d="m5 9.5 7 7 7-7" />,
  grid: (
    <>
      <rect x="3.5" y="3.5" width="7" height="7" rx="1" />
      <rect x="13.5" y="3.5" width="7" height="7" rx="1" />
      <rect x="3.5" y="13.5" width="7" height="7" rx="1" />
      <rect x="13.5" y="13.5" width="7" height="7" rx="1" />
    </>
  ),
  cube: (
    <>
      <path d="M12 2.8 20.5 7v10L12 21.2 3.5 17V7z" />
      <path d="M3.5 7 12 11.4 20.5 7M12 11.4V21.2" />
    </>
  ),
  table: (
    <>
      <rect x="3.5" y="4.5" width="17" height="15" rx="1.5" />
      <path d="M3.5 9.5h17M3.5 14.5h17M9.5 4.5v15" />
    </>
  ),
  book: (
    <>
      <path d="M4 4.5h7a3 3 0 0 1 3 3V20a2.4 2.4 0 0 0-2.4-2.4H4z" />
      <path d="M20 4.5h-4a3 3 0 0 0-2 3V20a2.4 2.4 0 0 1 2.4-2.4H20z" />
    </>
  ),
  cpu: (
    <>
      <rect x="6.5" y="6.5" width="11" height="11" rx="1.5" />
      <path d="M9.5 3v3.5M14.5 3v3.5M9.5 17.5V21M14.5 17.5V21M3 9.5h3.5M3 14.5h3.5M17.5 9.5H21M17.5 14.5H21" />
    </>
  ),
  layers: (
    <>
      <path d="m12 3 8.5 4.5L12 12 3.5 7.5z" />
      <path d="m3.5 12 8.5 4.5 8.5-4.5M3.5 16.5 12 21l8.5-4.5" />
    </>
  ),
  graduation: (
    <>
      <path d="M2.8 8.8 12 4.5l9.2 4.3L12 13.2z" />
      <path d="M6.5 10.8v4.6c0 1.4 2.5 2.6 5.5 2.6s5.5-1.2 5.5-2.6v-4.6M21 9v5" />
    </>
  ),
  sun: (
    <>
      <circle cx="12" cy="12" r="4" />
      <path d="M12 2.5v2.2M12 19.3v2.2M4.2 4.2l1.6 1.6M18.2 18.2l1.6 1.6M2.5 12h2.2M19.3 12h2.2M4.2 19.8l1.6-1.6M18.2 5.8l1.6-1.6" />
    </>
  ),
  moon: <path d="M20 14.2A8.4 8.4 0 0 1 9.8 4 8.5 8.5 0 1 0 20 14.2" />,
  play: <path d="M7 4.8 19 12 7 19.2z" />,
  pause: <path d="M8.5 5v14M15.5 5v14" />,
  step: (
    <>
      <path d="M6 5v14M18 5v14" />
      <path d="m9.5 8.5 5 3.5-5 3.5z" />
    </>
  ),
  reset: (
    <>
      <path d="M4.5 9.5A8 8 0 1 1 4 14" />
      <path d="M3.5 4v5.5H9" />
    </>
  ),
  maximize: <path d="M4 9V4h5M20 15v5h-5M20 9V4h-5M4 15v5h5" />,
  minimize: <path d="M9 4v5H4M15 20v-5h5M15 4v5h5M9 20v-5H4" />,
  camera: (
    <>
      <path d="M4 8.5h3l1.5-2.2h7L17 8.5h3v10H4z" />
      <circle cx="12" cy="13" r="3.2" />
    </>
  ),
  sort: (
    <>
      <path d="M7 4.5v15M7 19.5 4 16.5M7 19.5l3-3" />
      <path d="M17 19.5v-15M17 4.5l-3 3M17 4.5l3 3" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7v5.3l3.4 2" />
    </>
  ),
  check: <path d="m5 12.5 4.5 4.5L19 7" />,
  alert: (
    <>
      <path d="M12 4.5 21 19.5H3z" />
      <path d="M12 10v4M12 16.6v.6" />
    </>
  ),
  info: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 11v5.5M12 7.8v.6" />
    </>
  ),
  menu: <path d="M4 7h16M4 12h16M4 17h16" />,
  zap: <path d="M13.5 3 6 13.5h5L10.5 21 18 10.5h-5z" />,
  filter: <path d="M3.5 5.5h17l-6.5 7.5v6l-4 2v-8z" />,
  list: <path d="M4 6.5h16M4 12h16M4 17.5h10" />,
  history: (
    <>
      <path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1M3.5 4.5V10H9" />
      <path d="M12 8v4.4l3 1.8" />
    </>
  ),
  target: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <circle cx="12" cy="12" r="4" />
      <circle cx="12" cy="12" r="0.6" fill="currentColor" />
    </>
  ),
  wrench: (
    <path d="M20 5.5a5 5 0 0 1-6.6 6.6L7 18.5a2.1 2.1 0 0 1-3-3l6.4-6.4A5 5 0 0 1 17 2.5l-3 3 1.5 3 3-1.5z" />
  ),
  wave: <path d="M3 14.5h3l2-6 3 12 3-9 2 3h5" />,
  plus: <path d="M12 5v14M5 12h14" />,
  arrowRight: <path d="M4 12h15M14 6.5 19.5 12 14 17.5" />,
};

export interface IconProps extends Omit<SVGProps<SVGSVGElement>, "name"> {
  name: IconName;
  size?: number;
}

export function Icon({ name, size = 16, className, ...rest }: IconProps) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
      {...rest}
    >
      {PATHS[name]}
    </svg>
  );
}

/** Small animated signal-dot used across the interface */
export function SignalDot({ on, className }: { on: boolean; className?: string }) {
  return (
    <span
      className={`inline-block h-2 w-2 rounded-full transition-all duration-200 ${className ?? ""}`}
      style={{
        background: on ? "var(--green)" : "var(--line)",
        boxShadow: on ? "0 0 10px var(--green), 0 0 3px var(--green)" : "none",
      }}
    />
  );
}
