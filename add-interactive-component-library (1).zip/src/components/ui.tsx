/**
 * DigiLab Pro — ui.tsx
 * Small shared primitives that keep the whole interface visually consistent.
 */
import type { ReactNode } from "react";
import { Icon, type IconName } from "./Icons";

/* ---------------- buttons ---------------- */

type BtnVariant = "ghost" | "outline" | "accent" | "solid" | "danger";
type BtnSize = "xs" | "sm" | "md";

const VARIANTS: Record<BtnVariant, string> = {
  ghost: "bg-transparent text-dim hover:text-fg hover:bg-panel3 border border-transparent",
  outline: "bg-panel2/60 text-fg border border-line hover:border-cyan/70 hover:text-cyan",
  accent:
    "bg-cyan/12 text-cyan border border-cyan/45 hover:bg-cyan/22 hover:border-cyan shadow-[0_0_18px_-8px_var(--cyan)]",
  solid: "bg-green/16 text-green border border-green/50 hover:bg-green/26",
  danger: "bg-red/12 text-red border border-red/40 hover:bg-red/22",
};

const SIZES: Record<BtnSize, string> = {
  xs: "h-7 px-2 text-[10px] gap-1.5",
  sm: "h-8 px-2.5 text-[11px] gap-1.5",
  md: "h-10 px-4 text-[12px] gap-2",
};

export function Btn({
  children,
  onClick,
  variant = "outline",
  size = "sm",
  icon,
  active,
  disabled,
  title,
  className = "",
  type = "button",
}: {
  children?: ReactNode;
  onClick?: (e: React.MouseEvent) => void;
  variant?: BtnVariant;
  size?: BtnSize;
  icon?: IconName;
  active?: boolean;
  disabled?: boolean;
  title?: string;
  className?: string;
  type?: "button" | "submit";
}) {
  return (
    <button
      type={type}
      title={title}
      disabled={disabled}
      onClick={onClick}
      className={[
        "inline-flex select-none items-center justify-center rounded-[3px] font-mono uppercase tracking-[0.12em]",
        "transition-all duration-150 active:translate-y-px focus-ring",
        VARIANTS[variant],
        SIZES[size],
        active ? "border-cyan! text-cyan! bg-cyan/14" : "",
        disabled ? "opacity-40 pointer-events-none" : "",
        className,
      ].join(" ")}
    >
      {icon && <Icon name={icon} size={size === "md" ? 15 : 13} />}
      {children}
    </button>
  );
}

/* ---------------- badges ---------------- */

export type Tone = "cyan" | "green" | "amber" | "red" | "dim";

const TONES: Record<Tone, string> = {
  cyan: "text-cyan border-cyan/40 bg-cyan/10",
  green: "text-green border-green/40 bg-green/10",
  amber: "text-amber border-amber/40 bg-amber/10",
  red: "text-red border-red/40 bg-red/10",
  dim: "text-mute border-line bg-panel2",
};

export function Badge({
  children,
  tone = "dim",
  icon,
  className = "",
}: {
  children: ReactNode;
  tone?: Tone;
  icon?: IconName;
  className?: string;
}) {
  return (
    <span
      className={[
        "inline-flex items-center gap-1 rounded-[3px] border px-1.5 py-[2px]",
        "font-mono text-[9.5px] uppercase tracking-[0.14em] whitespace-nowrap",
        TONES[tone],
        className,
      ].join(" ")}
    >
      {icon && <Icon name={icon} size={10} />}
      {children}
    </span>
  );
}

/* ---------------- panels ---------------- */

export function Panel({
  title,
  icon,
  right,
  children,
  className = "",
  bodyClass = "",
}: {
  title?: ReactNode;
  icon?: IconName;
  right?: ReactNode;
  children: ReactNode;
  className?: string;
  bodyClass?: string;
}) {
  return (
    <section className={`panel corner-ticks rounded-[4px] ${className}`}>
      {title && (
        <header className="flex items-center justify-between gap-3 border-b border-line/80 bg-panel2/60 px-3.5 py-2.5">
          <h3 className="flex items-center gap-2 font-display text-[12.5px] font-semibold uppercase tracking-[0.16em] text-fg">
            {icon && <Icon name={icon} size={14} className="text-cyan" />}
            {title}
          </h3>
          {right}
        </header>
      )}
      <div className={`p-3.5 ${bodyClass}`}>{children}</div>
    </section>
  );
}

/* ---------------- LED ---------------- */

export function Led({ on, size = 10, color = "var(--green)" }: { on: boolean; size?: number; color?: string }) {
  return (
    <span
      className="inline-block shrink-0 rounded-full transition-all duration-150"
      style={{
        width: size,
        height: size,
        background: on ? color : "color-mix(in srgb, var(--mute) 35%, transparent)",
        boxShadow: on ? `0 0 ${size}px ${color}, 0 0 ${size / 2}px ${color}` : "inset 0 0 0 1px var(--line)",
      }}
    />
  );
}

/* ---------------- HTML toggle switch ---------------- */

export function Switch({
  on,
  onChange,
  label,
  sub,
  disabled,
}: {
  on: boolean;
  onChange: (v: boolean) => void;
  label: ReactNode;
  sub?: ReactNode;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={() => onChange(!on)}
      className={[
        "group flex w-full items-center gap-3 rounded-[3px] border px-2.5 py-2 text-left transition-all duration-150 focus-ring",
        on ? "border-green/55 bg-green/10" : "border-line bg-panel2/50 hover:border-cyan/45",
        disabled ? "pointer-events-none opacity-40" : "",
      ].join(" ")}
    >
      <span
        className="relative h-4 w-8 shrink-0 rounded-full border transition-colors duration-200"
        style={{
          borderColor: on ? "var(--green)" : "var(--line)",
          background: on ? "color-mix(in srgb, var(--green) 26%, transparent)" : "var(--panel3)",
        }}
      >
        <span
          className="absolute top-[1px] h-[12px] w-[12px] rounded-full transition-all duration-200"
          style={{
            left: on ? 16 : 2,
            background: on ? "var(--green)" : "var(--mute)",
            boxShadow: on ? "0 0 8px var(--green)" : "none",
          }}
        />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate font-mono text-[11px] uppercase tracking-[0.1em] text-fg">{label}</span>
        {sub && <span className="block truncate text-[10.5px] text-mute">{sub}</span>}
      </span>
      <span className="font-mono text-[13px] font-semibold" style={{ color: on ? "var(--green)" : "var(--mute)" }}>
        {on ? "1" : "0"}
      </span>
    </button>
  );
}

/* ---------------- tab strip ---------------- */

export function Tabs<T extends string>({
  items,
  value,
  onChange,
  className = "",
}: {
  items: { id: T; label: string; icon?: IconName; badge?: ReactNode }[];
  value: T;
  onChange: (v: T) => void;
  className?: string;
}) {
  return (
    <div className={`flex gap-1 overflow-x-auto scroll-thin ${className}`} role="tablist">
      {items.map((it) => {
        const active = it.id === value;
        return (
          <button
            key={it.id}
            role="tab"
            aria-selected={active}
            onClick={() => onChange(it.id)}
            className={[
              "group relative flex shrink-0 items-center gap-2 rounded-[3px] border px-3 py-2 font-mono text-[10.5px] uppercase tracking-[0.14em] transition-all duration-200 focus-ring",
              active
                ? "border-cyan/60 bg-cyan/12 text-cyan shadow-[0_0_22px_-10px_var(--cyan)]"
                : "border-line bg-panel2/40 text-dim hover:border-cyan/35 hover:text-fg",
            ].join(" ")}
          >
            {it.icon && <Icon name={it.icon} size={13} />}
            {it.label}
            {it.badge}
            {active && <span className="absolute inset-x-2 -bottom-[1px] h-[2px] bg-cyan" />}
          </button>
        );
      })}
    </div>
  );
}

/* ---------------- empty / loading states ---------------- */

export function EmptyState({
  icon = "search",
  title,
  body,
  action,
}: {
  icon?: IconName;
  title: string;
  body?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 px-6 py-16 text-center anim-pop">
      <div className="relative">
        <div className="absolute inset-0 rounded-full bg-cyan/10 blur-xl" />
        <div className="relative grid h-14 w-14 place-items-center rounded-full border border-line bg-panel2 text-cyan">
          <Icon name={icon} size={24} />
        </div>
      </div>
      <h4 className="font-display text-[15px] font-semibold uppercase tracking-[0.14em] text-fg">{title}</h4>
      {body && <p className="max-w-sm text-[12.5px] leading-relaxed text-dim">{body}</p>}
      {action}
    </div>
  );
}

export function Skeleton({ className = "" }: { className?: string }) {
  return <div className={`skeleton rounded-[3px] ${className}`} />;
}

export function Spinner({ size = 18 }: { size?: number }) {
  return (
    <span
      className="anim-spin inline-block rounded-full border-2 border-line border-t-cyan"
      style={{ width: size, height: size }}
    />
  );
}

/* ---------------- stat tile ---------------- */

export function Stat({ label, value, tone = "cyan" }: { label: string; value: ReactNode; tone?: Tone }) {
  return (
    <div className="panel rounded-[3px] px-3 py-2">
      <div className="hud">{label}</div>
      <div className="mt-0.5 font-display text-[19px] font-bold leading-none" style={{ color: `var(--${tone === "dim" ? "dim" : tone})` }}>
        {value}
      </div>
    </div>
  );
}
