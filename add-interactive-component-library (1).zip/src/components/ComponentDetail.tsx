/**
 * DigiLab Pro — ComponentDetail.tsx
 * The six-part detail view: Overview · 3D Lab · Truth Table · Theory ·
 * Parts · Learning. Every panel is driven by the same netlist + kernel.
 */
import { useMemo, useState } from "react";
import type { ComponentDoc } from "@/data/library";
import { CATEGORY_MAP } from "@/data/library";
import type { Build } from "@/sim/logic";
import type { SimSession } from "@/hooks/useSimSession";
import type { ThemeName } from "@/sim/kit";
import { CircuitSymbol } from "./CircuitSymbol";
import { LogicDiagram } from "./LogicDiagram";
import { SimStage } from "./SimStage";
import { TruthTable } from "./TruthTable";
import { Badge, Btn, Led, Panel } from "./ui";
import { Icon, type IconName } from "./Icons";

type Tab = "overview" | "lab" | "table" | "theory" | "parts" | "learning";

const TABS: { id: Tab; label: string; icon: IconName }[] = [
  { id: "overview", label: "Overview", icon: "info" },
  { id: "lab", label: "3D Lab", icon: "cube" },
  { id: "table", label: "Truth Table", icon: "table" },
  { id: "theory", label: "Theory", icon: "book" },
  { id: "parts", label: "Parts", icon: "cpu" },
  { id: "learning", label: "Learning", icon: "graduation" },
];

export function ComponentDetail({
  doc,
  build,
  session,
  theme,
  onBack,
  favorite,
  onToggleFavorite,
  onOpenTab,
}: {
  doc: ComponentDoc;
  build: Build | undefined;
  session: SimSession;
  theme: ThemeName;
  onBack: () => void;
  favorite: boolean;
  onToggleFavorite: () => void;
  onOpenTab?: (t: Tab) => void;
}) {
  const [tab, setTab] = useState<Tab>("overview");
  const cat = CATEGORY_MAP[doc.category];
  void onOpenTab;

  const facts = useMemo(() => {
    if (!build) return [];
    const gates = build.nodes.filter((n) => n.kind === "GATE").length;
    const ffs = build.nodes.filter((n) => n.kind === "FF").length;
    const mems = build.nodes.filter((n) => n.kind === "MEM").length;
    return [
      { k: "Category", v: cat.name },
      { k: "IC family", v: doc.ic },
      { k: "Controls", v: `${build.controls.length}` },
      { k: "Readouts", v: `${build.readouts.length}` },
      { k: "Timing", v: build.clocked ? "clocked (edge)" : "combinational" },
      { k: "Devices", v: `${gates} gates · ${ffs} FF · ${mems} mem` },
      { k: "Model fidelity", v: doc.fidelity },
      { k: "Difficulty", v: `Level ${doc.difficulty} / 3` },
    ];
  }, [build, doc, cat]);

  return (
    <div className="anim-in flex h-full flex-col">
      {/* ---------------- header ---------------- */}
      <header className="shrink-0 border-b border-line bg-panel/60 px-4 py-3 sm:px-6">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <Btn size="xs" variant="ghost" icon="chevronLeft" onClick={onBack} title="Back to library">
                Library
              </Btn>
              <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-mute">
                <span style={{ color: cat.accent }}>{cat.name}</span>
                <span className="mx-1.5 opacity-50">/</span>
                <span className="text-dim">{doc.id}</span>
              </span>
            </div>
            <div className="mt-1.5 flex flex-wrap items-center gap-3">
              <h1 className="font-display text-[24px] font-bold uppercase leading-none tracking-[0.06em] text-fg sm:text-[30px]">
                {doc.name}
              </h1>
              <span className="flex items-center gap-1.5">
                <Led on={Boolean(build)} size={8} />
                <span className="font-mono text-[9.5px] uppercase tracking-[0.14em] text-green">
                  {build ? "simulation ready" : "model pending"}
                </span>
              </span>
            </div>
            <p className="mt-2 max-w-3xl text-[13px] leading-relaxed text-dim">{doc.short}</p>
          </div>

          <div className="flex shrink-0 flex-wrap items-center gap-1.5">
            <Btn size="sm" variant={favorite ? "solid" : "outline"} icon={favorite ? "starFilled" : "star"} onClick={onToggleFavorite}>
              {favorite ? "Starred" : "Favourite"}
            </Btn>
            <Btn size="sm" variant="accent" icon="cube" onClick={() => setTab("lab")}>
              Launch 3D lab
            </Btn>
          </div>
        </div>

        <div className="mt-3.5 flex flex-wrap gap-1.5">
          {TABS.map((t) => {
            const active = tab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={[
                  "relative flex items-center gap-2 rounded-[3px] border px-3 py-2 font-mono text-[10.5px] uppercase tracking-[0.14em] transition-all duration-200 focus-ring",
                  active
                    ? "border-cyan/60 bg-cyan/12 text-cyan shadow-[0_0_22px_-10px_var(--cyan)]"
                    : "border-line bg-panel2/40 text-dim hover:border-cyan/35 hover:text-fg",
                ].join(" ")}
              >
                <Icon name={t.icon} size={13} />
                {t.label}
                {active && <span className="absolute inset-x-2 -bottom-[1px] h-[2px] bg-cyan" />}
              </button>
            );
          })}
        </div>
      </header>

      {/* ---------------- body ---------------- */}
      <div className="scroll-thin flex-1 overflow-y-auto">
        <div className="mx-auto grid max-w-[1500px] gap-4 p-4 sm:p-6 xl:grid-cols-[minmax(0,1fr)_292px]">
          <div className="min-w-0 space-y-4">
            {tab === "overview" && <OverviewTab doc={doc} build={build} session={session} onTab={setTab} />}
            {tab === "lab" &&
              (build ? (
                <>
                  <SimStage build={build} session={session} theme={theme} />
                  <Panel title="Live logic diagram" icon="layers" right={<Badge tone="cyan">schematic probe</Badge>}>
                    <LogicDiagram build={build} sim={session.sim ?? undefined} onToggle={(id, bit) => session.toggle(id, bit)} />
                  </Panel>
                </>
              ) : (
                <PendingModel doc={doc} />
              ))}
            {tab === "table" &&
              (build ? (
                <TruthTable build={build} sim={session.sim} version={session.version} step={session.step} onApply={session.applyRow} />
              ) : (
                <PendingModel doc={doc} />
              ))}
            {tab === "theory" && <TheoryTab doc={doc} build={build} session={session} />}
            {tab === "parts" && <PartsTab doc={doc} build={build} />}
            {tab === "learning" && <LearningTab doc={doc} />}
          </div>

          {/* ---------------- right rail ---------------- */}
          <aside className="space-y-4 xl:sticky xl:top-0 xl:self-start">
            <Panel title="Specification" icon="cpu">
              <dl className="space-y-2">
                {facts.map((f) => (
                  <div key={f.k} className="flex items-baseline justify-between gap-3 border-b border-line/50 pb-1.5 last:border-0">
                    <dt className="hud">{f.k}</dt>
                    <dd className="text-right font-mono text-[11px] text-fg">{f.v}</dd>
                  </div>
                ))}
              </dl>
            </Panel>

            <Panel title="Boolean expression" icon="zap">
              <p className="rounded-[3px] border border-cyan/25 bg-cyan/6 p-2.5 font-mono text-[12px] leading-relaxed text-cyan">
                {doc.boolean}
              </p>
            </Panel>

            <Panel title="Tags" icon="filter">
              <div className="flex flex-wrap gap-1.5">
                {doc.tags.map((t) => (
                  <Badge key={t} tone="dim">
                    {t}
                  </Badge>
                ))}
              </div>
            </Panel>

            <Panel title="Applications" icon="target" bodyClass="p-3.5">
              <ul className="space-y-1.5">
                {doc.applications.slice(0, 4).map((a) => (
                  <li key={a} className="flex gap-2 text-[11.5px] leading-relaxed text-dim">
                    <span className="mt-[6px] h-1 w-1 shrink-0 rounded-full bg-cyan" />
                    {a}
                  </li>
                ))}
              </ul>
            </Panel>
          </aside>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */



function OverviewTab({
  doc,
  build,
  session,
  onTab,
}: {
  doc: ComponentDoc;
  build?: Build;
  session: SimSession;
  onTab: (t: Tab) => void;
}) {
  return (
    <>
      <div className="grid gap-4 md:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
        <Panel title="Description" icon="info">
          <p className="text-[13px] leading-[1.75] text-dim">{doc.description}</p>
          <div className="mt-3 flex flex-wrap gap-1.5">
            <Badge tone="green" icon="check">
              3D model
            </Badge>
            <Badge tone="cyan" icon="table">
              live truth table
            </Badge>
            <Badge tone="amber" icon="layers">
              {doc.fidelity}
            </Badge>
          </div>
        </Panel>

        <Panel title="Circuit symbol" icon="layers" right={<span className="hud">IEEE / ANSI</span>}>
          <div className="rounded-[3px] border border-line bg-panel2/50 p-2">
            <CircuitSymbol doc={doc} build={build} />
          </div>
        </Panel>
      </div>

      <Panel title="Working principle" icon="wrench">
        <p className="text-[13px] leading-[1.75] text-dim">{doc.working}</p>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <div className="rounded-[3px] border border-cyan/25 bg-cyan/6 p-3">
            <div className="hud mb-1">Boolean expression</div>
            <p className="font-mono text-[12.5px] leading-relaxed text-cyan">{doc.boolean}</p>
          </div>
          <div className="rounded-[3px] border border-line bg-panel2/60 p-3">
            <div className="hud mb-1">Typical package</div>
            <p className="font-mono text-[12.5px] leading-relaxed text-fg">{doc.ic}</p>
          </div>
        </div>
      </Panel>

      {build && (
        <Panel
          title="Quick probe"
          icon="zap"
          right={
            <Btn size="xs" variant="accent" icon="cube" onClick={() => onTab("lab")}>
              Full 3D lab
            </Btn>
          }
        >
          <LogicDiagram build={build} sim={session.sim ?? undefined} onToggle={(id) => session.toggle(id)} className="max-h-[320px]" />
          <p className="mt-2 text-[11.5px] text-mute">
            Click any input block to drive the netlist — wires light up with the real signal state.
          </p>
        </Panel>
      )}
    </>
  );
}

function TheoryTab({ doc, build, session }: { doc: ComponentDoc; build?: Build; session: SimSession }) {
  return (
    <>
      <Panel title="Definition" icon="book">
        <p className="text-[13px] leading-[1.75] text-dim">{doc.description}</p>
      </Panel>

      <Panel title="Working principle" icon="wrench">
        <p className="text-[13px] leading-[1.75] text-dim">{doc.working}</p>
      </Panel>

      <div className="grid gap-4 md:grid-cols-2">
        <Panel title="Boolean expression" icon="zap">
          <p className="rounded-[3px] border border-cyan/25 bg-cyan/6 p-3 font-mono text-[13px] leading-relaxed text-cyan">
            {doc.boolean}
          </p>
          {build?.note && <p className="mt-2.5 text-[11.5px] leading-relaxed text-mute">{build.note}</p>}
        </Panel>
        <Panel title="Symbol" icon="layers">
          <div className="rounded-[3px] border border-line bg-panel2/50 p-2">
            <CircuitSymbol doc={doc} build={build} height={130} />
          </div>
        </Panel>
      </div>

      {build && (
        <Panel title="Logic diagram" icon="grid" right={<Badge tone="green">generated from netlist</Badge>}>
          <LogicDiagram build={build} sim={session.sim ?? undefined} onToggle={(id) => session.toggle(id)} />
          <p className="mt-2 text-[11.5px] leading-relaxed text-mute">
            This diagram is rendered directly from the same netlist the 3D bench and truth table use — the gate count, pin
            names and interconnect are the circuit that is actually being simulated.
          </p>
        </Panel>
      )}

      <Panel title="Practical applications" icon="target">
        <ul className="grid gap-2 sm:grid-cols-2">
          {doc.applications.map((a) => (
            <li key={a} className="flex gap-2.5 rounded-[3px] border border-line bg-panel2/40 p-2.5 text-[12px] leading-relaxed text-dim">
              <Icon name="check" size={13} className="mt-[2px] shrink-0 text-green" />
              {a}
            </li>
          ))}
        </ul>
      </Panel>
    </>
  );
}

function PartsTab({ doc, build }: { doc: ComponentDoc; build?: Build }) {
  return (
    <>
      <Panel title="Bill of materials" icon="cpu" right={<Badge tone="cyan">{doc.parts.length} line items</Badge>}>
        <div className="overflow-hidden rounded-[3px] border border-line">
          <table className="w-full border-collapse text-left">
            <thead>
              <tr className="bg-panel2/70 font-mono text-[9.5px] uppercase tracking-[0.14em] text-mute">
                <th className="px-3 py-2 font-normal">Component</th>
                <th className="px-3 py-2 font-normal">Qty</th>
                <th className="px-3 py-2 font-normal">Function in the circuit</th>
              </tr>
            </thead>
            <tbody>
              {doc.parts.map((p) => (
                <tr key={p.name} className="border-t border-line/60 transition-colors hover:bg-cyan/6">
                  <td className="px-3 py-2 text-[12.5px] font-medium text-fg">{p.name}</td>
                  <td className="whitespace-nowrap px-3 py-2 font-mono text-[11.5px] text-cyan">{p.qty}</td>
                  <td className="px-3 py-2 text-[12px] leading-relaxed text-dim">{p.fn}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      {build && (
        <Panel title="Silicon on the bench" icon="layers">
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {build.nodes
              .filter((n) => ["GATE", "FF", "MEM"].includes(n.kind))
              .map((n, i) => (
                <div key={`${n.id}-${i}`} className="flex items-center gap-2.5 rounded-[3px] border border-line bg-panel2/40 p-2.5">
                  <span className="grid h-8 w-10 shrink-0 place-items-center rounded-[2px] border border-line bg-panel font-mono text-[9px] text-cyan">
                    {n.part}
                  </span>
                  <span className="min-w-0">
                    <span className="block truncate font-mono text-[11px] uppercase tracking-[0.1em] text-fg">
                      {n.kind === "GATE" ? `${n.gate} gate` : n.kind === "FF" ? `${n.ff} flip-flop${(n.bits ?? 1) > 1 ? ` ×${n.bits}` : ""}` : `${n.mem?.kind} array`}
                    </span>
                    <span className="block truncate text-[10.5px] text-mute">{n.label}</span>
                  </span>
                </div>
              ))}
          </div>
        </Panel>
      )}
    </>
  );
}

function LearningTab({ doc }: { doc: ComponentDoc }) {
  return (
    <>
      <Panel title="Learning objectives" icon="graduation">
        <ol className="space-y-2">
          {doc.objectives.map((o, i) => (
            <li key={o} className="flex gap-3 rounded-[3px] border border-line bg-panel2/40 p-2.5">
              <span className="grid h-6 w-6 shrink-0 place-items-center rounded-[2px] border border-cyan/40 bg-cyan/10 font-mono text-[11px] text-cyan">
                {i + 1}
              </span>
              <span className="text-[12.5px] leading-relaxed text-dim">{o}</span>
            </li>
          ))}
        </ol>
      </Panel>

      <Panel title="Practical examples" icon="target">
        <div className="grid gap-3 md:grid-cols-2">
          {doc.examples.map((e) => (
            <div key={e.title} className="rounded-[3px] border border-line bg-panel2/40 p-3">
              <h4 className="font-display text-[12.5px] font-semibold uppercase tracking-[0.12em] text-green">{e.title}</h4>
              <p className="mt-1.5 text-[12px] leading-relaxed text-dim">{e.body}</p>
            </div>
          ))}
        </div>
      </Panel>

      <Panel title="Important notes" icon="alert">
        <ul className="space-y-2">
          {doc.notes.map((n) => (
            <li key={n} className="flex gap-2.5 rounded-[3px] border border-amber/25 bg-amber/6 p-2.5 text-[12px] leading-relaxed text-dim">
              <Icon name="alert" size={13} className="mt-[2px] shrink-0 text-amber" />
              {n}
            </li>
          ))}
        </ul>
      </Panel>
    </>
  );
}

function PendingModel({ doc }: { doc: ComponentDoc }) {
  return (
    <Panel title="Model status" icon="alert">
      <div className="flex flex-col items-start gap-3 rounded-[3px] border border-amber/30 bg-amber/6 p-4">
        <Icon name="alert" size={22} className="text-amber" />
        <div>
          <h4 className="font-display text-[13px] font-semibold uppercase tracking-[0.14em] text-amber">
            3D model not yet implemented
          </h4>
          <p className="mt-1.5 max-w-xl text-[12.5px] leading-relaxed text-dim">
            {doc.name} is documented in the catalogue but its gate-level netlist has not been authored yet, so the bench and
            truth table are unavailable. Everything else on this page — overview, theory, symbol, parts and learning material
            — is complete.
          </p>
        </div>
      </div>
    </Panel>
  );
}
