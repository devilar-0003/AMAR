/**
 * DigiLab Pro — CircuitSymbol.tsx
 * IEEE/ANSI-style symbols drawn from the *actual* build definition, so the
 * pin names always match the simulation.
 */
import type { Build } from "@/sim/logic";
import type { ComponentDoc } from "@/data/library";

const pinLabel = (b: Build, id: string) => b.colLabels?.[id] ?? b.nodes.find((n) => n.id === id)?.label ?? id;

function shortLabel(b: Build, id: string, fallback: string) {
  const l = pinLabel(b, id);
  if (l.length <= 8) return l;
  return fallback;
}

export function CircuitSymbol({
  doc,
  build,
  height = 150,
}: {
  doc: ComponentDoc;
  build?: Build;
  height?: number;
}) {
  if (!build) return <FallbackSymbol doc={doc} height={height} />;
  const inputs = build.controls.filter((c) => build.nodes.find((n) => n.id === c)?.kind !== "CLK");
  const hasClock = build.clocked;
  const outputs = build.readouts;
  const pins = Math.max(inputs.length + (hasClock ? 1 : 0), outputs.length, 2);
  const h = Math.max(height, pins * 26 + 46);
  const w = 280;
  const cy = h / 2;
  const left = 78;
  const right = w - 62;

  const inY = (i: number) => cy - ((pins - 1) * 26) / 2 + i * 26;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full" style={{ height: h }} role="img" aria-label={`${doc.name} circuit symbol`}>
      <defs>
        <linearGradient id={`symfill-${doc.id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="var(--panel3)" />
          <stop offset="100%" stopColor="var(--panel2)" />
        </linearGradient>
      </defs>

      {/* input / output leads */}
      {inputs.map((id, i) => {
        const y = inY(i);
        return (
          <g key={`in-${id}`}>
            <line x1={left - 46} y1={y} x2={98} y2={y} stroke="var(--dim)" strokeWidth={1.4} />
            <text x={left - 52} y={y + 3.5} textAnchor="end" fontSize={10} fill="var(--dim)" fontFamily="var(--font-mono)">
              {shortLabel(build, id, id)}
            </text>
          </g>
        );
      })}
      {hasClock && (
        <g>
          <line x1={left - 46} y1={inY(inputs.length)} x2={98} y2={inY(inputs.length)} stroke="var(--cyan)" strokeWidth={1.4} />
          <text x={left - 52} y={inY(inputs.length) + 3.5} textAnchor="end" fontSize={10} fill="var(--cyan)" fontFamily="var(--font-mono)">
            CLK
          </text>
        </g>
      )}
      {outputs.map((id, i) => {
        const y = cy - ((outputs.length - 1) * 26) / 2 + i * 26;
        return (
          <g key={`out-${id}`}>
            <line x1={w - 108} y1={y} x2={right + 46} y2={y} stroke="var(--dim)" strokeWidth={1.4} />
            <text x={right + 52} y={y + 3.5} fontSize={10} fill="var(--fg)" fontFamily="var(--font-mono)">
              {shortLabel(build, id, id)}
            </text>
          </g>
        );
      })}

      <SymbolBody doc={doc} build={build} cy={cy} w={w} />
    </svg>
  );
}

function SymbolBody({ doc, build, cy, w }: { doc: ComponentDoc; build: Build; cy: number; w: number }) {
  const cx = w / 2;
  const stroke = "var(--fg)";
  const fill = `url(#symfill-${doc.id})`;

  if (doc.symbol === "gate" && doc.gate) {
    const g = doc.gate;
    const bw = 54;
    const bh = 46;
    const x0 = cx - bw / 2;
    const y0 = cy - bh / 2;
    const bubble = g === "NAND" || g === "NOR" || g === "NOT" || g === "XNOR";
    const shape = () => {
      switch (g) {
        case "AND":
        case "NAND":
          return <path d={`M${x0},${y0} H${cx - 4} A${bh / 2},${bh / 2} 0 0 1 ${cx - 4},${y0 + bh} H${x0} Z`} fill={fill} stroke={stroke} strokeWidth={1.8} />;
        case "OR":
        case "NOR":
        case "XOR":
        case "XNOR":
          return (
            <g>
              {g === "XOR" || g === "XNOR" ? (
                <path d={`M${x0 - 9},${y0} Q${x0 + 11},${cy} ${x0 - 9},${y0 + bh}`} fill="none" stroke={stroke} strokeWidth={1.8} />
              ) : null}
              <path
                d={`M${x0},${y0} Q${x0 + 20},${cy} ${x0},${y0 + bh} Q${cx + 12},${y0 + bh} ${cx + bw / 2 - 4},${cy} Q${cx + 12},${y0} ${x0},${y0} Z`}
                fill={fill}
                stroke={stroke}
                strokeWidth={1.8}
              />
            </g>
          );
        case "NOT":
        default:
          return <path d={`M${x0},${y0} L${cx + bw / 2 - 12},${cy} L${x0},${y0 + bh} Z`} fill={fill} stroke={stroke} strokeWidth={1.8} />;
      }
    };
    return (
      <g>
        {shape()}
        {bubble && <circle cx={cx + bw / 2 - 1} cy={cy} r={5.4} fill="var(--panel)" stroke={stroke} strokeWidth={1.8} />}
        <text x={cx - 2} y={cy + 34} textAnchor="middle" fontSize={9.5} fill="var(--mute)" fontFamily="var(--font-mono)">
          {build.nodes.find((n) => n.kind === "GATE")?.part ?? ""}
        </text>
      </g>
    );
  }

  if (doc.symbol === "ff") {
    const bw = 78;
    const bh = Math.max(74, build.controls.length * 22 + 34);
    const x0 = cx - bw / 2;
    const y0 = cy - bh / 2;
    return (
      <g>
        <rect x={x0} y={y0} width={bw} height={bh} rx={3} fill={fill} stroke={stroke} strokeWidth={1.8} />
        <text x={cx} y={y0 + 17} textAnchor="middle" fontSize={11.5} fontWeight={600} fill="var(--fg)" fontFamily="var(--font-display)">
          {doc.name.replace(" Flip-Flop", "")}
        </text>
        <text x={cx} y={y0 + 31} textAnchor="middle" fontSize={8} fill="var(--mute)" fontFamily="var(--font-mono)">
          {build.nodes.find((n) => n.kind === "FF")?.part}
        </text>
        {build.controls
          .filter((c) => build.nodes.find((n) => n.id === c)?.kind !== "CLK")
          .map((c, i) => (
            <text key={c} x={x0 + 7} y={y0 + 48 + i * 16} fontSize={9.5} fill="var(--dim)" fontFamily="var(--font-mono)">
              {c}
            </text>
          ))}
        <path d={`M${x0},${y0 + bh - 20} l8,5 l-8,5`} fill="none" stroke="var(--cyan)" strokeWidth={1.6} />
        <text x={x0 + bw - 7} y={y0 + 48} textAnchor="end" fontSize={9.5} fill="var(--green)" fontFamily="var(--font-mono)">
          Q
        </text>
        <text x={x0 + bw - 7} y={y0 + 64} textAnchor="end" fontSize={9.5} fill="var(--green)" fontFamily="var(--font-mono)">
          Q̄
        </text>
      </g>
    );
  }

  if (doc.symbol === "memory") {
    const bw = 84;
    const bh = 92;
    const x0 = cx - bw / 2;
    const y0 = cy - bh / 2;
    const mem = build.nodes.find((n) => n.kind === "MEM");
    const cells = 16;
    return (
      <g>
        <rect x={x0} y={y0} width={bw} height={bh} rx={3} fill={fill} stroke={stroke} strokeWidth={1.8} />
        {Array.from({ length: cells }).map((_, i) => {
          const r = Math.floor(i / 4);
          const c = i % 4;
          return (
            <rect
              key={i}
              x={x0 + 16 + c * 14}
              y={y0 + 30 + r * 12}
              width={10}
              height={8}
              rx={1}
              fill={i % 5 === 0 ? "var(--green)" : "var(--panel)"}
              stroke="var(--line)"
              strokeWidth={0.8}
              opacity={i % 5 === 0 ? 0.9 : 1}
            />
          );
        })}
        <text x={cx} y={y0 + 18} textAnchor="middle" fontSize={11} fontWeight={600} fill="var(--fg)" fontFamily="var(--font-display)">
          {mem?.mem?.kind ?? "MEM"}
        </text>
        <text x={cx} y={y0 + bh - 8} textAnchor="middle" fontSize={8.5} fill="var(--mute)" fontFamily="var(--font-mono)">
          {mem?.mem?.words}×{mem?.mem?.width} · {mem?.part}
        </text>
      </g>
    );
  }

  /* generic MSI block (adder, mux, decoder, counter, register, …) */
  const bw = 92;
  const rows = Math.max(build.controls.length, build.readouts.length, 3);
  const bh = Math.max(70, rows * 20 + 26);
  const x0 = cx - bw / 2;
  const y0 = cy - bh / 2;
  const glyph = doc.symbol === "adder" ? (doc.id.includes("sub") ? "Σ / −" : "Σ") : "";
  return (
    <g>
      <rect x={x0} y={y0} width={bw} height={bh} rx={4} fill={fill} stroke={stroke} strokeWidth={1.8} />
      <text x={cx} y={y0 + 18} textAnchor="middle" fontSize={11} fontWeight={700} fill="var(--fg)" fontFamily="var(--font-display)">
        {doc.name.split(" ")[0].toUpperCase()}
      </text>
      {glyph && (
        <text x={cx} y={cy + 12} textAnchor="middle" fontSize={26} fill="var(--cyan)" fontFamily="var(--font-display)" opacity={0.85}>
          {glyph}
        </text>
      )}
      {build.controls.map((c, i) => (
        <text key={`l-${c}`} x={x0 + 6} y={y0 + 34 + i * 15} fontSize={8.5} fill="var(--dim)" fontFamily="var(--font-mono)">
          {shortLabel(build, c, c)}
        </text>
      ))}
      {build.readouts.map((c, i) => (
        <text key={`r-${c}`} x={x0 + bw - 6} y={y0 + 34 + i * 15} textAnchor="end" fontSize={8.5} fill="var(--green)" fontFamily="var(--font-mono)">
          {shortLabel(build, c, c)}
        </text>
      ))}
      <text x={cx} y={y0 + bh - 7} textAnchor="middle" fontSize={8} fill="var(--mute)" fontFamily="var(--font-mono)">
        {build.nodes.find((n) => n.part)?.part}
      </text>
    </g>
  );
}

function FallbackSymbol({ doc, height }: { doc: ComponentDoc; height: number }) {
  return (
    <svg viewBox="0 0 280 150" className="w-full" style={{ height }} role="img" aria-label={doc.name}>
      <rect x={90} y={35} width={100} height={80} rx={4} fill="var(--panel2)" stroke="var(--line)" strokeWidth={1.6} />
      <text x={140} y={72} textAnchor="middle" fontSize={12} fill="var(--dim)" fontFamily="var(--font-display)">
        {doc.name}
      </text>
      <text x={140} y={92} textAnchor="middle" fontSize={9} fill="var(--mute)" fontFamily="var(--font-mono)">
        {doc.ic}
      </text>
    </svg>
  );
}
