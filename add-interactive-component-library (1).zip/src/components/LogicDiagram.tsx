/**
 * DigiLab Pro — LogicDiagram.tsx
 * Live 2D netlist diagram generated straight from the Build graph using the
 * same layout helpers as the 3D bench. Wires light up with the real signal
 * state produced by LogicSim, so the schematic is a working probe.
 */
import { useMemo } from "react";
import type { Build, GateKind, LNode, Vec } from "@/sim/logic";
import type { LogicSim } from "@/sim/logic";
import { CONST, parseRef, widthOf } from "@/sim/logic";
import { footprint, inputRefs, layoutDepths, layoutLanes } from "@/sim/layout";

const CW = 132;
const CH = 62;

interface Slot {
  x: number;
  y: number;
  w: number;
  h: number;
}

export function LogicDiagram({
  build,
  sim,
  onToggle,
  className = "",
}: {
  build: Build;
  sim?: LogicSim;
  onToggle?: (id: string, bit: number) => void;
  className?: string;
}) {
  const layout = useMemo(() => {
    const depths = layoutDepths(build);
    const lanes = layoutLanes(build);
    const rowsPerCol = new Map<number, number>();
    for (const n of build.nodes) {
      const d = depths.get(n.id) ?? 0;
      rowsPerCol.set(d, Math.max(rowsPerCol.get(d) ?? 0, (lanes.get(n.id) ?? 0) + 1));
    }
    const cols = Math.max(...depths.values()) + 1;
    const rows = Math.max(...[...rowsPerCol.values()], 1);
    const slots = new Map<string, Slot>();
    for (const n of build.nodes) {
      const d = depths.get(n.id) ?? 0;
      const l = lanes.get(n.id) ?? 0;
      const rowCount = rowsPerCol.get(d) ?? 1;
      const colHeight = rowCount * CH;
      const y0 = 30 + ((rows * CH - colHeight) / 2);
      slots.set(n.id, {
        x: 34 + d * CW,
        y: y0 + l * CH + CH / 2,
        w: nodeW(n),
        h: nodeH(n),
      });
    }
    return { slots, cols, rows, width: 34 * 2 + cols * CW, height: 60 + rows * CH };
  }, [build]);

  const edges = useMemo(() => {
    const list: { src: string; bit: number; dst: string; clock?: boolean }[] = [];
    for (const n of build.nodes) {
      for (const { ref, clock } of inputRefs(n)) {
        if (CONST(ref) !== null) continue;
        const { id, bit } = parseRef(ref);
        const src = build.nodes.find((x) => x.id === id);
        if (!src) continue;
        const sw = widthOf(src);
        if (bit >= 0) list.push({ src: id, bit, dst: n.id, clock });
        else if (sw > 1 && (n.kind === "MEM" || n.kind === "OUTBUS"))
          for (let b = 0; b < sw; b++) list.push({ src: id, bit: b, dst: n.id, clock });
        else list.push({ src: id, bit: 0, dst: n.id, clock });
      }
    }
    const outIdx = new Map<string, number>();
    const inIdx = new Map<string, number>();
    const outN = new Map<string, number>();
    const inN = new Map<string, number>();
    for (const e of list) {
      outN.set(e.src, (outN.get(e.src) ?? 0) + 1);
      inN.set(e.dst, (inN.get(e.dst) ?? 0) + 1);
    }
    return list.map((e) => {
      const oi = outIdx.get(e.src) ?? 0;
      outIdx.set(e.src, oi + 1);
      const ii = inIdx.get(e.dst) ?? 0;
      inIdx.set(e.dst, ii + 1);
      const a = layout.slots.get(e.src)!;
      const b = layout.slots.get(e.dst)!;
      const spread = (n: number, cnt: number) => (cnt <= 1 ? 0 : (n / (cnt - 1) - 0.5) * Math.min(22, cnt * 9));
      return {
        ...e,
        x0: a.x + a.w / 2,
        y0: a.y + spread(oi, outN.get(e.src) ?? 1),
        x1: b.x - b.w / 2,
        y1: b.y + spread(ii, inN.get(e.dst) ?? 1),
      };
    });
  }, [build, layout]);

  const val = (id: string): Vec => (sim ? sim.vec(id) : []);
  const state = (id: string): Vec => (sim ? sim.readState(id) : []);

  return (
    <div className={`overflow-auto scroll-thin ${className}`}>
      <svg
        viewBox={`0 0 ${layout.width} ${layout.height}`}
        style={{ minWidth: Math.min(layout.width, 640), width: "100%", height: "auto" }}
        role="img"
        aria-label={`${build.title} logic diagram`}
      >
        <defs>
          <pattern id="ld-grid" width="22" height="22" patternUnits="userSpaceOnUse">
            <path d="M22 0H0V22" fill="none" stroke="var(--grid)" strokeWidth="1" />
          </pattern>
        </defs>
        <rect x="0" y="0" width={layout.width} height={layout.height} fill="url(#ld-grid)" />

        {/* wires */}
        {edges.map((e, i) => {
          const live = val(e.src)[e.bit] ?? state(e.src)[e.bit] ?? 0;
          const mid = (e.x0 + e.x1) / 2;
          const d = `M${e.x0},${e.y0} H${mid - 6} Q${mid},${e.y0} ${mid},${(e.y0 + e.y1) / 2} Q${mid},${e.y1} ${mid + 6},${e.y1} H${e.x1}`;
          return (
            <g key={i}>
              <path
                d={d}
                fill="none"
                stroke={live ? (e.clock ? "var(--cyan)" : "var(--green)") : "var(--line)"}
                strokeWidth={live ? 2 : 1.4}
                strokeDasharray={e.clock ? "5 3" : undefined}
                opacity={live ? 0.95 : 0.75}
                style={{ transition: "stroke 180ms ease, stroke-width 180ms ease" }}
              />
              {live ? <circle cx={e.x1} cy={e.y1} r={2.6} fill={e.clock ? "var(--cyan)" : "var(--green)"} /> : null}
            </g>
          );
        })}

        {/* nodes */}
        {build.nodes.map((n) => {
          const s = layout.slots.get(n.id)!;
          const v = n.kind === "FF" ? state(n.id) : val(n.id);
          const clickable = Boolean(onToggle) && ["IN", "INBUS", "CLK"].includes(n.kind);
          return (
            <g
              key={n.id}
              transform={`translate(${s.x},${s.y})`}
              style={{ cursor: clickable ? "pointer" : "default" }}
              onClick={() => clickable && onToggle?.(n.id, 0)}
            >
              <NodeGlyph n={n} s={s} v={v} />
            </g>
          );
        })}
      </svg>
    </div>
  );
}

function nodeW(n: LNode) {
  const f = footprint(n);
  if (n.kind === "INBUS") return Math.max(56, 20 + (n.bits ?? 4) * 12);
  if (n.kind === "MEM") return 74;
  if (n.kind === "OUTBUS") return Math.max(52, 18 + (n.bits ?? 4) * 11);
  return Math.min(78, 34 + Math.max(n.label.length, n.part?.length ?? 0) * 4.4 + f.w * 2);
}
function nodeH(n: LNode) {
  if (n.kind === "MEM") return 46;
  if (n.kind === "FF") return 40;
  if (n.kind === "INBUS" || n.kind === "OUTBUS") return 34;
  return 30;
}

function NodeGlyph({ n, s, v }: { n: LNode; s: Slot; v: Vec }) {
  const w = s.w;
  const h = s.h;
  const on = (v[0] ?? 0) === 1;
  const anyOn = v.some((b) => b === 1);

  const box = (fillVar: string, strokeVar: string) => (
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={5} fill={fillVar} stroke={strokeVar} strokeWidth={1.5} />
  );

  if (n.kind === "IN" || n.kind === "CLK") {
    return (
      <g>
        {box(on ? "color-mix(in srgb, var(--green) 22%, var(--panel))" : "var(--panel2)", on ? "var(--green)" : "var(--line)")}
        <text x={0} y={-1} textAnchor="middle" fontSize={10} fontFamily="var(--font-mono)" fill="var(--dim)">
          {n.kind === "CLK" ? "CLK" : n.id}
        </text>
        <text x={0} y={11} textAnchor="middle" fontSize={11} fontWeight={700} fontFamily="var(--font-mono)" fill={on ? "var(--green)" : "var(--mute)"}>
          {on ? "1" : "0"}
        </text>
      </g>
    );
  }

  if (n.kind === "INBUS") {
    const bits = n.bits ?? 4;
    return (
      <g>
        {box("var(--panel2)", anyOn ? "var(--green)" : "var(--line)")}
        {Array.from({ length: bits }).map((_, i) => (
          <g key={i}>
            <rect
              x={-w / 2 + 8 + i * ((w - 16) / bits)}
              y={-5}
              width={(w - 16) / bits - 3}
              height={13}
              rx={2}
              fill={v[bits - 1 - i] ? "var(--green)" : "var(--panel3)"}
              opacity={v[bits - 1 - i] ? 0.9 : 1}
            />
          </g>
        ))}
        <text x={0} y={-h / 2 - 5} textAnchor="middle" fontSize={9} fontFamily="var(--font-mono)" fill="var(--mute)">
          {n.label}
        </text>
      </g>
    );
  }

  if (n.kind === "OUT") {
    return (
      <g>
        <circle cx={0} cy={0} r={11} fill={on ? "var(--green)" : "var(--panel3)"} stroke={on ? "var(--green)" : "var(--line)"} strokeWidth={1.5} />
        {on && <circle cx={0} cy={0} r={17} fill="none" stroke="var(--green)" strokeWidth={1} opacity={0.4} />}
        <text x={0} y={3.6} textAnchor="middle" fontSize={9.5} fontWeight={700} fontFamily="var(--font-mono)" fill={on ? "#03150d" : "var(--mute)"}>
          {on ? "1" : "0"}
        </text>
        <text x={0} y={h / 2 + 12} textAnchor="middle" fontSize={9} fontFamily="var(--font-mono)" fill="var(--dim)">
          {n.label}
        </text>
      </g>
    );
  }

  if (n.kind === "OUTBUS") {
    const bits = n.bits ?? 4;
    return (
      <g>
        {box("var(--panel2)", anyOn ? "var(--green)" : "var(--line)")}
        {Array.from({ length: bits }).map((_, i) => (
          <circle
            key={i}
            cx={-w / 2 + 10 + i * ((w - 20) / Math.max(1, bits - 1 || 1))}
            cy={0}
            r={4.2}
            fill={v[bits - 1 - i] ? "var(--green)" : "var(--panel3)"}
            stroke={v[bits - 1 - i] ? "var(--green)" : "var(--line)"}
            strokeWidth={1}
          />
        ))}
        <text x={0} y={-h / 2 - 5} textAnchor="middle" fontSize={9} fontFamily="var(--font-mono)" fill="var(--mute)">
          {n.label}
        </text>
      </g>
    );
  }

  if (n.kind === "GATE") return <MiniGate gate={n.gate ?? "BUF"} part={n.part ?? ""} w={w} h={h} out={v[0] ?? 0} />;

  if (n.kind === "FF") {
    return (
      <g>
        {box("var(--panel)", anyOn ? "var(--green)" : "var(--line)")}
        <text x={0} y={-4} textAnchor="middle" fontSize={10} fontWeight={700} fontFamily="var(--font-display)" fill="var(--fg)">
          {n.ff} FF{n.bits && n.bits > 1 ? ` ×${n.bits}` : ""}
        </text>
        <text x={0} y={9} textAnchor="middle" fontSize={8} fontFamily="var(--font-mono)" fill="var(--mute)">
          {n.part}
        </text>
        <path d={`M${-w / 2},${h / 2 - 11} l6,4 l-6,4`} fill="none" stroke="var(--cyan)" strokeWidth={1.4} />
      </g>
    );
  }

  /* MEM */
  return (
    <g>
      {box("var(--panel)", anyOn ? "var(--green)" : "var(--line)")}
      <text x={0} y={-8} textAnchor="middle" fontSize={9.5} fontWeight={700} fontFamily="var(--font-display)" fill="var(--fg)">
        {n.mem?.kind}
      </text>
      {Array.from({ length: 8 }).map((_, i) => (
        <rect
          key={i}
          x={-w / 2 + 10 + (i % 4) * ((w - 20) / 4)}
          y={-1 + Math.floor(i / 4) * 9}
          width={(w - 20) / 4 - 3}
          height={6}
          rx={1}
          fill={v[i] ? "var(--green)" : "var(--panel3)"}
        />
      ))}
      <text x={0} y={h / 2 + 11} textAnchor="middle" fontSize={8} fontFamily="var(--font-mono)" fill="var(--mute)">
        {n.mem?.words}×{n.mem?.width} · {n.part}
      </text>
    </g>
  );
}

function MiniGate({ gate, part, w, h, out }: { gate: GateKind; part: string; w: number; h: number; out: number }) {
  const hw = w / 2;
  const hh = h / 2;
  const stroke = out ? "var(--green)" : "var(--line)";
  const fill = out ? "color-mix(in srgb, var(--green) 14%, var(--panel))" : "var(--panel)";
  const bubble = gate === "NAND" || gate === "NOR" || gate === "NOT" || gate === "XNOR";
  const tipX = hw - (bubble ? 7 : 0);
  let shape = <path d={`M${-hw},${-hh} H${hw - 12} A${hh},${hh} 0 0 1 ${hw - 12},${hh} H${-hw} Z`} fill={fill} stroke={stroke} strokeWidth={1.5} />;
  if (gate === "OR" || gate === "NOR" || gate === "XOR" || gate === "XNOR") {
    shape = (
      <g>
        {gate.startsWith("X") && <path d={`M${-hw - 5},${-hh} Q${-hw + 6},0 ${-hw - 5},${hh}`} fill="none" stroke={stroke} strokeWidth={1.5} />}
        <path
          d={`M${-hw},${-hh} Q${-hw + 9},0 ${-hw},${hh} Q${hw - 14},${hh} ${tipX},0 Q${hw - 14},${-hh} ${-hw},${-hh} Z`}
          fill={fill}
          stroke={stroke}
          strokeWidth={1.5}
        />
      </g>
    );
  }
  if (gate === "NOT") shape = <path d={`M${-hw},${-hh} L${tipX},0 L${-hw},${hh} Z`} fill={fill} stroke={stroke} strokeWidth={1.5} />;
  return (
    <g>
      {shape}
      {bubble && <circle cx={hw - 4} cy={0} r={3.6} fill="var(--panel)" stroke={stroke} strokeWidth={1.5} />}
      <text x={0} y={3.4} textAnchor="middle" fontSize={8.5} fontWeight={700} fontFamily="var(--font-mono)" fill="var(--fg)">
        {gate}
      </text>
      <text x={0} y={-hh - 5} textAnchor="middle" fontSize={8} fontFamily="var(--font-mono)" fill="var(--mute)">
        {part}
      </text>
    </g>
  );
}
