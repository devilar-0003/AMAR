"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildIds = exports.hasBuild = exports.getBuild = exports.BUILDS = void 0;
/* ---------------- node factories ---------------- */
const SW = (id, label) => ({ id, kind: "IN", label });
const BANK = (id, label, bits) => ({ id, kind: "INBUS", label, bits });
const CLOCK = (id = "CLK") => ({ id, kind: "CLK", label: "CLK" });
const LAMP = (id, label, src) => ({ id, kind: "OUT", label, in: [src] });
const BAR = (id, label, src, bits, disp = "led") => ({
    id,
    kind: "OUTBUS",
    label,
    in: [src],
    bits,
    disp,
});
const G = (id, gate, ins, part, label) => ({
    id,
    kind: "GATE",
    gate,
    in: ins,
    part,
    label: label ?? gate,
});
const FF = (id, ff, clk, ctl, part, label, bits = 1, init) => ({ id, kind: "FF", ff, clk, ctl, part, label, bits, init, edge: "rising" });
const P = {
    AND: "7408",
    AND3: "7411",
    OR: "7432",
    OR3: "7427",
    NOT: "7404",
    NAND: "7400",
    NOR: "7402",
    XOR: "7486",
    XNOR: "74266",
    DFF: "7474",
    JKFF: "7476",
    QUADD: "74175",
    COUNTER: "74161",
    SHIFT: "7495",
    RAM: "2114",
    ROM: "2716",
    SRAM: "6264",
    DRAM: "4116",
};
const gray = (n) => {
    const g = n ^ (n >> 1);
    return [0, 1, 2, 3].map((i) => ((g >> i) & 1));
};
/* ---------------- 1. logic gates ---------------- */
const GATE_PART = {
    AND: P.AND,
    OR: P.OR,
    NOT: P.NOT,
    NAND: P.NAND,
    NOR: P.NOR,
    XOR: P.XOR,
    XNOR: P.XNOR,
};
function gateBuild(id, gate, title) {
    const ins = gate === "NOT" ? ["A"] : ["A", "B"];
    const nodes = [
        ...ins.map((i) => SW(i, `INPUT ${i}`)),
        G("U1", gate, ins, GATE_PART[gate], gate),
        LAMP("Y", "Y", "U1"),
    ];
    if (gate !== "NOT")
        nodes.push(LAMP("YN", "Y′", "U2")),
            nodes.push(G("U2", "NOT", ["U1"], P.NOT, "NOT"));
    return {
        id,
        title,
        nodes,
        controls: ins.map(String),
        readouts: gate === "NOT" ? ["Y"] : ["Y", "YN"],
        tableMode: "combo",
        colLabels: { A: "A", B: "B", Y: "Y", YN: "Y′" },
    };
}
/* ---------------- 2. combinational ---------------- */
const halfAdder = {
    id: "half-adder",
    title: "Half Adder",
    nodes: [
        SW("A", "INPUT A"),
        SW("B", "INPUT B"),
        G("X1", "XOR", ["A", "B"], P.XOR, "SUM ⊕"),
        G("A1", "AND", ["A", "B"], P.AND, "CARRY ∧"),
        LAMP("SUM", "SUM", "X1"),
        LAMP("CARRY", "CARRY", "A1"),
    ],
    controls: ["A", "B"],
    readouts: ["SUM", "CARRY"],
    tableMode: "combo",
    colLabels: { SUM: "SUM", CARRY: "CARRY" },
};
const fullAdder = {
    id: "full-adder",
    title: "Full Adder",
    nodes: [
        SW("A", "INPUT A"),
        SW("B", "INPUT B"),
        SW("CIN", "CARRY IN"),
        G("X1", "XOR", ["A", "B"], P.XOR, "A⊕B"),
        G("X2", "XOR", ["X1", "CIN"], P.XOR, "SUM"),
        G("A1", "AND", ["A", "B"], P.AND, "A·B"),
        G("A2", "AND", ["X1", "CIN"], P.AND, "(A⊕B)·Cin"),
        G("O1", "OR", ["A1", "A2"], P.OR, "CARRY"),
        LAMP("SUM", "SUM", "X2"),
        LAMP("COUT", "CARRY OUT", "O1"),
    ],
    controls: ["A", "B", "CIN"],
    readouts: ["SUM", "COUT"],
    tableMode: "combo",
    colLabels: { A: "A", B: "B", CIN: "Cin", SUM: "SUM", COUT: "Cout" },
};
const halfSub = {
    id: "half-subtractor",
    title: "Half Subtractor",
    nodes: [
        SW("A", "MINUEND A"),
        SW("B", "SUBTRAHEND B"),
        G("X1", "XOR", ["A", "B"], P.XOR, "DIFF"),
        G("N1", "NOT", ["A"], P.NOT, "Ā"),
        G("A1", "AND", ["N1", "B"], P.AND, "BORROW"),
        LAMP("DIFF", "DIFFERENCE", "X1"),
        LAMP("BRW", "BORROW", "A1"),
    ],
    controls: ["A", "B"],
    readouts: ["DIFF", "BRW"],
    tableMode: "combo",
    colLabels: { A: "A", B: "B", DIFF: "DIFF", BRW: "BORROW" },
};
const fullSub = {
    id: "full-subtractor",
    title: "Full Subtractor",
    nodes: [
        SW("A", "MINUEND A"),
        SW("B", "SUBTRAHEND B"),
        SW("BIN", "BORROW IN"),
        G("X1", "XOR", ["A", "B"], P.XOR, "A⊕B"),
        G("X2", "XOR", ["X1", "BIN"], P.XOR, "DIFF"),
        G("N1", "NOT", ["A"], P.NOT, "Ā"),
        G("N2", "NOT", ["X1"], P.NOT, "A⊕B ‾"),
        G("A1", "AND", ["N1", "B"], P.AND, "Ā·B"),
        G("A2", "AND", ["N2", "BIN"], P.AND, "(A⊕B)′·Bin"),
        G("O1", "OR", ["A1", "A2"], P.OR, "BORROW"),
        LAMP("DIFF", "DIFFERENCE", "X2"),
        LAMP("BOUT", "BORROW OUT", "O1"),
    ],
    controls: ["A", "B", "BIN"],
    readouts: ["DIFF", "BOUT"],
    tableMode: "combo",
    colLabels: { A: "A", B: "B", BIN: "Bin", DIFF: "DIFF", BOUT: "Bout" },
};
const mux4 = {
    id: "multiplexer",
    title: "Multiplexer (4:1)",
    nodes: [
        SW("S1", "SELECT S1"),
        SW("S0", "SELECT S0"),
        SW("D0", "DATA D0"),
        SW("D1", "DATA D1"),
        SW("D2", "DATA D2"),
        SW("D3", "DATA D3"),
        G("N1", "NOT", ["S1"], P.NOT, "S̄1"),
        G("N2", "NOT", ["S0"], P.NOT, "S̄0"),
        G("A0", "AND", ["D0", "N1", "N2"], P.AND3, "D0·S̄1·S̄0"),
        G("A1", "AND", ["D1", "N1", "S0"], P.AND3, "D1·S̄1·S0"),
        G("A2", "AND", ["D2", "S1", "N2"], P.AND3, "D2·S1·S̄0"),
        G("A3", "AND", ["D3", "S1", "S0"], P.AND3, "D3·S1·S0"),
        G("O1", "OR", ["A0", "A1", "A2"], P.OR3, "Σ 0-2"),
        G("O2", "OR", ["O1", "A3"], P.OR, "Y"),
        LAMP("Y", "OUTPUT Y", "O2"),
    ],
    controls: ["S1", "S0", "D0", "D1", "D2", "D3"],
    readouts: ["Y"],
    tableMode: "combo",
    colLabels: { S1: "S1", S0: "S0", D0: "D0", D1: "D1", D2: "D2", D3: "D3", Y: "Y" },
    note: "Y = D0·S̄1S̄0 + D1·S̄1S0 + D2·S1S̄0 + D3·S1S0",
};
const demux4 = {
    id: "demultiplexer",
    title: "Demultiplexer (1:4)",
    nodes: [
        SW("I", "DATA INPUT"),
        SW("S1", "SELECT S1"),
        SW("S0", "SELECT S0"),
        G("N1", "NOT", ["S1"], P.NOT, "S̄1"),
        G("N2", "NOT", ["S0"], P.NOT, "S̄0"),
        G("A0", "AND", ["I", "N1", "N2"], P.AND3, "Y0"),
        G("A1", "AND", ["I", "N1", "S0"], P.AND3, "Y1"),
        G("A2", "AND", ["I", "S1", "N2"], P.AND3, "Y2"),
        G("A3", "AND", ["I", "S1", "S0"], P.AND3, "Y3"),
        LAMP("Y0", "Y0", "A0"),
        LAMP("Y1", "Y1", "A1"),
        LAMP("Y2", "Y2", "A2"),
        LAMP("Y3", "Y3", "A3"),
    ],
    controls: ["I", "S1", "S0"],
    readouts: ["Y0", "Y1", "Y2", "Y3"],
    tableMode: "combo",
    colLabels: { I: "I", S1: "S1", S0: "S0", Y0: "Y0", Y1: "Y1", Y2: "Y2", Y3: "Y3" },
};
const encoder42 = {
    id: "encoder",
    title: "Encoder (4-to-2)",
    nodes: [
        SW("D0", "LINE D0"),
        SW("D1", "LINE D1"),
        SW("D2", "LINE D2"),
        SW("D3", "LINE D3"),
        G("O1", "OR", ["D2", "D3"], P.OR, "A1"),
        G("O2", "OR", ["D1", "D3"], P.OR, "A0"),
        G("O3", "OR", ["O1", "O2", "D0"], P.OR3, "VALID"),
        LAMP("A1", "A1 (MSB)", "O1"),
        LAMP("A0", "A0 (LSB)", "O2"),
        LAMP("V", "VALID", "O3"),
    ],
    controls: ["D0", "D1", "D2", "D3"],
    readouts: ["A1", "A0", "V"],
    tableMode: "combo",
    colLabels: { D0: "D0", D1: "D1", D2: "D2", D3: "D3", A1: "A1", A0: "A0", V: "VALID" },
    note: "Assumes one active input line at a time (see priority encoder in Theory).",
};
const decoder24 = {
    id: "decoder",
    title: "Decoder (2-to-4)",
    nodes: [
        SW("A1", "ADDRESS A1"),
        SW("A0", "ADDRESS A0"),
        SW("EN", "ENABLE"),
        G("N1", "NOT", ["A1"], P.NOT, "Ā1"),
        G("N2", "NOT", ["A0"], P.NOT, "Ā0"),
        G("A0g", "AND", ["EN", "N1", "N2"], P.AND3, "Y0"),
        G("A1g", "AND", ["EN", "N1", "A0"], P.AND3, "Y1"),
        G("A2g", "AND", ["EN", "A1", "N2"], P.AND3, "Y2"),
        G("A3g", "AND", ["EN", "A1", "A0"], P.AND3, "Y3"),
        LAMP("Y0", "Y0", "A0g"),
        LAMP("Y1", "Y1", "A1g"),
        LAMP("Y2", "Y2", "A2g"),
        LAMP("Y3", "Y3", "A3g"),
    ],
    controls: ["A1", "A0", "EN"],
    readouts: ["Y0", "Y1", "Y2", "Y3"],
    tableMode: "combo",
    colLabels: { A1: "A1", A0: "A0", EN: "EN", Y0: "Y0", Y1: "Y1", Y2: "Y2", Y3: "Y3" },
};
const comparator = {
    id: "comparator",
    title: "Comparator (2-bit)",
    nodes: [
        SW("A1", "A1"),
        SW("A0", "A0"),
        SW("B1", "B1"),
        SW("B0", "B0"),
        G("N1", "NOT", ["A1"], P.NOT, "Ā1"),
        G("N2", "NOT", ["A0"], P.NOT, "Ā0"),
        G("N3", "NOT", ["B1"], P.NOT, "B̄1"),
        G("N4", "NOT", ["B0"], P.NOT, "B̄0"),
        G("X0", "XNOR", ["A0", "B0"], P.XNOR, "A0⊙B0"),
        G("X1", "XNOR", ["A1", "B1"], P.XNOR, "A1⊙B1"),
        G("EQ1", "AND", ["X0", "X1"], P.AND, "EQ"),
        G("GT1", "AND", ["A1", "N3"], P.AND, "A1·B̄1"),
        G("GT2", "AND", ["A0", "N4"], P.AND, "A0·B̄0"),
        G("GT3", "AND", ["X1", "GT2"], P.AND, "(A1⊙B1)·A0·B̄0"),
        G("GT4", "OR", ["GT1", "GT3"], P.OR, "A>B"),
        G("LT1", "AND", ["N1", "B1"], P.AND, "Ā1·B1"),
        G("LT2", "AND", ["N2", "B0"], P.AND, "Ā0·B0"),
        G("LT3", "AND", ["X1", "LT2"], P.AND, "(A1⊙B1)·Ā0·B0"),
        G("LT4", "OR", ["LT1", "LT3"], P.OR, "A<B"),
        LAMP("GT", "A > B", "GT4"),
        LAMP("EQ", "A = B", "EQ1"),
        LAMP("LT", "A < B", "LT4"),
    ],
    controls: ["A1", "A0", "B1", "B0"],
    readouts: ["GT", "EQ", "LT"],
    tableMode: "combo",
    colLabels: { A1: "A1", A0: "A0", B1: "B1", B0: "B0", GT: "A>B", EQ: "A=B", LT: "A<B" },
};
/* ---------------- 3. sequential ---------------- */
function ffBuild(id, ff, title, part, ctlIn) {
    const ctl = {};
    ctlIn.forEach((k) => (ctl[k] = k));
    const nodes = [
        ...ctlIn.map((k) => SW(k, `INPUT ${k}`)),
        CLOCK(),
        FF("U1", ff, "CLK", ctl, part, `${ff} FF`),
        G("INV", "NOT", ["U1"], P.NOT, "Q̄ buffer"),
        LAMP("Q", "Q", "U1"),
        LAMP("QN", "Q̄", "INV"),
    ];
    return {
        id,
        title,
        nodes,
        controls: [...ctlIn, "CLK"],
        readouts: ["Q", "QN"],
        clocked: true,
        clockId: "CLK",
        tableMode: "characteristic",
        stateId: "U1",
        colLabels: { Q: "Q(t+1)", QN: "Q̄(t+1)" },
    };
}
const srFF = ffBuild("sr-flipflop", "SR", "SR Flip-Flop", P.NOR, ["S", "R"]);
const jkFF = ffBuild("jk-flipflop", "JK", "JK Flip-Flop", P.JKFF, ["J", "K"]);
const dFF = ffBuild("d-flipflop", "D", "D Flip-Flop", P.DFF, ["D"]);
const tFF = ffBuild("t-flipflop", "T", "T Flip-Flop", P.DFF, ["T"]);
const register4 = {
    id: "registers",
    title: "4-bit Parallel Register",
    nodes: [
        BANK("DIN", "PARALLEL DATA IN", 4),
        SW("LD", "LOAD ENABLE"),
        SW("CLR", "MASTER CLEAR"),
        CLOCK(),
        G("CG", "AND", ["LD", "CLK"], P.AND, "CLK·LD"),
        FF("U1", "D", "CG", { D0: "DIN:0", D1: "DIN:1", D2: "DIN:2", D3: "DIN:3", CLR: "CLR" }, P.QUADD, "4-bit REG", 4),
        BAR("Q", "REGISTER OUTPUT", "U1", 4, "seven"),
    ],
    controls: ["DIN", "LD", "CLR", "CLK"],
    readouts: ["Q"],
    clocked: true,
    clockId: "CLK",
    tableMode: "sequence",
    seqSteps: 8,
    colLabels: { Q: "Q3 Q2 Q1 Q0" },
    script: [
        { at: 1, set: { LD: 1, DIN: [1, 0, 1, 0] } },
        { at: 3, set: { DIN: [0, 1, 1, 1] } },
        { at: 5, set: { LD: 0, DIN: [1, 1, 1, 1] } },
        { at: 7, set: { LD: 1, DIN: [0, 0, 1, 1] } },
    ],
    note: "LD gates the clock, so data is latched only while LOAD ENABLE is high.",
};
const counter4 = {
    id: "counters",
    title: "4-bit Synchronous Counter",
    nodes: [
        SW("CLR", "RESET"),
        SW("EN", "COUNT ENABLE"),
        CLOCK(),
        // Ti = EN · Q0 · Q1 · … · Q(i-1)  → synchronous mod-16 up counter
        G("G1", "AND", ["EN", "U1:0"], P.AND, "T1 = EN·Q0"),
        G("G2", "AND", ["EN", "U1:0", "U1:1"], P.AND3, "T2 = EN·Q0·Q1"),
        G("G3", "AND", ["G2", "U1:2"], P.AND, "T3 = EN·Q0·Q1·Q2"),
        FF("U1", "T", "CLK", { T0: "EN", T1: "G1", T2: "G2", T3: "G3", CLR: "CLR" }, P.COUNTER, "MOD-16 CNT", 4),
        BAR("Q", "COUNT", "U1", 4, "seven"),
    ],
    controls: ["CLR", "EN", "CLK"],
    readouts: ["Q"],
    clocked: true,
    clockId: "CLK",
    tableMode: "sequence",
    seqSteps: 16,
    colLabels: { Q: "Q3 Q2 Q1 Q0" },
    script: [{ at: 0, set: { EN: 1 } }],
    note: "Toggle inputs Ti = EN·Q0·Q1···Qi-1 make this a synchronous mod-16 up counter.",
};
/* ---------------- 4. memory ---------------- */
function memBuild(id, title, part, kind, words, width, opts = {}) {
    const aBits = Math.round(Math.log2(words));
    const nodes = [BANK("ADDR", "ADDRESS", aBits)];
    const controls = ["ADDR"];
    const addrRefs = Array.from({ length: aBits }, (_, i) => `ADDR:${i}`);
    if (kind !== "ROM") {
        nodes.push(BANK("DIN", "DATA IN", width));
        nodes.push(SW("WE", "WRITE ENABLE"));
        nodes.push(CLOCK());
        controls.push("DIN", "WE", "CLK");
    }
    if (opts.cs) {
        nodes.push(SW("CS", "CHIP SELECT"));
        controls.push("CS");
    }
    if (opts.refresh) {
        nodes.push(SW("REF", "REFRESH"));
        controls.push("REF");
    }
    nodes.push({
        id: "U1",
        kind: "MEM",
        label: title,
        part,
        clk: kind === "ROM" ? undefined : "CLK",
        mem: {
            kind,
            words,
            width,
            addr: addrRefs,
            din: kind === "ROM" ? undefined : Array.from({ length: width }, (_, i) => `DIN:${i}`),
            we: kind === "ROM" ? undefined : "WE",
            cs: opts.cs ? "CS" : undefined,
            ref: opts.refresh ? "REF" : undefined,
            data: opts.data,
            decayMs: opts.decayMs,
        },
    });
    nodes.push(BAR("DOUT", "DATA OUT", "U1", width, "led"));
    return {
        id,
        title,
        nodes,
        controls,
        readouts: ["DOUT"],
        clocked: kind !== "ROM",
        clockId: kind === "ROM" ? undefined : "CLK",
        tableMode: "memory",
        colLabels: { DOUT: "DATA OUT" },
        note: kind === "ROM"
            ? "Non-volatile: contents are programmed at manufacture and can only be read."
            : "Write happens on the rising clock edge while WRITE ENABLE is high.",
    };
}
const rom = memBuild("rom", "ROM 16×4", P.ROM, "ROM", 16, 4, {
    data: Array.from({ length: 16 }, (_, i) => gray(i)),
});
const ram = memBuild("ram", "RAM 16×4", P.RAM, "RAM", 16, 4, {});
const sram = memBuild("sram", "SRAM 8×4", P.SRAM, "SRAM", 8, 4, { cs: true });
const dram = memBuild("dram", "DRAM 8×4", P.DRAM, "DRAM", 8, 4, {
    cs: true,
    refresh: true,
    decayMs: 6000,
});
/* ---------------- 5. special ---------------- */
const shiftReg = {
    id: "shift-registers",
    title: "4-bit Shift Register (SIPO)",
    nodes: [
        SW("SIN", "SERIAL INPUT"),
        SW("CLR", "MASTER CLEAR"),
        CLOCK(),
        FF("U1", "D", "CLK", { D0: "SIN", D1: "U1:0", D2: "U1:1", D3: "U1:2", CLR: "CLR" }, P.SHIFT, "SIPO 4-bit", 4),
        BAR("Q", "PARALLEL OUTPUT", "U1", 4, "led"),
        LAMP("SOUT", "SERIAL OUT", "U1:3"),
    ],
    controls: ["SIN", "CLR", "CLK"],
    readouts: ["Q", "SOUT"],
    clocked: true,
    clockId: "CLK",
    tableMode: "sequence",
    seqSteps: 8,
    colLabels: { Q: "Q3 Q2 Q1 Q0", SOUT: "SOUT" },
    script: [
        { at: 0, set: { SIN: 1 } },
        { at: 2, set: { SIN: 0 } },
        { at: 3, set: { SIN: 1 } },
        { at: 5, set: { SIN: 0 } },
        { at: 6, set: { SIN: 1 } },
    ],
    note: "Each rising edge moves every bit one stage to the left (Q0 → Q1 → Q2 → Q3).",
};
const ringCounter = {
    id: "ring-counter",
    title: "Ring Counter",
    nodes: [
        SW("LOAD", "PRESET 1000"),
        SW("CLR", "MASTER CLEAR"),
        CLOCK(),
        FF("U1", "D", "CLK", {
            D0: "U1:3",
            D1: "U1:0",
            D2: "U1:1",
            D3: "U1:2",
            PRE0: "LOAD",
            CLR1: "LOAD",
            CLR2: "LOAD",
            CLR3: "LOAD",
            CLR: "CLR",
        }, P.QUADD, "RING 4-bit", 4, [1, 0, 0, 0]),
        BAR("Q", "STATE", "U1", 4, "led"),
    ],
    controls: ["LOAD", "CLR", "CLK"],
    readouts: ["Q"],
    clocked: true,
    clockId: "CLK",
    tableMode: "sequence",
    seqSteps: 8,
    colLabels: { Q: "Q3 Q2 Q1 Q0" },
    script: [{ at: 0, set: { CLR: 0 } }],
    note: "A single ‘1’ recirculates through the loop — modulus equals the number of stages.",
};
const johnsonCounter = {
    id: "johnson-counter",
    title: "Johnson Counter",
    nodes: [
        SW("CLR", "MASTER CLEAR"),
        CLOCK(),
        G("INV", "NOT", ["U1:3"], P.NOT, "Q̄3"),
        FF("U1", "D", "CLK", { D0: "INV", D1: "U1:0", D2: "U1:1", D3: "U1:2", CLR: "CLR" }, P.SHIFT, "TWISTED RING", 4),
        BAR("Q", "STATE", "U1", 4, "led"),
    ],
    controls: ["CLR", "CLK"],
    readouts: ["Q"],
    clocked: true,
    clockId: "CLK",
    tableMode: "sequence",
    seqSteps: 8,
    colLabels: { Q: "Q3 Q2 Q1 Q0" },
    script: [{ at: 0, set: { CLR: 0 } }],
    note: "Q̄ of the last stage is fed back to the first — 2n states for n stages.",
};
const parityGen = {
    id: "parity-generator",
    title: "Parity Generator (even)",
    nodes: [
        BANK("D", "DATA WORD", 4),
        G("X1", "XOR", ["D:0", "D:1"], P.XOR, "D0⊕D1"),
        G("X2", "XOR", ["D:2", "D:3"], P.XOR, "D2⊕D3"),
        G("X3", "XOR", ["X1", "X2"], P.XOR, "TREE"),
        LAMP("P", "PARITY BIT P", "X3"),
        BAR("ECHO", "DATA WORD", "D", 4, "led"),
    ],
    controls: ["D"],
    readouts: ["P", "ECHO"],
    tableMode: "combo",
    colLabels: { D: "D", ECHO: "DATA", P: "P" },
};
const parityCheck = {
    id: "parity-checker",
    title: "Parity Checker (even)",
    nodes: [
        BANK("W", "RECEIVED WORD", 5),
        G("X1", "XOR", ["W:0", "W:1"], P.XOR, "W0⊕W1"),
        G("X2", "XOR", ["W:2", "W:3"], P.XOR, "W2⊕W3"),
        G("X3", "XOR", ["X1", "X2"], P.XOR, "TREE"),
        G("X4", "XOR", ["X3", "W:4"], P.XOR, "⊕P"),
        G("N1", "NOT", ["X4"], P.NOT, "VALID"),
        LAMP("ERR", "ERROR", "X4"),
        LAMP("OK", "WORD VALID", "N1"),
    ],
    controls: ["W"],
    readouts: ["ERR", "OK"],
    tableMode: "combo",
    colLabels: { ERR: "ERROR", OK: "VALID" },
    note: "Bit 4 of the received word is the transmitted parity bit.",
};
/* ---------------- registry ---------------- */
exports.BUILDS = Object.fromEntries([
    gateBuild("and-gate", "AND", "AND Gate"),
    gateBuild("or-gate", "OR", "OR Gate"),
    gateBuild("not-gate", "NOT", "NOT Gate"),
    gateBuild("nand-gate", "NAND", "NAND Gate"),
    gateBuild("nor-gate", "NOR", "NOR Gate"),
    gateBuild("xor-gate", "XOR", "XOR Gate"),
    gateBuild("xnor-gate", "XNOR", "XNOR Gate"),
    halfAdder,
    fullAdder,
    halfSub,
    fullSub,
    mux4,
    demux4,
    encoder42,
    decoder24,
    comparator,
    srFF,
    jkFF,
    dFF,
    tFF,
    register4,
    counter4,
    ram,
    rom,
    sram,
    dram,
    shiftReg,
    ringCounter,
    johnsonCounter,
    parityGen,
    parityCheck,
].map((b) => [b.id, b]));
const getBuild = (id) => exports.BUILDS[id];
exports.getBuild = getBuild;
const hasBuild = (id) => Boolean(exports.BUILDS[id]);
exports.hasBuild = hasBuild;
exports.buildIds = Object.keys(exports.BUILDS);
