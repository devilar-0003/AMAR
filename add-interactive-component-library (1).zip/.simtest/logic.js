"use strict";
/**
 * DigiLab Pro — logic.ts
 * ------------------------------------------------------------------
 * Headless digital logic kernel. It is shared by:
 *   • the Three.js bench renderer (sim/models.ts)
 *   • the truth-table generator (data/library helpers)
 *   • the 2D logic-diagram preview
 * Because every view reads the *same* evaluator, simulated results and
 * documented truth tables can never disagree.
 * ------------------------------------------------------------------
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.toBinaryString = exports.toDecimal = exports.LogicSim = exports.GATE_SYMBOL = exports.parseRef = exports.CONST = void 0;
exports.applyGate = applyGate;
exports.widthOf = widthOf;
exports.deriveTable = deriveTable;
/* ------------------------------------------------------------------ */
/* primitives                                                          */
/* ------------------------------------------------------------------ */
const CONST = (r) => r === "VCC" ? 1 : r === "GND" ? 0 : null;
exports.CONST = CONST;
const parseRef = (r) => {
    const i = r.indexOf(":");
    if (i < 0)
        return { id: r, bit: -1 };
    return { id: r.slice(0, i), bit: Number(r.slice(i + 1)) };
};
exports.parseRef = parseRef;
function applyGate(kind, bits) {
    const a = bits[0] ?? 0;
    // every n-input function reduces over all bits, not just the first two
    const all = bits.length > 0 && bits.every((b) => b === 1) ? 1 : 0;
    const any = bits.some((b) => b === 1) ? 1 : 0;
    switch (kind) {
        case "AND":
            return all;
        case "OR":
            return any;
        case "NOT":
            return (a ^ 1);
        case "BUF":
            return a;
        case "NAND":
            return (all ^ 1);
        case "NOR":
            return (any ^ 1);
        case "XOR": {
            let x = 0;
            for (const b of bits)
                x ^= b;
            return x;
        }
        case "XNOR": {
            let x = 0;
            for (const b of bits)
                x ^= b;
            return (x ^ 1);
        }
    }
}
exports.GATE_SYMBOL = {
    AND: "∧",
    OR: "∨",
    NOT: "¬",
    NAND: "⊼",
    NOR: "⊽",
    XOR: "⊕",
    XNOR: "⊙",
    BUF: "▷",
};
function widthOf(n) {
    switch (n.kind) {
        case "INBUS":
        case "OUTBUS":
            return n.bits ?? 1;
        case "FF":
            return n.bits ?? 1;
        case "MEM":
            return n.mem?.width ?? 1;
        default:
            return 1;
    }
}
const zeros = (w) => new Array(w).fill(0);
/* ------------------------------------------------------------------ */
/* simulator                                                           */
/* ------------------------------------------------------------------ */
class LogicSim {
    constructor(build) {
        this.byId = new Map();
        /** live wire values */
        this.values = new Map();
        /** stored state for FF / MEM nodes */
        this.state = new Map();
        /** last observed clock level per stateful node */
        this.prevClk = new Map();
        /** memory cells */
        this.cells = new Map();
        this.cellStamp = new Map();
        this.now = 0;
        /** set when a DRAM cell has leaked (used by the UI warning lamp) */
        this.leak = false;
        this.error = null;
        this.build = build;
        for (const n of build.nodes)
            this.byId.set(n.id, n);
        this.reset();
    }
    node(id) {
        return this.byId.get(id);
    }
    reset() {
        this.values.clear();
        this.state.clear();
        this.prevClk.clear();
        this.cells.clear();
        this.cellStamp.clear();
        this.leak = false;
        this.error = null;
        this.now = 0;
        for (const n of this.build.nodes) {
            const w = widthOf(n);
            if (n.kind === "FF") {
                const s = n.init ? [...n.init] : zeros(w);
                this.state.set(n.id, s.slice(0, w).concat(zeros(w)).slice(0, w));
            }
            if (n.kind === "MEM" && n.mem) {
                const grid = [];
                for (let i = 0; i < n.mem.words; i++) {
                    const src = n.mem.data?.[i];
                    grid.push(src ? src.slice(0, n.mem.width) : zeros(n.mem.width));
                }
                this.cells.set(n.id, grid);
                this.cellStamp.set(n.id, 0);
            }
            if (n.kind === "IN" || n.kind === "CLK" || n.kind === "INBUS") {
                this.values.set(n.id, zeros(w));
            }
        }
        this.evaluate();
        // seed the edge detectors so the first transition is always seen
        for (const n of this.build.nodes) {
            if ((n.kind === "FF" || n.kind === "MEM") && n.clk)
                this.prevClk.set(n.id, this.bit(n.clk));
            if (n.mem?.ref)
                this.prevClk.set(`REF:${n.id}`, this.bit(n.mem.ref));
        }
    }
    /* ---------- input handling ---------- */
    setInput(id, bit, index = 0) {
        const n = this.byId.get(id);
        if (!n)
            return;
        const v = this.values.get(id) ?? zeros(widthOf(n));
        if (n.kind === "CLK") {
            v[0] = bit;
            this.values.set(id, v);
            this.syncClocks();
        }
        else {
            v[index] = bit;
            this.values.set(id, v);
        }
        this.evaluate();
    }
    toggle(id, index = 0) {
        const n = this.byId.get(id);
        if (!n)
            return;
        const cur = (this.values.get(id)?.[index] ?? 0);
        this.setInput(id, (cur ^ 1), index);
    }
    setInputs(map) {
        for (const [k, v] of Object.entries(map)) {
            const arr = Array.isArray(v) ? v : [v];
            arr.forEach((b, i) => {
                const n = this.byId.get(k);
                if (!n)
                    return;
                const vec = this.values.get(k) ?? zeros(widthOf(n));
                vec[i] = b;
                this.values.set(k, vec);
            });
        }
        this.syncClocks();
        this.evaluate();
    }
    get value() {
        return Object.fromEntries(this.values);
    }
    bit(ref) {
        const c = (0, exports.CONST)(ref);
        if (c !== null)
            return c;
        const { id, bit } = (0, exports.parseRef)(ref);
        const v = this.values.get(id);
        if (!v)
            return 0;
        return (bit < 0 ? v[0] : v[bit]) ?? 0;
    }
    vec(id) {
        return this.values.get(id) ?? zeros(1);
    }
    /** read a numeric bus value (LSB first) */
    num(id) {
        const v = this.vec(id);
        let out = 0;
        for (let i = 0; i < v.length; i++)
            if (v[i])
                out |= 1 << i;
        return out;
    }
    /* ---------- evaluation ---------- */
    /** Fixed-point evaluation of the combinational network. */
    evaluate(passes = 14) {
        for (let p = 0; p < passes; p++) {
            let dirty = false;
            for (const n of this.build.nodes) {
                const next = this.evalNode(n);
                if (!next)
                    continue;
                const prev = this.values.get(n.id);
                if (!prev || prev.length !== next.length || prev.some((b, i) => b !== next[i])) {
                    this.values.set(n.id, next);
                    dirty = true;
                }
            }
            if (!dirty)
                break;
        }
    }
    evalNode(n) {
        const w = widthOf(n);
        switch (n.kind) {
            case "IN":
            case "CLK":
            case "INBUS":
                return this.values.get(n.id) ?? zeros(w);
            case "OUT":
            case "OUTBUS": {
                const src = n.in?.[0];
                if (!src)
                    return zeros(w);
                const { id, bit } = (0, exports.parseRef)(src);
                const sv = this.values.get(id) ?? zeros(1);
                if (bit >= 0)
                    return [sv[bit] ?? 0];
                const out = zeros(w);
                for (let i = 0; i < w; i++)
                    out[i] = sv[i] ?? 0;
                return out;
            }
            case "GATE": {
                const bits = (n.in ?? []).map((r) => this.bit(r));
                return [applyGate(n.gate ?? "BUF", bits)];
            }
            case "FF": {
                const st = this.state.get(n.id) ?? zeros(w);
                if (n.edge === "latch" && n.ff === "SR") {
                    // level-sensitive NOR latch: converges through the fixed point
                    const s = this.bit(n.ctl?.S ?? "GND");
                    const r = this.bit(n.ctl?.R ?? "GND");
                    const q = zeros(w);
                    for (let i = 0; i < w; i++) {
                        const si = w > 1 ? (n.ctl?.[`S${i}`] ? this.bit(n.ctl[`S${i}`]) : s) : s;
                        const ri = w > 1 ? (n.ctl?.[`R${i}`] ? this.bit(n.ctl[`R${i}`]) : r) : r;
                        q[i] = si ? 1 : ri ? 0 : st[i];
                    }
                    this.state.set(n.id, q);
                    return q;
                }
                return st;
            }
            case "MEM": {
                const m = n.mem;
                const grid = this.cells.get(n.id) ?? [];
                let addr = 0;
                m.addr.forEach((r, i) => {
                    if (this.bit(r))
                        addr |= 1 << i;
                });
                addr = Math.min(addr, m.words - 1);
                // DRAM leakage
                if (m.kind === "DRAM" && m.decayMs) {
                    const stamp = this.cellStamp.get(n.id) ?? 0;
                    if (this.now - stamp > m.decayMs) {
                        const fresh = grid.some((word) => word.some((b) => b === 1));
                        if (fresh) {
                            this.leak = true;
                            for (let i = 0; i < grid.length; i++)
                                grid[i] = zeros(m.width);
                        }
                    }
                }
                const cs = m.cs ? this.bit(m.cs) : 1;
                if (!cs)
                    return zeros(m.width);
                const word = grid[addr] ?? zeros(m.width);
                return word.slice(0, m.width);
            }
        }
    }
    /* ---------- sequential machinery ---------- */
    stateful() {
        return this.build.nodes.filter((n) => (n.kind === "FF" || n.kind === "MEM") && n.clk);
    }
    /** Cascade clock edges (handles ripple counters naturally). */
    syncClocks() {
        for (let pass = 0; pass < 12; pass++) {
            // settle the combinational network first, otherwise gated clocks such as
            // CLK·LOAD would never present their edge to the flip-flops
            this.evaluate();
            let changed = false;
            // DRAM refresh lines are edge-sampled independently of the write clock
            for (const n of this.build.nodes) {
                const r = n.mem?.ref;
                if (!r)
                    continue;
                const key = `REF:${n.id}`;
                const cur = this.bit(r);
                const prev = this.prevClk.get(key);
                if (prev === undefined) {
                    this.prevClk.set(key, cur);
                    continue;
                }
                if (cur !== prev) {
                    this.prevClk.set(key, cur);
                    changed = true;
                    if (prev === 0 && cur === 1) {
                        this.cellStamp.set(n.id, this.now);
                        this.leak = false;
                    }
                }
            }
            const pending = [];
            for (const n of this.stateful()) {
                if (!n.clk)
                    continue;
                const cur = this.bit(n.clk);
                const prev = this.prevClk.get(n.id);
                if (prev === undefined) {
                    this.prevClk.set(n.id, cur);
                    continue;
                }
                if (cur === prev)
                    continue;
                this.prevClk.set(n.id, cur);
                changed = true;
                const edge = n.edge ?? "rising";
                const active = edge === "rising" ? prev === 0 && cur === 1 : edge === "falling" ? prev === 1 && cur === 0 : true;
                if (!active)
                    continue;
                if (n.kind === "FF")
                    pending.push({ n, next: this.nextFF(n) });
                if (n.kind === "MEM")
                    this.memWrite(n);
            }
            // commit all next-states simultaneously => true synchronous behaviour
            for (const p of pending)
                this.state.set(p.n.id, p.next);
            if (!changed)
                break;
        }
        this.evaluate();
    }
    nextFF(n) {
        const w = widthOf(n);
        const st = this.state.get(n.id) ?? zeros(w);
        const out = zeros(w);
        const ctl = n.ctl ?? {};
        for (let i = 0; i < w; i++) {
            const pick = (key) => {
                const single = ctl[key];
                const banked = ctl[`${key}${i}`];
                if (banked)
                    return this.bit(banked);
                if (single)
                    return this.bit(single);
                return 0;
            };
            const q = st[i];
            switch (n.ff) {
                case "D":
                    out[i] = pick("D");
                    break;
                case "T":
                    out[i] = pick("T") ? (q ^ 1) : q;
                    break;
                case "JK": {
                    const j = pick("J");
                    const k = pick("K");
                    out[i] = j && k ? (q ^ 1) : j ? 1 : k ? 0 : q;
                    break;
                }
                case "SR": {
                    // characteristic equation Q(t+1) = S + R̄·Q  (S = R = 1 is the
                    // forbidden combination — S is given dominance so the model stays
                    // deterministic and the documentation flags the condition)
                    const s = pick("S");
                    const r = pick("R");
                    out[i] = s ? 1 : r ? 0 : q;
                    break;
                }
            }
            // asynchronous clear / preset win over the clocked behaviour
            if ((ctl.CLR && this.bit(ctl.CLR)) || (ctl[`CLR${i}`] && this.bit(ctl[`CLR${i}`])))
                out[i] = 0;
            if ((ctl.PRE && this.bit(ctl.PRE)) || (ctl[`PRE${i}`] && this.bit(ctl[`PRE${i}`])))
                out[i] = 1;
        }
        return out;
    }
    memWrite(n) {
        const m = n.mem;
        if (!m || !m.din || !m.we)
            return;
        if (!this.bit(m.we))
            return;
        if (m.cs && !this.bit(m.cs))
            return;
        const grid = this.cells.get(n.id);
        if (!grid)
            return;
        let addr = 0;
        m.addr.forEach((r, i) => {
            if (this.bit(r))
                addr |= 1 << i;
        });
        if (addr >= m.words)
            return;
        const word = zeros(m.width);
        m.din.forEach((r, i) => {
            if (i < m.width)
                word[i] = this.bit(r);
        });
        grid[addr] = word;
        this.cellStamp.set(n.id, this.now);
        this.leak = false;
    }
    /** Manual single clock pulse (low -> high -> low). */
    pulse() {
        const id = this.build.clockId ?? this.build.controls.find((c) => this.node(c)?.kind === "CLK");
        if (!id)
            return;
        this.setInput(id, 0);
        this.setInput(id, 1);
        this.setInput(id, 0);
    }
    setClock(high) {
        const id = this.build.clockId;
        if (!id)
            return;
        this.setInput(id, high ? 1 : 0);
    }
    clockLevel() {
        const id = this.build.clockId;
        if (!id)
            return 0;
        return this.vec(id)[0] ?? 0;
    }
    /** force a state (used by characteristic tables) */
    forceState(id, v) {
        const n = this.byId.get(id);
        if (!n)
            return;
        this.state.set(id, v.slice(0, widthOf(n)));
        this.evaluate();
    }
    readState(id) {
        const n = this.byId.get(id);
        if (!n)
            return [];
        if (n.kind === "FF")
            return [...(this.state.get(id) ?? zeros(widthOf(n)))];
        return [...this.vec(id)];
    }
    memoryGrid(id) {
        return (this.cells.get(id) ?? []).map((r) => [...r]);
    }
    /** advance wall clock (auto-run + DRAM decay) */
    tick(dtMs) {
        this.now += dtMs;
        const anyDram = this.build.nodes.some((n) => n.mem?.kind === "DRAM");
        if (anyDram)
            this.evaluate(2);
    }
    clone() {
        return new LogicSim(this.build);
    }
}
exports.LogicSim = LogicSim;
function deriveTable(build, maxRows = 128) {
    const nodeById = new Map(build.nodes.map((n) => [n.id, n]));
    // column labels default to the net identifier (A, B, CIN, SUM …) which is
    // what a textbook truth table shows; colLabels can prettify them.
    const lbl = (id) => build.colLabels?.[id] ?? id;
    const sim = new LogicSim(build);
    if (build.tableMode === "memory") {
        const memNode = build.nodes.find((n) => n.kind === "MEM");
        const rows = [];
        const inCols = build.controls.filter((c) => nodeById.get(c)?.kind !== "CLK").map(lbl);
        if (memNode?.mem) {
            for (let a = 0; a < memNode.mem.words; a++) {
                const addrBits = memNode.mem.addr.map((_, i) => ((a >> i) & 1));
                const inputs = {};
                const nonClk = build.controls.filter((c) => nodeById.get(c)?.kind !== "CLK");
                let k = 0;
                for (const c of nonClk) {
                    const n = nodeById.get(c);
                    if (n.kind === "INBUS" && /addr/i.test(n.id + n.label)) {
                        inputs[lbl(c)] = addrBits;
                    }
                    else if (n.kind === "INBUS") {
                        inputs[lbl(c)] = zeros(widthOf(n));
                    }
                    else {
                        inputs[lbl(c)] = [addrBits[k] ?? 0];
                        k++;
                    }
                }
                const data = memNode.mem.data?.[a] ?? zeros(memNode.mem.width);
                const outputs = {};
                for (const o of build.readouts)
                    outputs[lbl(o)] = data.slice(0, widthOf(nodeById.get(o)));
                rows.push({ inputs, outputs, label: `0x${a.toString(16).toUpperCase()}` });
            }
        }
        return { mode: "memory", inCols, outCols: build.readouts.map(lbl), rows, note: build.note };
    }
    const nonClock = build.controls.filter((c) => nodeById.get(c)?.kind !== "CLK");
    if (build.tableMode === "characteristic" && build.stateId) {
        const stNode = nodeById.get(build.stateId);
        const inCols = nonClock.map(lbl);
        const outCols = build.readouts.map(lbl);
        const rows = [];
        for (let s = 0; s < 2; s++) {
            for (let combo = 0; combo < 1 << nonClock.length && rows.length < maxRows; combo++) {
                sim.reset();
                const inputs = {};
                nonClock.forEach((c, i) => {
                    const n = nodeById.get(c);
                    const w = widthOf(n);
                    const v = zeros(w);
                    for (let b = 0; b < w; b++)
                        v[b] = ((combo >> (b + i * w)) & 1);
                    inputs[lbl(c)] = v;
                    sim.setInput(c, 0, 0);
                    v.forEach((bit, bi) => sim.setInput(c, bit, bi));
                });
                sim.forceState(build.stateId, [s]);
                sim.setClock(false);
                sim.setClock(true);
                sim.setClock(false);
                const outputs = {};
                for (const o of build.readouts)
                    outputs[lbl(o)] = sim.vec(o).slice(0, widthOf(nodeById.get(o)));
                rows.push({
                    inputs,
                    outputs,
                    state: [s],
                    nextState: sim.readState(build.stateId).slice(0, 1),
                    label: stNode.ff ? `${stNode.ff} @ Q=${s}` : undefined,
                });
            }
        }
        return {
            mode: "characteristic",
            inCols,
            outCols,
            stateCol: `Q(t)`,
            rows,
            note: build.note ?? "Clock pulses ↑ are applied automatically for every row.",
        };
    }
    if (build.tableMode === "sequence") {
        const steps = build.seqSteps ?? 8;
        const inCols = nonClock.map(lbl);
        const outCols = build.readouts.map(lbl);
        const rows = [];
        sim.reset();
        for (let s = 0; s <= steps; s++) {
            for (const ev of build.script ?? [])
                if (ev.at === s)
                    sim.setInputs(ev.set);
            const inputs = {};
            for (const c of nonClock)
                inputs[lbl(c)] = sim.vec(c).slice();
            const outputs = {};
            for (const o of build.readouts)
                outputs[lbl(o)] = sim.vec(o).slice(0, widthOf(nodeById.get(o)));
            rows.push({ inputs, outputs, label: s === 0 ? "RESET" : `CLK ↑ ${s}` });
            sim.pulse();
        }
        return {
            mode: "sequence",
            inCols,
            outCols,
            rows,
            note: build.note ?? "Outputs sampled immediately after each rising clock edge.",
        };
    }
    /* ---- combinational ---- */
    const totalBits = nonClock.reduce((a, c) => a + widthOf(nodeById.get(c)), 0);
    const combos = Math.min(1 << totalBits, maxRows);
    const inCols = nonClock.map(lbl);
    const outCols = build.readouts.map(lbl);
    const rows = [];
    for (let combo = 0; combo < combos; combo++) {
        let shift = 0;
        const inputs = {};
        for (const c of nonClock) {
            const n = nodeById.get(c);
            const w = widthOf(n);
            const v = zeros(w);
            for (let b = 0; b < w; b++)
                v[b] = ((combo >> (shift + b)) & 1);
            shift += w;
            inputs[lbl(c)] = v;
        }
        sim.reset();
        nonClock.forEach((c) => {
            const v = inputs[lbl(c)];
            v.forEach((bit, bi) => sim.setInput(c, bit, bi));
        });
        const outputs = {};
        for (const o of build.readouts)
            outputs[lbl(o)] = sim.vec(o).slice(0, widthOf(nodeById.get(o)));
        rows.push({ inputs, outputs });
    }
    return { mode: "combo", inCols, outCols, rows, note: build.note, };
}
const toDecimal = (v) => {
    let acc = 0;
    for (let i = 0; i < v.length; i++)
        if (v[i])
            acc |= 1 << i;
    return acc;
};
exports.toDecimal = toDecimal;
const toBinaryString = (v) => [...v].reverse().map((b) => b.toString()).join("");
exports.toBinaryString = toBinaryString;
