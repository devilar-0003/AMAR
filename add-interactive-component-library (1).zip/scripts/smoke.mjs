/**
 * DigiLab Pro — SSR smoke runner.
 *   node scripts/smoke.mjs
 * Bundles the smoke entry with esbuild (the same resolver Vite uses) and
 * executes it under Node, so the whole catalogue is rendered headlessly.
 */
import { build } from "esbuild";
import { mkdirSync, rmSync } from "node:fs";
import path from "node:path";

const out = path.resolve(".smoke/out.cjs");
rmSync(path.dirname(out), { recursive: true, force: true });
mkdirSync(path.dirname(out), { recursive: true });

await build({
  entryPoints: ["scripts/smoke-entry.tsx"],
  outfile: out,
  bundle: true,
  format: "cjs",
  platform: "node",
  target: "node20",
  jsx: "automatic",
  alias: { "@": path.resolve("src") },
  loader: { ".css": "empty" },
  logLevel: "warning",
});

await import(out);
