/**
 * DigiLab Pro — headless simulation verification harness.
 *
 *   npx tsc src/sim/logic.ts src/sim/builds.ts --outDir .simtest \
 *       --module commonjs --target es2020 --moduleResolution node --skipLibCheck
 *   echo '{"type":"commonjs"}' > .simtest/package.json
 *   node scripts/verify-sim.cjs ./.simtest
 *
 * Every catalogue build is checked against its textbook behaviour so the 3D
 * bench, the logic diagram, the truth table and the documentation can never
 * disagree with each other.
 */
const path = require("path");
const DIR = path.resolve(process.cwd(), process.argv[2] || "./.simtest");
const { BUILDS } = require(path.join(DIR, "builds.js"));
const { deriveTable, LogicSim } = require(path.join(DIR, "logic.js"));

let failures = 0;
let passes = 0;
const check = (name, cond, extra = "") => {
  if (!cond) {
    failures++;
    console.log(`  FAIL  ${name} ${extra}`);
  } else {
    passes++;
    console.log(`  ok    ${name}`);
  }
};

const bin = (v) => [...v].reverse().join("");
const num = (v) => v.reduce((a, b, i) => a | (b << i), 0);
const I = (t, r, i) => r.inputs[t.inCols[i]];
const O = (t, r, i) => r.outputs[t.outCols[i]];

/* ---------------------------------------------------------------- gates */
const gateExpect = {
  "and-gate": (a, b) => [a & b, (a & b) ^ 1],
  "or-gate": (a, b) => [a | b, (a | b) ^ 1],
  "nand-gate": (a, b) => [(a & b) ^ 1, a & b],
  "nor-gate": (a, b) => [(a | b) ^ 1, a | b],
  "xor-gate": (a, b) => [a ^ b, (a ^ b) ^ 1],
  "xnor-gate": (a, b) => [(a ^ b) ^ 1, a ^ b],
};
for (const [id, fn] of Object.entries(gateExpect)) {
  const t = deriveTable(BUILDS[id]);
  const bad = t.rows.filter((r) => {
    const [exp1, exp2] = fn(num(I(t, r, 0)), num(I(t, r, 1)));
    return num(O(t, r, 0)) !== exp1 || num(O(t, r, 1)) !== exp2;
  });
  check(`${id} (${t.rows.length} rows)`, bad.length === 0, `${bad.length} wrong`);
}
{
  const t = deriveTable(BUILDS["not-gate"]);
  check("not-gate (2 rows)", t.rows.every((r) => num(O(t, r, 0)) === (num(I(t, r, 0)) ^ 1)));
}

/* ----------------------------------------------------------- arithmetic */
{
  const t = deriveTable(BUILDS["half-adder"]);
  check("half-adder", t.rows.every((r) => {
    const a = num(I(t, r, 0)), b = num(I(t, r, 1)), s = a + b;
    return num(O(t, r, 0)) === (s & 1) && num(O(t, r, 1)) === (s >> 1);
  }));
  const f = deriveTable(BUILDS["full-adder"]);
  check("full-adder", f.rows.every((r) => {
    const s = num(I(f, r, 0)) + num(I(f, r, 1)) + num(I(f, r, 2));
    return num(O(f, r, 0)) === (s & 1) && num(O(f, r, 1)) === (s >> 1);
  }));
  const h = deriveTable(BUILDS["half-subtractor"]);
  check("half-subtractor", h.rows.every((r) => {
    const d = num(I(h, r, 0)) - num(I(h, r, 1));
    return num(O(h, r, 0)) === (d < 0 ? d + 2 : d) && num(O(h, r, 1)) === (d < 0 ? 1 : 0);
  }));
  const s = deriveTable(BUILDS["full-subtractor"]);
  check("full-subtractor", s.rows.every((r) => {
    const d = num(I(s, r, 0)) - num(I(s, r, 1)) - num(I(s, r, 2));
    return num(O(s, r, 0)) === (d < 0 ? d + 2 : d) && num(O(s, r, 1)) === (d < 0 ? 1 : 0);
  }));
}

/* ------------------------------------------------------ MSI combinational */
{
  const t = deriveTable(BUILDS["multiplexer"]);
  check(`multiplexer 4:1 (${t.rows.length} rows)`, t.rows.length === 64 && t.rows.every((r) => {
    const sel = num(I(t, r, 0)) * 2 + num(I(t, r, 1)); // S1,S0
    return num(O(t, r, 0)) === num(I(t, r, 2 + sel));
  }));
  const d = deriveTable(BUILDS["demultiplexer"]);
  check(`demultiplexer 1:4 (${d.rows.length} rows)`, d.rows.every((r) => {
    const data = num(I(d, r, 0));
    const sel = num(I(d, r, 1)) * 2 + num(I(d, r, 2));
    const outs = d.outCols.map((_, i) => num(O(d, r, i)));
    const ones = outs.filter((o) => o === 1).length;
    return data ? ones === 1 && outs[sel] === 1 : ones === 0;
  }));
  const e = deriveTable(BUILDS["encoder"]);
  const oneHot = e.rows.filter((r) => e.inCols.map((_, i) => num(I(e, r, i))).reduce((a, b) => a + b, 0) === 1);
  check(`encoder 4:2 (one-hot rows ${oneHot.length})`, oneHot.length === 4 && oneHot.every((r) => {
    const dIdx = e.inCols.map((_, i) => num(I(e, r, i))).indexOf(1);
    return num(O(e, r, 0)) === (dIdx >> 1) && num(O(e, r, 1)) === (dIdx & 1) && num(O(e, r, 2)) === 1;
  }));
  const dc = deriveTable(BUILDS["decoder"]);
  check(`decoder 2:4 (${dc.rows.length} rows)`, dc.rows.every((r) => {
    const en = num(I(dc, r, 2));
    const sel = num(I(dc, r, 0)) * 2 + num(I(dc, r, 1));
    const outs = dc.outCols.map((_, i) => num(O(dc, r, i)));
    return en ? outs[sel] === 1 && outs.filter((o) => o).length === 1 : outs.every((o) => o === 0);
  }));
  const c = deriveTable(BUILDS["comparator"]);
  check(`comparator 2-bit (${c.rows.length} rows)`, c.rows.every((r) => {
    const A = num(I(c, r, 0)) * 2 + num(I(c, r, 1));
    const B = num(I(c, r, 2)) * 2 + num(I(c, r, 3));
    return num(O(c, r, 0)) === (A > B ? 1 : 0) && num(O(c, r, 1)) === (A === B ? 1 : 0) && num(O(c, r, 2)) === (A < B ? 1 : 0);
  }));
}

/* --------------------------------------------------------- flip-flops */
{
  const rules = {
    "d-flipflop": (a, _b, _q) => a,
    "t-flipflop": (a, _b, q) => (a ? q ^ 1 : q),
    "jk-flipflop": (j, k, q) => (j && k ? q ^ 1 : j ? 1 : k ? 0 : q),
    "sr-flipflop": (s, r, q) => (s ? 1 : r ? 0 : q),
  };
  for (const [id, rule] of Object.entries(rules)) {
    const t = deriveTable(BUILDS[id]);
    const bad = t.rows.filter((r) => {
      const a = num(I(t, r, 0));
      const b = t.inCols.length > 1 ? num(I(t, r, 1)) : 0;
      return num(O(t, r, 0)) !== rule(a, b, num(r.state));
    });
    check(`${id} characteristic (${t.rows.length} rows)`, bad.length === 0, `${bad.length} wrong`);
    // complementary output must be the inverse
    const comp = t.rows.every((r) => num(O(t, r, 1)) === (num(O(t, r, 0)) ^ 1));
    check(`${id} Q̄ complement`, comp);
  }
}

/* ------------------------------------------------------------- sequences */
{
  const t = deriveTable(BUILDS["counters"]);
  const seq = t.rows.map((r) => bin(O(t, r, 0)));
  check("mod-16 synchronous counter", seq.join(",") === [...Array(17)].map((_, i) => (i % 16).toString(2).padStart(4, "0")).join(","), seq.join(","));

  const rg = deriveTable(BUILDS["ring-counter"]);
  const rseq = rg.rows.map((r) => bin(O(rg, r, 0)));
  check("ring counter (mod-4)", rseq.join(",") === "0001,0010,0100,1000,0001,0010,0100,1000,0001", rseq.join(","));

  const jn = deriveTable(BUILDS["johnson-counter"]);
  const jseq = jn.rows.map((r) => bin(O(jn, r, 0)));
  check("johnson counter (mod-8)", jseq.join(",") === "0000,0001,0011,0111,1111,1110,1100,1000,0000", jseq.join(","));

  const sh = deriveTable(BUILDS["shift-registers"]);
  const sseq = sh.rows.map((r) => `${num(I(sh, r, 0))}→${bin(O(sh, r, 0))}`);
  console.log("        shift register:", sseq.join("  "));
  // serial bit must appear at Q0 one clock later
  // the serial bit entered at step k must be visible at Q0 one clock later
  check(
    "shift register SIPO",
    sh.rows.every((r, i) => i === 0 || bin(O(sh, r, 0))[3] === String(num(I(sh, sh.rows[i - 1], 0)))),
    sseq.join(" "),
  );

  const rg2 = deriveTable(BUILDS["registers"]);
  const loaded = rg2.rows.map((r) => `${bin(I(rg2, r, 0))}/LD${num(I(rg2, r, 1))}→${bin(O(rg2, r, 0))}`);
  console.log("        register:", loaded.join("  "));
  // whenever LD was high on the previous edge the register holds the data word
  let held = true;
  for (let i = 2; i < rg2.rows.length; i++) {
    const prev = rg2.rows[i - 1];
    if (num(I(rg2, prev, 1)) === 1 && bin(O(rg2, rg2.rows[i], 0)) !== bin(I(rg2, prev, 0))) held = false;
  }
  check("register loads on gated clock", held);
}

/* ---------------------------------------------------------------- memory */
{
  const t = deriveTable(BUILDS["rom"]);
  check(`rom 16×4 grey code (${t.rows.length} words)`, t.rows.every((r, a) => num(O(t, r, 0)) === (a ^ (a >> 1))));

  const ram = new LogicSim(BUILDS["ram"]);
  ram.setInput("ADDR", 1, 0);
  ram.setInput("ADDR", 1, 1); // address 3
  ram.setInput("DIN", 1, 0);
  ram.setInput("DIN", 1, 2); // data 0101
  ram.setInput("WE", 1);
  ram.pulse();
  ram.setInput("WE", 0);
  check("ram write then read", bin(ram.vec("DOUT")) === "0101", bin(ram.vec("DOUT")));
  ram.setInput("ADDR", 0, 0);
  ram.setInput("ADDR", 0, 1); // address 0
  check("ram other address untouched", bin(ram.vec("DOUT")) === "0000");
  ram.setInput("ADDR", 1, 0);
  ram.setInput("ADDR", 1, 1);
  check("ram retains written word", bin(ram.vec("DOUT")) === "0101");

  const sram = new LogicSim(BUILDS["sram"]);
  sram.setInput("WE", 1);
  sram.setInput("DIN", 1, 1);
  sram.pulse();
  check("sram blocked without chip select", sram.memoryGrid("U1").every((w) => w.every((b) => b === 0)));
  sram.setInput("CS", 1);
  sram.pulse();
  sram.setInput("WE", 0);
  check("sram writes with chip select", bin(sram.vec("DOUT")) === "0010", bin(sram.vec("DOUT")));

  const dram = new LogicSim(BUILDS["dram"]);
  dram.setInput("CS", 1);
  dram.setInput("WE", 1);
  dram.setInput("DIN", 1, 0);
  dram.pulse();
  dram.setInput("WE", 0);
  const held = bin(dram.vec("DOUT"));
  dram.tick(9000);
  const leaked = bin(dram.vec("DOUT"));
  check("dram holds data before decay", held === "0001", held);
  check("dram leaks after refresh interval", leaked === "0000" && dram.leak === true, `${leaked} leak=${dram.leak}`);
}

/* --------------------------------------------------------------- parity */
{
  const g = deriveTable(BUILDS["parity-generator"]);
  check(`parity generator (${g.rows.length} rows)`, g.rows.every((r) => {
    const ones = I(g, r, 0).reduce((a, b) => a + b, 0);
    return num(O(g, r, 0)) === ones % 2;
  }));
  const c = deriveTable(BUILDS["parity-checker"]);
  check(`parity checker (${c.rows.length} rows)`, c.rows.every((r) => {
    const ones = I(c, r, 0).reduce((a, b) => a + b, 0);
    return num(O(c, r, 0)) === ones % 2 && num(O(c, r, 1)) === (ones % 2 === 0 ? 1 : 0);
  }));
}

/* --------------------------------------------------- structural integrity */
{
  const ids = Object.keys(BUILDS);
  check("all builds resolve their refs", ids.every((id) => {
    const b = BUILDS[id];
    const known = new Set(b.nodes.map((n) => n.id));
    const refs = [];
    for (const n of b.nodes) {
      for (const r of [...(n.in ?? []), ...Object.values(n.ctl ?? {}), n.clk, ...(n.mem ? [...n.mem.addr, ...(n.mem.din ?? []), n.mem.we, n.mem.cs, n.mem.ref] : [])]) {
        if (r && r !== "VCC" && r !== "GND") refs.push(r.split(":")[0]);
      }
    }
    return refs.every((r) => known.has(r));
  }));
  check("controls and readouts exist in every build", ids.every((id) => {
    const b = BUILDS[id];
    const known = new Set(b.nodes.map((n) => n.id));
    return [...b.controls, ...b.readouts].every((x) => known.has(x));
  }));
  check("every build derives a table", ids.every((id) => {
    try {
      const t = deriveTable(BUILDS[id]);
      return t.rows.length > 0 && t.inCols.length > 0 && t.outCols.length > 0;
    } catch (e) {
      console.log("        table error", id, e.message);
      return false;
    }
  }));
  check("no duplicate build ids", ids.length === new Set(ids).size && ids.every((k) => BUILDS[k].id === k));
}

console.log(`\n${Object.keys(BUILDS).length} builds · ${passes} passed · ${failures} failed`);
process.exit(failures ? 1 : 0);
