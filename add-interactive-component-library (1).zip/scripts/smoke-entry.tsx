/**
 * DigiLab Pro — SSR smoke test entry.
 * Renders the whole catalogue through react-dom/server so every symbol,
 * logic diagram and truth table is exercised without a browser.
 */
import { renderToString } from "react-dom/server";
import App from "@/App";
import { COMPONENTS } from "@/data/library";
import { getBuild } from "@/sim/builds";
import { LogicSim } from "@/sim/logic";
import { CircuitSymbol } from "@/components/CircuitSymbol";
import { LogicDiagram } from "@/components/LogicDiagram";
import { TruthTable } from "@/components/TruthTable";
import { COMPONENT_MAP, CATEGORIES, SIMULATABLE_COUNT, TOTAL_COMPONENTS } from "@/data/library";

let failures = 0;
const ok = (name: string, cond: boolean, extra = "") => {
  if (!cond) {
    failures++;
    console.log(`  FAIL  ${name} ${extra}`);
  } else console.log(`  ok    ${name}`);
};

/* ---------- shell ---------- */
const app = renderToString(<App />);
ok("App renders", app.length > 5000, `${app.length} chars`);
ok("sidebar library launcher present", app.includes("Component") && app.includes("Library"));
ok("subtitle present", app.includes("Browse all digital electronics components"));
ok("total count rendered", app.includes(String(TOTAL_COMPONENTS)));
ok("all categories listed", CATEGORIES.every((c) => app.includes(c.name)));
ok("first component card rendered", app.includes(COMPONENTS[0].name));
ok("no react error boundary text", !app.includes("Renderer offline"));

/* ---------- every component: symbol + diagram + truth table ---------- */
let symbolChars = 0;
let diagramChars = 0;
let tableChars = 0;

for (const doc of COMPONENTS) {
  const build = getBuild(doc.buildId);
  if (!build) {
    ok(`${doc.id} has a build`, false);
    continue;
  }
  const sim = new LogicSim(build);

  // drive every input high so live-state paths are covered too
  for (const c of build.controls) {
    const node = build.nodes.find((n) => n.id === c);
    if (!node) continue;
    if (node.kind === "INBUS") for (let i = 0; i < (node.bits ?? 1); i++) sim.setInput(c, 1, i);
    else sim.setInput(c, 1);
  }
  if (build.clocked) sim.pulse();

  const s = renderToString(<CircuitSymbol doc={doc} build={build} />);
  const d = renderToString(<LogicDiagram build={build} sim={sim} onToggle={() => undefined} />);
  const t = renderToString(
    <TruthTable build={build} sim={sim} version={1} step={2} onApply={() => undefined} />,
  );
  symbolChars += s.length;
  diagramChars += d.length;
  tableChars += t.length;

  const problems: string[] = [];
  if (s.length < 400) problems.push(`symbol too small (${s.length})`);
  if (d.length < 800) problems.push(`diagram too small (${d.length})`);
  if (t.length < 1200) problems.push(`table too small (${t.length})`);
  if (/undefined|NaN|\[object Object\]/.test(t)) problems.push("table contains undefined/NaN");
  if (/undefined|NaN/.test(d)) problems.push("diagram contains undefined/NaN");
  if (/undefined|NaN/.test(s)) problems.push("symbol contains undefined/NaN");
  ok(`${doc.id}`, problems.length === 0, problems.join("; "));
}

/* ---------- catalogue integrity ---------- */
ok("every component resolves in the map", COMPONENTS.every((c) => COMPONENT_MAP[c.id] === c));
ok("every component is simulatable", SIMULATABLE_COUNT === TOTAL_COMPONENTS, `${SIMULATABLE_COUNT}/${TOTAL_COMPONENTS}`);
ok("every component has all doc sections", COMPONENTS.every((c) =>
  Boolean(
    c.description && c.working && c.boolean && c.parts.length && c.applications.length &&
    c.objectives.length && c.examples.length && c.notes.length && c.tags.length && c.ic,
  ),
));
ok("no duplicate ids", new Set(COMPONENTS.map((c) => c.id)).size === COMPONENTS.length);
ok("no duplicate names", new Set(COMPONENTS.map((c) => c.name)).size === COMPONENTS.length);

console.log(
  `\nrendered ${COMPONENTS.length} components · symbol ${symbolChars} chars · diagram ${diagramChars} chars · table ${tableChars} chars · ${failures} failure(s)`,
);
if (failures) process.exit(1);
